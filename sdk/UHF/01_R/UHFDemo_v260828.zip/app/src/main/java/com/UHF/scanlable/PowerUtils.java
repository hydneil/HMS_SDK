package com.UHF.scanlable;

import android.os.Build;
import android.util.Log;

import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class PowerUtils {
    private static final String TAG = "PowerUtils";
    public static final int VCC_GP_DOWN = 0;
    public static final int VCC_RFID_DOWN = 4;
    public static final int VCC_RFID_UP = 5;
    public static final int VCC_PSAM_DOWN = 6;
    public static final int VCC_PSAM_UP = 7;
    public static final int VCC_ID_DOWN = 8;
    public static final int VCC_ID_UP = 9;
    public static final int VCC_MISC_DOWN = 10;
    public static final int VCC_MISC_UP = 11;
    public static final int VCC_OTG_DOWN = 12;
    public static final int VCC_OTG_UP = 13;

    public static final int VCC_LED_IR_DOWN = 14; // turn off IR led
    public static final int VCC_LED_IR_UP = 15; // turn on IR led
    public static final int VCC_LED_WHITE_DOWN = 16; // turn off White led
    public static final int VCC_LED_WHITE_UP = 17; // turn on White led
    public static final int VCC_LED_IR_POWER_OFF = 18; // turn off power of White & IR
    public static final int VCC_LED_IR_POWER_ON = 19; // turn on power of White & IR

    public static final int VCC_DOWN_FORCE = 24;
    public static final int VCC_UP_FORCE = 25;

    private static final boolean isSprdA12 = getSystemProp("ro.dfs.soc", "qcom").equals("sprd")
            && Build.VERSION.SDK_INT == 31;
    private static final boolean isMtk = getSystemProp("ro.dfs.soc", "qcom").equals("mtk");

    private static final String POGO_VBATT_SEL_FILE_PATH = "/sys/class/pigpig/pogo_vcc_sel/value"; // QCOM & SPRDA10
    private static final String SCN_RFID_EN = "/sys/class/pigpig/scn_rfid_en/value"; // MTK
    private static final String SCN_io2_EN = "/sys/class/pigpig/scn_io2/value"; // MTK, M50R/50T

    private static final String POGO_OTG_5V_EN = "/sys/class/leds/pogo_otg_5v_en/brightness";
    private static final String OTG_5V_EN = "/sys/class/leds/otg_5v_en/brightness";
    private static final String RFID_POWER_EN = "/sys/class/leds/rfid_pwr_en/brightness";

    /* M40IB only */
    private static final String IR_POWER_EN = "/sys/class/pigpig/scn_vccillum/value";
    private static final String IR_IO_EN = "/sys/class/pigpig/scn_vcc_io_host/value";
    private static final String IR_LED_IR_EN = "/sys/class/pigpig/scn_aim_en/value";
    private static final String IR_LED_WHITE_EN = "/sys/class/pigpig/scn_illum_en/value";

    public static boolean mDisableScan = true;

    public static String getSystemProp(String prop, String def){
        try{
            Class SystemProperties = Class.forName("android.os.SystemProperties");
            Method method = SystemProperties.getMethod("get", String.class, String.class);
            Object ret = method.invoke(null, prop, def);

            Log.d(TAG, "get prop : " + ret.toString());
            return (String)ret;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return "";
    }

    public static void powerCtrl(int type){
        try {
            if(isSprdA12) {
                FileOutputStream fOVbatPogoOtg = new FileOutputStream(POGO_OTG_5V_EN);
                FileOutputStream fOVbatOtg5v = new FileOutputStream(OTG_5V_EN);
                FileOutputStream fOVbatRfidPwr = new FileOutputStream(RFID_POWER_EN);
                switch (type) {
                    case VCC_RFID_DOWN:
                        fOVbatPogoOtg.write(Integer.toString(0).getBytes());
                        fOVbatOtg5v.write(Integer.toString(0).getBytes());
                        fOVbatRfidPwr.write(Integer.toString(1).getBytes());
                        break;
                    case VCC_RFID_UP:
                        fOVbatPogoOtg.write(Integer.toString(1).getBytes());
                        fOVbatOtg5v.write(Integer.toString(1).getBytes());
                        fOVbatRfidPwr.write(Integer.toString(0).getBytes());
                        break;
                    default:
                        // nothing
                }
                fOVbatPogoOtg.close();
                fOVbatOtg5v.close();
                fOVbatRfidPwr.close();
            }else if(isMtk){
                FileOutputStream fOVbatSel = new FileOutputStream(SCN_RFID_EN);
                switch (type) {
                    case VCC_RFID_DOWN:
                        fOVbatSel.write(Integer.toString(0).getBytes());
                        break;
                    case VCC_RFID_UP:
                        fOVbatSel.write(Integer.toString(1).getBytes());
                        break;
                    default:
                        // nothing
                }
                fOVbatSel.close();
            }else{
                FileOutputStream fOVbatSel = new FileOutputStream(POGO_VBATT_SEL_FILE_PATH);
                fOVbatSel.write(Integer.toString(type).getBytes());
                fOVbatSel.close();
            }
            Log.d(TAG,"Power control type: " + type);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void powerCtrlIRLed(int type){
        try {
            if(isMtk){
                /* Power & IO */
                FileOutputStream fIRPwr = new FileOutputStream(IR_POWER_EN);
                FileOutputStream fIRIO = new FileOutputStream(IR_IO_EN);

                /* LED IR */
                FileOutputStream fLedIR = new FileOutputStream(IR_LED_IR_EN);
                /* LED White */
                FileOutputStream fLedWhite = new FileOutputStream(IR_LED_WHITE_EN);

                switch (type) {
                    case VCC_LED_IR_POWER_ON:
                        fIRPwr.write(Integer.toString(1).getBytes());
                        fIRIO.write(Integer.toString(1).getBytes());
                        break;
                    case VCC_LED_IR_POWER_OFF:
                        fIRIO.write(Integer.toString(0).getBytes());
                        fIRPwr.write(Integer.toString(0).getBytes());
                        break;
                    case VCC_LED_IR_DOWN:
                        fLedIR.write(Integer.toString(0).getBytes());
                        break;
                    case VCC_LED_IR_UP:
                        fLedIR.write(Integer.toString(1).getBytes());
                        break;
                    case VCC_LED_WHITE_DOWN:
                        fLedWhite.write(Integer.toString(0).getBytes());
                        break;
                    case VCC_LED_WHITE_UP:
                        fLedWhite.write(Integer.toString(1).getBytes());
                        break;
                    default:
                        // nothing
                }
                fIRPwr.close();
                fIRIO.close();
                fLedIR.close();
                fLedWhite.close();
            }
            Log.d(TAG,"IR Power control type: " + type);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
