package com.UHF.scanlable;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.device.DeviceManager;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.hdms.HDMSManager;
import com.android.hdms.scanner.ScanManager;
import com.rfid.trans.ReadTag;



public class Finding extends Activity implements View.OnClickListener {
    private CircleProgress mCircleProgress;
    TextView epcid;
    Button btFinding;
    private volatile boolean mWorking = true;
    private volatile Thread mThread=null;
    Handler handler;
    ScanManager mScanManager;
    int rssi=0;
    public boolean keyPress =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finding);
        mCircleProgress = (CircleProgress) findViewById(R.id.circle_progress);
        epcid =(TextView)findViewById(R.id.epc_id);
        btFinding = (Button)findViewById(R.id.btfind);
        btFinding.setOnClickListener(this);
        handler = new Handler() {
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(Message msg) {
                try{
                    switch (msg.what) {
                        case 0:
                            String rssistr = msg.obj+"";
                            int rssi = (int)Integer.valueOf(rssistr);
                            mCircleProgress.setValue((float)rssi);
                            break;
                        default:
                            break;
                    }
                }catch(Exception ex)
                {ex.toString();}
            }
        };

        mScanManager = (ScanManager) HDMSManager.getInstance().getModuleManager(HDMSManager.MODULE_TYPE.SCANNER);
    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        epcid.setText(ScanMode.epc);
        mCircleProgress.setValue(0.00f);
        if(mScanManager != null && PowerUtils.mDisableScan) {
            mScanManager.disableScanKey(true);
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        if(mScanManager != null && PowerUtils.mDisableScan) {
            mScanManager.disableScanKey(false);
        }
        super.onPause();
    }

    @Override
    public void onClick(View v) {
        if(v == btFinding)
        {
            readTag();

        }
    }

    private void readTag()
    {
        if(btFinding.getText().toString().equals(getString(R.string.finding)))
        {
            if(mThread==null)
            {
                mWorking = true;
                btFinding.setText(R.string.btstop);
                mThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while(mWorking)
                        {
                            if(ScanMode.epc == null){
                                Message msg = handler.obtainMessage();
                                msg = handler.obtainMessage();
                                msg.what = 0;
                                rssi=0;
                                msg.obj = rssi + "";
                                handler.sendMessage(msg);
                                try {
                                    Thread.sleep(500);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }else{
                                ReadTag mtag = Reader.rrlib.FindEPC(ScanMode.epc);
                                if(mtag!=null)
                                {
                                    rssi = mtag.rssi;
                                    Reader.rrlib.playSound();
                                    Message msg = handler.obtainMessage();
                                    msg = handler.obtainMessage();
                                    msg.what = 0;
                                    msg.obj = rssi + "";
                                    handler.sendMessage(msg);
                                }
                                else
                                {
                                    if(rssi>0)
                                        rssi -=2;
                                    if(rssi<0) rssi=0;
                                    Message msg = handler.obtainMessage();
                                    msg = handler.obtainMessage();
                                    msg.what = 0;
                                    msg.obj = rssi + "";
                                    handler.sendMessage(msg);
                                }
                            }


                        }
                    }
                });
                mThread.start();
            }
        }
        else
        {
            if(mThread!=null)
            {
                mWorking=false;
                try {
                    mThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mThread=null;
                btFinding.setText(R.string.finding);
            }
        }
    }
    /**
     * Scan RFID with the hardware key
     **/
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==566 && !keyPress)
        {
            keyPress = true;
            readTag();
        }
        else if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Scan RFID with the hardware key
     **/
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if(keyCode==566)
        {
            keyPress =false;
        }
        return super.onKeyUp(keyCode, event);
    }


}