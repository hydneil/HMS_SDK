
# UHF开发常见FAQ Common FAQs on UHF Development

## 上电 Power-up

连接RFID前请确保已经正确上电，并保证有至少300ms延时，建议500ms
Before connecting the RFID module, please ensure that power has been correctly applied and that there is a delay of at least 300 ms; 500 ms is recommended.
```java
    PowerUtils.powerCtrl(PowerUtils.VCC_RFID_UP);
```

## 下电 Power-down

```java
    PowerUtils.powerCtrl(PowerUtils.VCC_RFID_DOWN);
```

## 波特率选择 Baud Rate Selection

波特率需要和RFID模块默认值匹配，默认值查看：UHFDemo-参数-波特率；
业务应用中可先尝试 115200,失败后再尝试 57600；

The baud rate must match the default value of the RFID module. To view the default value, refer to: UHFDemo > Parameters > Baud Rate;
In practical applications, you may first try 115200; if this fails, try 57600;

```java
    try {
        int result = Reader.rrlib.Connect(devport, 115200,1);
        if(result==0){
            baud = 115200;
            mBaud115200View.setChecked(true);
            initRfid();
            Intent intent;
            intent = new Intent().setClass(Connect232.this, MainActivity.class);
            startActivity(intent);
        }
        else
        {
            result = Reader.rrlib.Connect(devport, 57600,1);
            if(result==0){
                baud = 57600;
                mBaud57600View.setChecked(true);
                initRfid();
                Intent intent;
                intent = new Intent().setClass(Connect232.this, MainActivity.class);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(
                        getApplicationContext(),
                        getString(R.string.openport_failed),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }catch (Exception e) 
    {
        Toast.makeText(
                getApplicationContext(),
                getString(R.string.openport_failed),
                Toast.LENGTH_SHORT).show();
    }
```

## 禁用/使能扫描条码功能  Disable/enable the barcode scanning function

```java
    import com.android.hdms.HDMSManager;
    import com.android.hdms.scanner.ScanManager;

    ScanManager mScanManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        mScanManager = (ScanManager) HDMSManager.getInstance().getModuleManager(HDMSManager.MODULE_TYPE.SCANNER);
        // ...
    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();

        if(mScanManager != null) {
            mScanManager.disableScanKey(true); // Disable SCAN KEY
        }
        // ...
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();

        if(mScanManager != null) {
            mScanManager.disableScanKey(false); // Enable SCAN KEY
        }
        // ...
    }
```
