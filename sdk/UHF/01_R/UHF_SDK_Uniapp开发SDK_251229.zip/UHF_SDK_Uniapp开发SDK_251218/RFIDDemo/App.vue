<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		printAndroidLog: function(msg){
			var Log = plus.android.importClass("android.util.Log");
			Log.d("neil",msg);
		},
	}
</script>

<style>
	/*每个页面公共css */
	@import './common/uni-nvue.css';
</style>
