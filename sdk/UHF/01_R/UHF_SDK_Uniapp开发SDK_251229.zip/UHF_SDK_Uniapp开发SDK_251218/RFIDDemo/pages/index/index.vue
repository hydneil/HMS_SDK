<template>
	<view class="uni-container">
		<view class="uni-hello-text">
			<text @click="goDetailPage()">RFID演示</text>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				list: [{
					id:'rfid-module',
					name:'RFID演示',
					open:false,
					url:'/pages/sample/rfid_module'
				}],
				navigateFlag: false
			}
		},
		onLoad() {},
		methods: {
			goDetailPage() {
				console.log("click this")
				uni.navigateTo({
					url: "/pages/sample/rfid_module/rfid_module"
				});
			}
		}
	}
</script>

<style>
</style>
