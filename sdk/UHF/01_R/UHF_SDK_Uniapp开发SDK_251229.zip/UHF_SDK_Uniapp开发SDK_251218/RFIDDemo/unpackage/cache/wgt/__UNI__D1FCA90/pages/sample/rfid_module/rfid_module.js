"use weex:vue";

if (typeof Promise !== 'undefined' && !Promise.prototype.finally) {
  Promise.prototype.finally = function(callback) {
    const promise = this.constructor
    return this.then(
      value => promise.resolve(callback()).then(() => value),
      reason => promise.resolve(callback()).then(() => {
        throw reason
      })
    )
  }
};

if (typeof uni !== 'undefined' && uni && uni.requireGlobal) {
  const global = uni.requireGlobal()
  ArrayBuffer = global.ArrayBuffer
  Int8Array = global.Int8Array
  Uint8Array = global.Uint8Array
  Uint8ClampedArray = global.Uint8ClampedArray
  Int16Array = global.Int16Array
  Uint16Array = global.Uint16Array
  Int32Array = global.Int32Array
  Uint32Array = global.Uint32Array
  Float32Array = global.Float32Array
  Float64Array = global.Float64Array
  BigInt64Array = global.BigInt64Array
  BigUint64Array = global.BigUint64Array
};


(()=>{var y=Object.create;var d=Object.defineProperty;var v=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var C=Object.getPrototypeOf,h=Object.prototype.hasOwnProperty;var b=(t,n)=>()=>(n||t((n={exports:{}}).exports,n),n.exports);var k=(t,n,o,l)=>{if(n&&typeof n=="object"||typeof n=="function")for(let r of x(n))!h.call(t,r)&&r!==o&&d(t,r,{get:()=>n[r],enumerable:!(l=v(n,r))||l.enumerable});return t};var w=(t,n,o)=>(o=t!=null?y(C(t)):{},k(n||!t||!t.__esModule?d(o,"default",{value:t,enumerable:!0}):o,t));var m=b((N,_)=>{_.exports=Vue});var e=w(m());function g(t){return weex.requireModule(t)}function p(t,n,...o){uni.__log__?uni.__log__(t,n,...o):console[t].apply(console,[...o,n])}var I={"text-box":{"":{marginBottom:"40rpx",paddingTop:"40rpx",paddingRight:0,paddingBottom:"40rpx",paddingLeft:0,display:"flex",minHeight:"300rpx",backgroundColor:"#FFFFFF",justifyContent:"center",alignItems:"center",textAlign:"center",fontSize:"30rpx",color:"#353535",lineHeight:1.8}}},F=(t,n)=>{let o=t.__vccOpts||t;for(let[l,r]of n)o[l]=r;return o},s=g("ezrfid_plugin");g("modal");var D={data(){return{title:"RFID Demo",text:"",isConnected:!1}},methods:{connectUHF(){s.connect({rate:115200},t=>{this.text+="Connected :"+t.code+`
`}),p("log","at pages/sample/rfid_module/rfid_module.nvue:37","uhf connect")},disconnectUHF(){s.disConnect(),p("log","at pages/sample/rfid_module/rfid_module.nvue:41","uhf disconnect"),this.text+=`Disconnected!
`},startInventory(){s.startInventory(t=>{this.text+=`startInventory
`})},stopInventory(){s.stopInventory(),this.text+=`stopInventory
`}},onLoad(){plus.globalEvent.addEventListener("tagCallback",t=>{p("log","at pages/sample/rfid_module/rfid_module.nvue:57","tagCallback"+JSON.stringify(t)),this.text="tag ecpid>>"+t.epcId+`
`})}};function H(t,n,o,l,r,c){let f=(0,e.resolveComponent)("page-head"),i=(0,e.resolveComponent)("button");return(0,e.openBlock)(),(0,e.createElementBlock)("scroll-view",{scrollY:!0,showScrollbar:!0,enableBackToTop:!0,bubble:"true",style:{flexDirection:"column"}},[(0,e.createElementVNode)("view",{class:"content"},[(0,e.createVNode)(f,{title:r.title},null,8,["title"]),(0,e.createElementVNode)("view",{class:"uni-padding-wrap uni-common-mt"},[(0,e.createElementVNode)("view",{class:"text-box",scrollY:"true"},[(0,e.createElementVNode)("u-text",null,(0,e.toDisplayString)(r.text),1)]),(0,e.createElementVNode)("view",{class:"uni-btn-v"},[(0,e.createVNode)(i,{type:"primary",onClick:c.connectUHF},{default:(0,e.withCtx)(()=>[(0,e.createTextVNode)("Connect UHF")]),_:1},8,["onClick"]),(0,e.createVNode)(i,{type:"primary",onClick:c.disconnectUHF},{default:(0,e.withCtx)(()=>[(0,e.createTextVNode)("Disconect")]),_:1},8,["onClick"]),(0,e.createVNode)(i,{type:"primary",onClick:c.startInventory},{default:(0,e.withCtx)(()=>[(0,e.createTextVNode)("startInventory")]),_:1},8,["onClick"]),(0,e.createVNode)(i,{type:"primary",onClick:c.stopInventory},{default:(0,e.withCtx)(()=>[(0,e.createTextVNode)("stopInventory")]),_:1},8,["onClick"])])])])])}var a=F(D,[["render",H],["styles",[I]]]);var u=plus.webview.currentWebview();if(u){let t=parseInt(u.id),n="pages/sample/rfid_module/rfid_module",o={};try{o=JSON.parse(u.__query__)}catch(r){}a.mpType="page";let l=Vue.createPageApp(a,{$store:getApp({allowDefault:!0}).$store,__pageId:t,__pagePath:n,__pageQuery:o});l.provide("__globalStyles",Vue.useCssStyles([...__uniConfig.styles,...a.styles||[]])),l.mount("#root")}})();
