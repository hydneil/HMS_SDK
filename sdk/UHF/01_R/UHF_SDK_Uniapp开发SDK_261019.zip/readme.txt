# UHF SDK for uniapp

## 文件说明
 * ezrfid_plugin： uniapp Android Native插件
 * RFIDDemo：uniapp示例工程源码
 * UHF_SDK_Uniapp开发文档： uniapp Android Native插件接口文档
 
 
=====================
## 更新SDK开发版本日志
=====================
2026.10.19
Version: 1.0.2
修改：
	1.add table sdk.
=====================
2025.12.29
Version: 1.0.1
修改：
	1.Fixed crash when disconnecting directly during inventory.
=====================

2024.12.31
Version: 1.0.0
修改：
	1.init sdk
