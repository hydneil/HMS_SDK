package com.fmsh.fmshrfid.sql;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.adapter.DataBaseAdapter;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.lxj.xpopup.animator.PopupAnimator;
import com.lxj.xpopup.core.CenterPopupView;
import com.lxj.xpopup.impl.FullScreenPopupView;
import com.qmuiteam.qmui.widget.QMUITopBarLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/11/13 14:23
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public  class CustomPopup extends FullScreenPopupView {

    private DataBaseAdapter dataBaseAdapter;
    private ArrayList<InventoryBean> mData;
    private RecyclerView recyclerView;
    private TextView tvEmpty;

    public void setmData(ArrayList<InventoryBean> mData) {
        this.mData = mData;
        if(dataBaseAdapter != null){
            dataBaseAdapter.notifyDataSetChanged();
        }
    }

    //注意：自定义弹窗本质是一个自定义View，但是只需重写一个参数的构造，其他的不要重写，所有的自定义弹窗都是这样。
    public CustomPopup(@NonNull Context context, ArrayList<InventoryBean> data) {
        super(context);
        this.mData = data;

    }
    // 返回自定义弹窗的布局
    @Override
    protected int getImplLayoutId() {
        return R.layout.dialog_full_screen;
    }
    // 执行初始化操作，比如：findView，设置点击，或者任何你弹窗内的业务逻辑
    @Override
    protected void onCreate() {
        super.onCreate();
        dataBaseAdapter = new DataBaseAdapter(getContext());
        recyclerView = findViewById(R.id.data_list);
        tvEmpty = findViewById(R.id.tv_empty);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerView.setAdapter(dataBaseAdapter);
        QMUITopBarLayout mTopBar = findViewById(R.id.topbar);
        mTopBar.setTitle("数据库列表");
        dataBaseAdapter.setList(mData);
        changeView();
        mTopBar.addLeftBackImageButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                smartDismiss();

            }
        });


    }

    public void changeView(){
        if(mData.size() > 0){
            recyclerView.setVisibility(VISIBLE);
            tvEmpty.setVisibility(GONE);
        }else {
            recyclerView.setVisibility(GONE);
            tvEmpty.setVisibility(VISIBLE);
        }
    }

    public DataBaseAdapter getDataBaseAdapter() {
        return dataBaseAdapter;
    }


}
