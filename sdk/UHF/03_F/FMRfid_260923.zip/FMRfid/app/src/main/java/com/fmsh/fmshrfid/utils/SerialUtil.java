package com.fmsh.fmshrfid.utils;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.util.Log;
import com.fmsh.fmshrfid.activity.CustomProber;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SerialUtil {
    UsbSerialPort usbSerialPort;
    public UsbManager usbManager;
    private UsbDevice device;
    private enum UsbPermission { Unknown, Requested, Granted, Denied }
    public enum UsbStatus { NO_USB_DEVICE, NO_USB_DRIVER, NO_USB_PERMISSION, OPEN_USB_FAILED, USB_CONECTED, USB_DISCONECTED}
    private UsbPermission usbPermission = UsbPermission.Unknown;
    private static final String ACTION_USB_PERMISSION = "com.android.usb.USB_PERMISSION";
    private static boolean connected = false;
    private static Lock Uart_Lock;
    private static char _lock_=0;
    private static Lock Uart_Pool_Lock;
    private static char _pool_lock_=0;
    private static Queue<Byte> UART_Pool;
    private static final int WRITE_WAIT_MILLIS = 200;
    private static final int READ_WAIT_MILLIS = 200;
    private UsbStatus SerialUtilStatus;
    private ReentrantReadWriteLock sta_rwl;
    public  SerialUtil(Context mContext){
        sta_rwl = new ReentrantReadWriteLock();

        usbManager = (UsbManager) mContext.getSystemService(mContext.USB_SERVICE);
        for(UsbDevice v : usbManager.getDeviceList().values())
            if(v.getDeviceId() > 0)
                device = v;
        if(device == null) {
            SerialUtilStatus = UsbStatus.NO_USB_DEVICE;//"未发现USB设备!";
            return;
        }
        UsbSerialDriver driver = UsbSerialProber.getDefaultProber().probeDevice(device);
        if(driver == null) {
            driver = CustomProber.getCustomProber().probeDevice(device);
        }
        if(driver == null) {
            SerialUtilStatus = UsbStatus.NO_USB_DRIVER;//"未发现USB设备对应驱动!";
            return;
        }
        usbSerialPort = driver.getPorts().get(0);
        UsbDeviceConnection usbConnection = usbManager.openDevice(driver.getDevice());
        if(usbConnection == null && usbPermission == UsbPermission.Unknown && !usbManager.hasPermission(driver.getDevice())) {
            usbPermission = UsbPermission.Requested;
            //int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent usbPermissionIntent = PendingIntent.getBroadcast(mContext, 0, new Intent(ACTION_USB_PERMISSION), 0);
            IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
            mContext.registerReceiver(mUsbReceiver, filter);
            usbManager.requestPermission(driver.getDevice(), usbPermissionIntent);
            SerialUtilStatus = UsbStatus.NO_USB_PERMISSION;//"未获取USB设备权限!";
            return;
        }
        if(usbConnection == null) {
            if (!usbManager.hasPermission(driver.getDevice()))
                SerialUtilStatus = UsbStatus.NO_USB_PERMISSION;
            else
                SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
            return;
        }
        try {
            usbSerialPort.open(usbConnection);
            try{
                usbSerialPort.setParameters(115200, 8, 1, UsbSerialPort.PARITY_NONE);
            }catch (UnsupportedOperationException e){
                SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
//                LogList.add(new itemdata("USB设备参数异常!"));
            }
            connected = true;
            SerialUtilStatus = UsbStatus.USB_CONECTED;//"USB设备连接成功!";
            Uart_Lock = new ReentrantLock();
            Uart_Pool_Lock= new ReentrantLock();
            UartReadThread();

        } catch (Exception e) {
            SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
//            LogList.add(new itemdata("USB设备连接失败："+ e.getMessage()));
            disconnect();
        }
        return;
    }

    public  void Connect(Context mContext){
        usbManager = (UsbManager) mContext.getSystemService(mContext.USB_SERVICE);
        for(UsbDevice v : usbManager.getDeviceList().values())
            if(v.getDeviceId() > 0)
                device = v;
        if(device == null) {
            SerialUtilStatus = UsbStatus.NO_USB_DEVICE;//"未发现USB设备!";
            return;
        }
        UsbSerialDriver driver = UsbSerialProber.getDefaultProber().probeDevice(device);
        if(driver == null) {
            driver = CustomProber.getCustomProber().probeDevice(device);
        }
        if(driver == null) {
            SerialUtilStatus = UsbStatus.NO_USB_DRIVER;//"未发现USB设备对应驱动!";
            return;
        }
        usbSerialPort = driver.getPorts().get(0);
        UsbDeviceConnection usbConnection = usbManager.openDevice(driver.getDevice());
        if(usbConnection == null && usbPermission == UsbPermission.Unknown && !usbManager.hasPermission(driver.getDevice())) {
            usbPermission = UsbPermission.Requested;
            //int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent usbPermissionIntent = PendingIntent.getBroadcast(mContext, 0, new Intent(ACTION_USB_PERMISSION), 0);
            IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
            filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
            mContext.registerReceiver(mUsbReceiver, filter);
            usbManager.requestPermission(driver.getDevice(), usbPermissionIntent);
            SerialUtilStatus = UsbStatus.NO_USB_PERMISSION;//"未获取USB设备权限!";
            return;
        }
        if(usbConnection == null) {
            if (!usbManager.hasPermission(driver.getDevice()))
                SerialUtilStatus = UsbStatus.NO_USB_PERMISSION;
            else
                SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
            return;
        }
        try {
            usbSerialPort.open(usbConnection);
            try{
                usbSerialPort.setParameters(115200, 8, 1, UsbSerialPort.PARITY_NONE);
            }catch (UnsupportedOperationException e){
                SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
//                LogList.add(new itemdata("USB设备参数异常!"));
            }
            connected = true;
            SerialUtilStatus = UsbStatus.USB_CONECTED;//"USB设备连接成功!";
            Uart_Lock = new ReentrantLock();
            Uart_Pool_Lock= new ReentrantLock();
            UartReadThread();

        } catch (Exception e) {
            SerialUtilStatus = UsbStatus.OPEN_USB_FAILED;
//            LogList.add(new itemdata("USB设备连接失败："+ e.getMessage()));
            disconnect();
        }
        return;
    }

    public UsbStatus getSerialUtilStatus(){
        UsbStatus sta;
        sta_rwl.writeLock().lock();
        sta = SerialUtilStatus;
        sta_rwl.writeLock().unlock();
        return sta;
    }
    public void setSerialUtilStatus(UsbStatus sta){
        sta_rwl.writeLock().lock();
        SerialUtilStatus = sta;
        sta_rwl.writeLock().unlock();
    }

    public String getDeviceName(){
        if(device == null)
        {
            return "No Device";
        }
        return device.getDeviceName();
    }

    public String getProductName(){
        if(device == null)
        {
            return "No Device";
        }
        return device.getProductName();
    }

    public int getVendorId(){
        if(device == null)
        {
            return 0xFF;
        }
        return device.getVendorId();
    }

    public int getProductId(){
        if(device == null)
        {
            return 0xFF;
        }
        return device.getProductId();
    }

    public void setParameters(int baudRate, int dataBits, int stopBits, @UsbSerialPort.Parity int parity) throws IOException {
        usbSerialPort.setParameters(baudRate, dataBits, stopBits, parity);
    }
    public boolean isOpen()
    {
        //return connected;
        if(usbSerialPort == null)
        {
            return false;
        }
        return usbSerialPort.isOpen();
    }
    public String getSerial()
    {
        if(usbSerialPort == null)
        {
            return "No Device";
        }
        return usbSerialPort.getSerial();
    }
    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        @SuppressLint("NewApi")
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    context.unregisterReceiver(mUsbReceiver);
                    UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        //TODO 授权成功，操作USB设备
                    }else{
                        //用户点击拒绝了
//                        LogList.add(new itemdata("拒绝 USB 访问"));
                    }
                }
            }
        }
    };

    private static void UART_LOCK(boolean lock)
    {
//        if((lock)&&(0 == _lock_))
//        {
//            //Log.i("JNILOG", "UART_LOCK: ");
//            _lock_ = 1;
//            Uart_Lock.lock();
//        }
//        else if((!lock)&&(0 != _lock_))
//        {
//            //Log.i("JNILOG", "UART_UNLOCK: ");
//            _lock_ = 0;
//            Uart_Lock.unlock();
//        }
    }
    private static void UART_POOL_LOCK(boolean lock)
    {
        if((lock))
//        if((lock)&&(0 ==_pool_lock_))
//        {
//            //Log.i("JNILOG", "UART_POOL_LOCK: ");
//            _pool_lock_=1;
            Uart_Pool_Lock.lock();
//        }
        else
//        else if((!lock)&&(0 !=_pool_lock_))
//        {
//            //Log.i("JNILOG", "UART_POOL_UNLOCK: ");
//            _pool_lock_ = 0;
            Uart_Pool_Lock.unlock();
//        }
    }

    public void disconnect() {
        connected = false;
        try {
            usbSerialPort.close();
        } catch (IOException ignored) {}
        usbSerialPort = null;
        UART_Pool_Clear();
    }

    public int send_uart(byte[] data, int len){
        UART_LOCK(true);
        send(data);
        UART_LOCK(false);
        return len;
    }
    public int recv_uart(byte[] data, int len){
        int real_len = 0;
        UART_POOL_LOCK(true);
        //try {
        real_len = read(data,len);
        //}
        //catch (Exception e){
        //    Log.i("JNILOG", "rfidread error: "+ e + data+"len="+ len +" real_len=" + real_len);
        //    UART_POOL_LOCK(false);
        //    return real_len;
        //}
        UART_POOL_LOCK(false);
        return real_len;
    }

    public static void UART_Pool_Clear() {
        if(null != UART_Pool) {
            UART_Pool.clear();
        }
    }

    public void onRunError(Exception e) {
        disconnect();
    }

    private synchronized void send(byte[] data) {
        if(!connected) {
            return;
        }
        try {
            usbSerialPort.write(data, WRITE_WAIT_MILLIS);
        } catch (Exception e) {
            onRunError(e);
        }
    }

    private synchronized int read(byte[] out, int expect_len) {
        int len = expect_len;
        if((!connected)||(0 == expect_len)) {
            return 0;
        }
        try {
            if((null == UART_Pool))
            {
                return 0;
            }
            if( UART_Pool.isEmpty() )
            {
                return 0;
            }

            if(expect_len > UART_Pool.size()) {
                len = UART_Pool.size();
            }

            for (int i = 0; i < len; i++) {
                out[i] = UART_Pool.poll();
            }
        }
        catch (Exception e){
            Log.i("JNILOG", "synchronized read error: "+ e + " UART_Pool.size()=" +UART_Pool.size()+UART_Pool);
            return len;
        }
        //Log.i("JNILOG", "UART_Pool OUT" + expect_len);
        return len;
    }

    private void onUartRecvThread(){
        int len = 0;
        byte[] buffer = new byte[512];
        while(true) {
            try {
                while (true) {
                    Thread.sleep(10);
                    UART_LOCK(true);
                    len = usbSerialPort.read(buffer, READ_WAIT_MILLIS);
                    UART_LOCK(false);
                    if(len>0)
                    {
                        UART_POOL_LOCK(true);
                        for (int i = 0; i < len; i++) {
                            UART_Pool.add(buffer[i]);
                        }
                        UART_POOL_LOCK(false);
                    }
//                    Log.i("JNILOG", "UART_Pool OUT");
                    if(!isOpen())
                    {
                        Log.i("JNILOG", "USB_DISCONECTED OUT");
                        SerialUtilStatus = UsbStatus.USB_DISCONECTED;
                        return;
                    }
                }
            } catch (IOException e) {
                UART_LOCK(false);
            }
            catch (Exception e)
            {
                Log.i("JNILOG", " Exception error:" + e);
                UART_LOCK(false);
            }
        }
    }

    private void UartReadThread(){
        new Thread("UartReadThread"){
            @Override
            public void run(){
                UART_Pool = new LinkedList<>();
                onUartRecvThread();
            }
        }.start();
    }
}
