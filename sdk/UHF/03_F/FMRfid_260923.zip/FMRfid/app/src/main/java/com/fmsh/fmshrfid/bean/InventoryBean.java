package com.fmsh.fmshrfid.bean;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/13 14:34
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class InventoryBean {
    private int labelCount = 1; // 标签被盘点次数
    private int Pkt_Version;

    public int getLabelCount() {
        return labelCount;
    }

    @Override
    public String toString() {
        return "InventoryBean{" +
                "labelCount=" + labelCount +
//                ", Pkt_Version=" + Pkt_Version +
//                ", Packet_Flags=" + Packet_Flags +
//                ", Pkt_Type=" + Pkt_Type +
//                ", Pkt_Length=" + Pkt_Length +
//                ", epc_len=" + epc_len +
//                ", MS_Ctr=" + MS_Ctr +
//                ", NB_RSSI='" + NB_RSSI + '\'' +
//                ", WB_RSSI_OTHER='" + WB_RSSI_OTHER + '\'' +
//                ", ANA_CTRL='" + ANA_CTRL + '\'' +
//                ", RSSI=" + RSSI +
//                ", Phase=" + Phase +
//                ", ChannelIndex_Antenna='" + ChannelIndex_Antenna + '\'' +
//                ", Inv_Data='" + Inv_Data + '\'' +
                ", pc='" + pc + '\'' +
                ", epc='" + epc + '\'' +
//                ", crc='" + crc + '\'' +
//                ", tid='" + tid + '\'' +
//                ", chIdx=" + chIdx +
//                ", PhyAtn=" + PhyAtn +
//                ", name='" + name + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLabelCount(int labelCount) {
        this.labelCount = labelCount;
    }

    private int Packet_Flags;

    private int Pkt_Type;
    private int Pkt_Length;
    private int epc_len;

    private long MS_Ctr;
    private String NB_RSSI;
    private String WB_RSSI_OTHER;
    private String ANA_CTRL;
    private double RSSI;
    private double Phase;
    private String ChannelIndex_Antenna;
    private String Inv_Data;
    private String pc;
    private String epc;

    public int getPkt_Version() {
        return Pkt_Version;
    }

    public void setPkt_Version(int pkt_Version) {
        Pkt_Version = pkt_Version;
    }

    public int getPacket_Flags() {
        return Packet_Flags;
    }

    public void setPacket_Flags(int packet_Flags) {
        Packet_Flags = packet_Flags;
    }

    public int getPkt_Type() {
        return Pkt_Type;
    }

    public void setPkt_Type(int pkt_Type) {
        Pkt_Type = pkt_Type;
    }

    public int getPkt_Length() {
        return Pkt_Length;
    }

    public void setPkt_Length(int pkt_Length) {
        Pkt_Length = pkt_Length;
    }

    public int getEpc_len() {
        return epc_len;
    }

    public void setEpc_len(int epc_len) {
        this.epc_len = epc_len;
    }

    public long getMS_Ctr() {
        return MS_Ctr;
    }

    public void setMS_Ctr(long MS_Ctr) {
        this.MS_Ctr = MS_Ctr;
    }

    public String getNB_RSSI() {
        return NB_RSSI;
    }

    public void setNB_RSSI(String NB_RSSI) {
        this.NB_RSSI = NB_RSSI;
    }

    public String getWB_RSSI_OTHER() {
        return WB_RSSI_OTHER;
    }

    public void setWB_RSSI_OTHER(String WB_RSSI_OTHER) {
        this.WB_RSSI_OTHER = WB_RSSI_OTHER;
    }

    public String getANA_CTRL() {
        return ANA_CTRL;
    }

    public void setANA_CTRL(String ANA_CTRL) {
        this.ANA_CTRL = ANA_CTRL;
    }

    public double getRSSI() {
        return RSSI;
    }

    public void setRSSI(double RSSI) {
        this.RSSI = RSSI;
    }

    public double getPhase() {
        return Phase;
    }

    public void setPhase(double phase) {
        Phase = phase;
    }

    public String getChannelIndex_Antenna() {
        return ChannelIndex_Antenna;
    }

    public void setChannelIndex_Antenna(String channelIndex_Antenna) {
        ChannelIndex_Antenna = channelIndex_Antenna;
    }

    public String getInv_Data() {
        return Inv_Data;
    }

    public void setInv_Data(String inv_Data) {
        Inv_Data = inv_Data;
    }

    public String getPc() {
        return pc;
    }

    public void setPc(String pc) {
        this.pc = pc;
    }

    public String getEpc() {
        return epc;
    }

    public void setEpc(String epc) {
        this.epc = epc;
    }

    public String getCrc() {
        return crc;
    }

    public void setCrc(String crc) {
        this.crc = crc;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public int getChIdx() {
        return chIdx;
    }

    public void setChIdx(int chIdx) {
        this.chIdx = chIdx;
    }

    public int getPhyAtn() {
        return PhyAtn;
    }

    public void setPhyAtn(int phyAtn) {
        PhyAtn = phyAtn;
    }

    private String crc;
    private String tid;
    private int chIdx;
    private int PhyAtn;

    private String name;


}
