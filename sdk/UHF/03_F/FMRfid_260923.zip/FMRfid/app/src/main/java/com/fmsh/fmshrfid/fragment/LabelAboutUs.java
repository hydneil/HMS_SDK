package com.fmsh.fmshrfid.fragment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.UIUtils;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;

import butterknife.BindView;
/**
 * @author : sunjun
 * @version : 0.0.1
 * @Date : 2023/12/11 15:19
 * @E-Mail : sunjun@fmsh.com.cn
 */
public class LabelAboutUs extends BaseFragment {
    @BindView(R.id.AppInfo)
    TextView Text_Info;
    @BindView(R.id.AppVer)
    TextView Text_AppVer;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_about_us;
    }

    @Override
    protected void initView(View view) {
    }
    @Override
    protected void initData() {
        byte[] data = RfidLibrary.FmshGetSerialNum();
        byte[] version = RfidLibrary.FmshGetVersion();
        Text_AppVer.setText(UIUtils.getString(mContext,R.string.app_name)+ "  V" +UIUtils.getVersion(mContext));
        String appinfo = "Serial Number : " + FMUtil.byteToString(data) +"\n\n" + FMUtil.byteToString(version);
        Text_Info.setText(appinfo);
    }

    @Override
    public String getTitle() {
        return "关于我们";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
