package com.fmsh.fmshrfid.jni;

public class RfidLibrary {
        public interface CallbackInterface {
        public void onCallback(byte[] message);
    }
    public interface RWCallbackInterface {
        public int onRfidRead(byte[] data, int len);
        public int onRfidWrite(byte[] data, int len);
    }

    public static native int FmshRadioOpen(String dev);
    public static native void FmshRadioClose();
    public static native int FmshRadioConfig(int baud_rate);
    public static native byte[] FmshGetSerialNum();
    public static native byte[] FmshGetVersion();
    public static native int SetCurrentLinkProfile( int profile );
    public static native int GetCurrentLinkProfile();

    /**
     *
     * @param mode 盘点模式 0单次盘点 1连续判断
     * @param callbackInterface 回发数据
     */
    public static native void Inventory(int mode ,CallbackInterface callbackInterface);
    public static native int stopInventory();
    public static native int GetCurProto();
//    // 设置功率
    public static native int SetAntenna( int bmask,int nPort,int nPower,int dwelltime);
    //获取功率
    public static native int GetAntenna(int[] nPort,int[] nPower,int[] dwelltime);
//    // 设置频率
    public static native int SetFreq( int nFreq, int nDiv);
//    // 获取频率
    public static native int[] GetFreq( );
    public static native int  writeReg(byte[] address,byte[] value);
    public static native byte[]  readReg(byte[] address);
    public static native int  writeOemReg(byte[] address,byte[] value);
    public static native byte[]  readOemReg(byte[] address);
    public static native int SetmatchRule(int proto, String sel_str,int str_len);
    public static native int SelectTag(String sel_str);
    public static native int ReadFreqCfgs(int[]buffer, int[] size);
    public static native int WriteFreqCfgs(int[]buffer, int size);
    public static native int ReadTag(int bank, int offset,byte[] pbuffer, int wordcount,int passwd);
    public static native int WriteTag(int bank, int offset,byte[] pbuffer, int wordcount,int passwd);
    public static native int LedCtrl(int mode, int on_time,int passwd);
    public static native int TempMeas(int passwd,byte[] pbuffer);
    public static native int ReadFifo(int offset,byte[] pbuffer, int wordcount,int passwd);
    public static native int WriteFifo(int offset,byte[] pbuffer, int wordcount,int passwd);
    public static native int switch_bank_ind(int proto, int bank);
    public static native void InitInventory();
    public static native int Cmdprocess(byte[] cmdLine, int cmdLen, byte[] resp, int[] respLen);

    static{
        try {
            System.loadLibrary("rfid" );
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
