package com.fmsh.fmshrfid.fragment;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.Constant;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelTempMeasFragment extends BaseFragment {
    @BindView(R.id.temp_epc_filter_spinner)
    Spinner epc_flt_Spinner;
    @BindView(R.id.temp_password)
    EditText led_ctrl_password;
    @BindView(R.id.text_temp)
    EditText Text_temp;
    private ArrayList<String> epcList;
    private QMUITipDialog loadingDialog;
    int cur_proto;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_temp_meas;
    }
    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
        if((epcList!= null) && (epcList.size()>0))
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_flt_Spinner.setAdapter(epc_filter_adapter);

            cur_proto = RfidLibrary.GetCurProto();
            loadingDialog = HintDialog.loadingDialog(mContext);
        }
    }
    @Override
    protected void initView(View view) {
    }
    private int OnSetMatchRegister(){
        int stat = 0;
        if(epcList.size()>0) {
            String match_str = epcList.get(epc_flt_Spinner.getSelectedItemPosition());
            stat = RfidLibrary.SetmatchRule(cur_proto, match_str, match_str.length());
        }
        return stat;
    }
    void OnClickedTempMeas(){
        byte []tempBuffer=new byte[4];
        String buff_str ="";
        String strpasswd = led_ctrl_password.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置口令");
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            return;
        }
        int passwd = Integer.parseInt(strpasswd);
        if(0 == (RfidLibrary.TempMeas(passwd, tempBuffer)))
        {
            byte tag_stat =  (byte)(tempBuffer[0] >> 8);
            byte operat_stat = tempBuffer[0];

            if (0 != tag_stat)
            {
                buff_str = String.format("测温失败!Tag status = 0x%02X",tag_stat);
                HintDialog.successDialog(mContext, buff_str);
                return;
            }
            else if (0 != operat_stat)
            {
                buff_str = String.format("测温失败!Operate Status = 0x%02X",operat_stat);
                HintDialog.successDialog(mContext, buff_str);
                return;
            }
            else
            {
                int temp_data = (((int)tempBuffer[3]<<8))| ((int)(0xFF&tempBuffer[2]));
                if( (temp_data & 0x200)==0x200)
                {//负温
                    temp_data = ~temp_data;
                    temp_data &= 0x01FF;
                    temp_data += 1;
                    buff_str = String.format(("-%d.%02d "), temp_data >> 2, 25 * (temp_data & 0x03));
                }
                else
                {
                    temp_data &= 0x01FF;
                    buff_str = String.format(("%d.%02d "), temp_data >> 2, 25 * (temp_data & 0x03));
                }
                Text_temp.setText(buff_str);
            }
            HintDialog.successDialog(mContext, "测温成功!");
        }
        else
        {
            HintDialog.faileDialog(mContext, "测温失败!");
        }
    }

    @OnClick({R.id.but_temp_meas})
    public void onClick(View view) {
        setBusy(Constant.FUNC_IN_BUSY);
        switch (view.getId()) {
            case R.id.but_temp_meas:
                OnClickedTempMeas();
                break;
        }
        setBusy(Constant.FUNC_IN_READY);
    }
    @Override
    protected void initData() {
    }
    @Override
    public String getTitle() {
        return "温度测量";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
