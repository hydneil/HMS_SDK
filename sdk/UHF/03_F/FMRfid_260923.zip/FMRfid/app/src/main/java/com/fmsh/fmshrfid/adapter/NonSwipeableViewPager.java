package com.fmsh.fmshrfid.adapter;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.viewpager.widget.ViewPager;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 14:10
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class NonSwipeableViewPager extends ViewPager {
    private boolean swipeEnabled;

    public NonSwipeableViewPager(Context context) {
        super(context);
        swipeEnabled = true;
    }

    public NonSwipeableViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        swipeEnabled = true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return swipeEnabled && super.onTouchEvent(event);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        return swipeEnabled && super.onInterceptTouchEvent(event);
    }

    public void setSwipeEnabled(boolean enabled) {
        swipeEnabled = enabled;
    }
}
