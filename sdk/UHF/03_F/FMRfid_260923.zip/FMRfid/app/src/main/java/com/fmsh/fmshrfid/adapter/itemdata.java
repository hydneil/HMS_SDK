package com.fmsh.fmshrfid.adapter;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author W凯
 * @data 2022/9/28
 * @fuction 实体类
 */
public class itemdata   {
    private String name;
    public itemdata(String name ){
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
