package com.fmsh.fmshrfid.utils;

import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.fmshrfid.bean.InventoryBean;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/13 15:05
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class ParseUtils {
    public static InventoryBean parsePacket(byte[] data) {
        LogUtil.d("parsePacket data:" + bytesToHexstr(data));
        int length = data.length;
        byte[] b_PC = new byte[2], b_CRC= new byte[2];
        int protocol = ((char)data[0])& 0x0F;
        LogUtil.d("parsePacket protocol:" + protocol);
        int epcLength = 0, tidLength = 0;
        double[] calcNbRssi;
        double phase;
        int[] ints;
        long MS_Ctr;
        InventoryBean inventoryBean = new InventoryBean();
        switch (protocol)
        {
            case 0x01://QUERY_EPC
                System.arraycopy(data,3,b_PC,0,2);
                epcLength = ((((((int)b_PC[0]) << 8) | b_PC[1]) >> 10) & 0xFE);
                break;
            case 0x02://QUERY_GP
            case 0x04://QUERY_JP
                System.arraycopy(data,3,b_PC,0,2);
                epcLength = b_PC[0] << 1;
                break;
            case 0x03://QUERY_6B
                epcLength = 0;
                tidLength = 8;
                /* if TID is included, print it out */
                System.arraycopy(data,tidLength + 3, b_CRC,0,2);
                MS_Ctr = byteArrayToTime(new byte[]{data[epcLength + tidLength + 8],
                                                    data[epcLength + tidLength + 7],
                                                    data[epcLength + tidLength + 6],
                                                    data[epcLength + tidLength + 5]});
                calcNbRssi = calcNbRssi(byteArrayToUnsignedInt(new byte[]{data[epcLength + tidLength + 10], data[epcLength + tidLength + 9]}));
                phase = calcPhase(byteArrayToUnsignedInt(new byte[]{data[epcLength + tidLength + 18], data[epcLength + tidLength + 17]}), calcNbRssi[0]);
                ints = calcChannelIndex_Antenna(byteArrayToUnsignedInt(new byte[]{data[epcLength + tidLength + 20], data[epcLength + tidLength + 19]}));
            break;
            default:
                break;
        }
        tidLength = length - epcLength - 21;
        LogUtil.d("tidLength:" + tidLength);
        if (tidLength < 0)
        {
            return inventoryBean;
        }
        MS_Ctr = byteArrayToTime(new byte[]{data[epcLength + tidLength + 20],
                data[epcLength + tidLength + 19],
                data[epcLength + tidLength + 18],
                data[epcLength + tidLength + 17]});
        calcNbRssi = calcNbRssi(byteArrayToUnsignedInt(new byte[]{data[epcLength + tidLength + 8], data[epcLength + tidLength + 7]}));
        phase = calcPhase(byteArrayToUnsignedInt(new byte[]{data[epcLength + tidLength + 12], data[epcLength + tidLength + 11]}), calcNbRssi[0]);
        ints = new int[]{data[epcLength + tidLength + 15], data[epcLength + tidLength + 16]};
        byte[] Inv_Data = new byte[epcLength + tidLength + 2 + 2];
        System.arraycopy(data,3,Inv_Data,0,epcLength + tidLength + 2 + 2);
        String pc_epc_crc = FMUtil.byteToHex(Inv_Data);
        String pc = pc_epc_crc.substring(0,4);
        String epc= pc_epc_crc.substring(4,epcLength *2 + 4);
        String crc= pc_epc_crc.substring(pc_epc_crc.length()-4);

        //inventoryBean.setPkt_Version(data[0]);
        //inventoryBean.setPacket_Flags(data[1]);
        //inventoryBean.setPkt_Type(byteArrayToUnsignedInt(new byte[]{data[3], data[2]}));
        inventoryBean.setPkt_Length(length);
        inventoryBean.setEpc_len(epcLength + tidLength + 2);
        inventoryBean.setMS_Ctr(MS_Ctr);
        inventoryBean.setNB_RSSI(FMUtil.byteToHex(new byte[]{data[epcLength + tidLength + 9], data[epcLength + tidLength + 10]}));
        inventoryBean.setWB_RSSI_OTHER(FMUtil.byteToHex(new byte[]{data[epcLength + tidLength + 12], data[epcLength + tidLength + 11]}));
        inventoryBean.setANA_CTRL(FMUtil.byteToHex(new byte[]{data[epcLength + tidLength + 13], data[epcLength + tidLength + 14]}));
        inventoryBean.setRSSI(calcNbRssi[1]);
        inventoryBean.setPhase(phase);
        inventoryBean.setChIdx(ints[0]);
        inventoryBean.setPhyAtn(ints[1]);
        inventoryBean.setPc(pc);
        inventoryBean.setEpc(epc);
        inventoryBean.setCrc(crc);
        inventoryBean.setInv_Data(pc_epc_crc);
        if(tidLength > 0){
            byte[] tid = new byte[tidLength];
            System.arraycopy(data,3 + epcLength + 4,tid,0,tidLength);
            inventoryBean.setTid(FMUtil.byteToHex(tid));
        }
        return inventoryBean;
    }
    public static String bytesToHexstr(byte[] bArray) {
        StringBuffer sb = new StringBuffer(bArray.length);

        for(int i = 0; i < bArray.length; ++i) {
            String sTemp = Integer.toHexString(255 & bArray[i]);
            if (sTemp.length() < 2) {
                sb.append(0);
            }

            sb.append(sTemp.toUpperCase());
        }

        return sb.toString();
    }
    public static double[] calcNbRssi(int NB_RSSI) {
        double x, y;
        int a, b;
        double rssi;
        double angle;
        a = (int) ((NB_RSSI & 0xff) - 76.0 - 10.0);
        b = (int) (((NB_RSSI >> 8) & 0xff) - 76.0 - 10.0);
        x = Math.pow(10, a / 20.0);
        y = Math.pow(10, b / 20.0);
        angle = Math.atan(x / y) * 180.0 / 3.1415926535;//计算相位使用
        rssi = Math.sqrt(x * x + y * y);
        rssi = 20.0 * Math.log10(rssi) + 10.0 - 57; // gain 57
        return new double[]{angle, rssi};

    }

    public static double calcPhase(int phase, double angle) {
        int angle_temp;
        angle_temp = phase & 0x1ff;
        switch (angle_temp >> 7) {
//angle 是 rssi 计算中的 angle 值
            case 0:
                break;
            case 1:
                angle = 180 - angle;
                break;
            case 2:
                angle = -180 + angle;
                break;
            case 3:
                angle = -angle;
                break;
            default:
                break;
        }

        return angle;

    }

    public static  int[] calcChannelIndex_Antenna(int value){
        int channelIndex = value & 0x3f;
        int PhysicalAntenna = (value & 0xff) >>6;
        return new int[]{channelIndex,PhysicalAntenna};

    }


    public static int byteArrayToUnsignedInt(byte[] data) {
        int value;
        value = getUint8(data[0]) * 256 + getUint8(data[1]);
        return value;
    }

    public static int byteArrayToTime(byte[] data) {
        int value;

        value = getUint8(data[0]) * 256 * 256 * 256 + getUint8(data[1]) * 256 * 256 + getUint8(data[2]) * 256 + getUint8(data[3]);
        LogUtil.d("byteArrayToUnsignedInt", value);
        return value;
    }


    public static short getUint8(short s) {
        return (short) (s & 0x00ff);
    }
}
