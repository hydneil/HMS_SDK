package com.fmsh.fmshrfid.adapter;

import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.fmsh.base.adapter.BaseRecyclerAdapter;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.fmsh.fmshrfid.sql.DatabaseUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/11/13 14:24
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class DataBaseAdapter extends BaseRecyclerAdapter {


    public DataBaseAdapter(Context context) {
        super(context);
    }
    private HashMap<String,String> dataBaseMap;

    public void setDataBaseMap(HashMap<String, String> dataBaseMap) {
        this.dataBaseMap = dataBaseMap;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_lable_database;
    }

    @Override
    public RecyclerView.ViewHolder getViewHolder(View view) {
        return new ViewHolder(view);
    }

    @Override
    public void setBindHolder(RecyclerView.ViewHolder holder, int position) {
        ViewHolder viewHolder = (ViewHolder) holder;

        InventoryBean inventoryBean = (InventoryBean) mList.get(position);
        viewHolder.tvEpc.setText(inventoryBean.getEpc());
        viewHolder.epcName.setText(inventoryBean.getName());
        viewHolder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.etEpc.setVisibility(View.VISIBLE);
                viewHolder.etEpc.setText(inventoryBean.getName());
                viewHolder.btnCancel.setVisibility(View.VISIBLE);
                viewHolder.btnConfirm.setVisibility(View.VISIBLE);
                viewHolder.btnEdit.setVisibility(View.GONE);
                viewHolder.epcName.setVisibility(View.GONE);



            }
        });


        viewHolder.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.etEpc.setVisibility(View.GONE);
                viewHolder.btnCancel.setVisibility(View.GONE);
                viewHolder.btnConfirm.setVisibility(View.GONE);
                viewHolder.btnEdit.setVisibility(View.VISIBLE);
                viewHolder.epcName.setVisibility(View.VISIBLE);
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(viewHolder.etEpc.getWindowToken(), 0);
            }
        });
        viewHolder.btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = viewHolder.etEpc.getText().toString().trim();
                if(text.isEmpty()){
                    HintDialog.messageDialog(mContext, "名称不能为空");
                    return;
                }
                long l = DatabaseUtils.updateEpcName(mContext, inventoryBean.getEpc(), text);
                if (l == -2) {
                    HintDialog.faileDialog(mContext, "失败，名称重复，请重新输入");
                } else if (l == -1) {
                    HintDialog.faileDialog(mContext, "失败");
                } else {
                    HintDialog.successDialog(mContext, "修改成功");
                    viewHolder.etEpc.setVisibility(View.GONE);
                    viewHolder.btnCancel.setVisibility(View.GONE);
                    viewHolder.btnConfirm.setVisibility(View.GONE);
                    viewHolder.btnEdit.setVisibility(View.VISIBLE);
                    viewHolder.epcName.setVisibility(View.VISIBLE);
                    inventoryBean.setName(text);
                    viewHolder.epcName.setText(inventoryBean.getName());
                    dataBaseMap.put(inventoryBean.getEpc(),text);

                }


            }
        });


    }

    static
    class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_epc)
        TextView tvEpc;
        @BindView(R.id.tv_name)
        TextView tvName;
        @BindView(R.id.epc_name)
        TextView epcName;
        @BindView(R.id.ll_name)
        LinearLayout llName;
        @BindView(R.id.btn_edit)
        Button btnEdit;
        @BindView(R.id.btn_cancel)
        Button btnCancel;
        @BindView(R.id.btn_confirm)
        Button btnConfirm;
        @BindView(R.id.et_epc)
        EditText etEpc;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

    public interface OnEditClickListener{
        void onClick(int position,String text);
    }
    private OnEditClickListener onEditClickListener;

    public void setOnEditClickListener(OnEditClickListener onEditClickListener) {
        this.onEditClickListener = onEditClickListener;
    }
}
