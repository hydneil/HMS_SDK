package com.fmsh.fmshrfid.fragment;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputFilter;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.hdms.HDMSManager;
import com.android.hdms.scanner.ScanManager;
import com.fmsh.base.adapter.BaseRecyclerAdapter;
import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.activity.AccessActivity;
import com.fmsh.fmshrfid.activity.ExFuncActivity;
import com.fmsh.fmshrfid.activity.MainActivity;
import com.fmsh.fmshrfid.adapter.DataBaseAdapter;
import com.fmsh.fmshrfid.adapter.LabelAdapter;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.sql.CustomPopup;
import com.fmsh.fmshrfid.sql.DatabaseHelper;
import com.fmsh.fmshrfid.sql.DatabaseUtils;
import com.fmsh.fmshrfid.utils.ParseUtils;
import com.fmsh.fmshrfid.utils.PowerUtils;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.impl.InputConfirmPopupView;
import com.lxj.xpopup.interfaces.OnCancelListener;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.OnInputConfirmListener;
import com.lxj.xpopup.interfaces.SimpleCallback;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import butterknife.BindView;
import butterknife.OnClick;

import static com.fmsh.fmshrfid.utils.SerialUtil.UsbStatus.USB_CONECTED;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelFragment extends BaseFragment {

    @BindView(R.id.button_access)
    Button btnAccess;
    @BindView(R.id.button_ex_func)
    Button btnExFunc;
//    @BindView(R.id.btn
    @BindView(R.id.btn_inventory)
    Button btnInventory;
    @BindView(R.id.btn_PowerOn)
    Button btnPowerOn;
    @BindView(R.id.btn_PowerOff)
    Button btnPowerOff;
    @BindView(R.id.recycler)
    RecyclerView recycler;
    @BindView(R.id.tv_count)
    TextView tvCount;
    @BindView(R.id.btn_database)
    Button btnDatabase;
    private StringBuffer stringBuffer = new StringBuffer();
    private LabelAdapter labelAdapter;
    private List<InventoryBean> beanList = new ArrayList<>();
    private HashMap<String, InventoryBean> hashMap = new HashMap<>();
    private QMUITipDialog loadingDialog;
    private boolean isInventory = false;
    private HashMap<String,String> dataBaseMap = new HashMap<>();
    private ArrayList<InventoryBean> dataBaseList = new ArrayList<>();

    int value = 1;
    private long total_cnt=0;
    private ReadWriteLock rwl;
    private SoundPool soundPool;
    private int mMusic;
    public HandlerThread handlerThread;
    private Handler handler;
    private InputConfirmPopupView popupView;
    ScanManager mScanManager;
    private void UsBCheckThread(){
        new Thread("UsBCheckThread2"){
            @Override
            public void run(){
                while(true) {
                    //Log.i("JNILOG", "getSerialUtilStatus="+MainActivity.serial_port.getSerialUtilStatus());
                    try {
                        if(USB_CONECTED !=MainActivity.serial_port.getSerialUtilStatus())
                        {
                            Log.i("JNILOG", "LabelFragment finish.");
                            onDestroy();
                        }
                        sleep(1000);
                    } catch (Exception e) {
                        Log.i("JNILOG", "UsBCheckThread Exception"+e);
                        //e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label;
    }


    @Override
    protected void initView(View view) {
        mScanManager = (ScanManager) HDMSManager.getInstance().getModuleManager(HDMSManager.MODULE_TYPE.SCANNER);
        labelAdapter = new LabelAdapter(mContext);
        recycler.setLayoutManager(new LinearLayoutManager(mContext));
        recycler.setAdapter(labelAdapter);
        loadingDialog = HintDialog.loadingDialog(mContext);
        soundPool = new SoundPool(1, AudioManager.STREAM_SYSTEM, 0);
        mMusic = soundPool.load(mContext, R.raw.beep, 1);
        handlerSound();
        rwl = new ReentrantReadWriteLock();
        UsBCheckThread();
        CtrlButtons(false);
        ButtonCfg(btnPowerOn,true);


    }
    private void handlerSound() {
        handlerThread = new HandlerThread("sound");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                sub_sound();
                soundPool.play(mMusic, 1, 1, 0, 0, 1);
                SystemClock.sleep(100);
            }
        };
    }

    private void add_sound()
    {
        rwl.writeLock().lock();
        total_cnt++;
        rwl.writeLock().unlock();
    }
    private void sub_sound()
    {
        rwl.writeLock().lock();
        total_cnt--;
        rwl.writeLock().unlock();
    }
    private long get_sound()
    {
        long tmp;
        rwl.readLock().lock();
        tmp = total_cnt;
        rwl.readLock().unlock();
        return tmp;
    }

    private void InitInventory()
    {//无限盘点
        RfidLibrary.InitInventory();
    }
    @Override
    protected void initData() {
        InitInventory();
        queryAll();
        btnDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                queryAll();
                CustomPopup  customPopup = new CustomPopup(mContext,dataBaseList);

                new XPopup.Builder(getContext())
                        .setPopupCallback(new SimpleCallback(){
                            @Override
                            public void onShow(BasePopupView popupView) {
                                super.onShow(popupView);

                                DataBaseAdapter dataBaseAdapter = customPopup.getDataBaseAdapter();
                                if(dataBaseAdapter != null){
                                    dataBaseAdapter.setDataBaseMap(dataBaseMap);

                                    dataBaseAdapter.setOnItemLongClickListener(new BaseRecyclerAdapter.OnItemLongClickListener() {
                                        @Override
                                        public void itemLongClickListener(int position) {
                                            InventoryBean inventoryBean = dataBaseList.get(position);

                                            new XPopup.Builder(getContext())
                                                    .isDestroyOnDismiss(true)
                                                    .asConfirm("", "是否要删除此数据？" ,
                                                            "取消", "确定",
                                                            new OnConfirmListener() {
                                                                @Override
                                                                public void onConfirm() {
                                                                    DatabaseUtils.deleteEpcName(mContext,inventoryBean.getEpc());
                                                                    dataBaseList.remove(inventoryBean);
                                                                    customPopup.setmData(dataBaseList);
                                                                    customPopup.changeView();

                                                                }
                                                            }, null, false).show();

                                        }
                                    });

                                }
                            }

                            @Override
                            public void onDismiss(BasePopupView popupView) {
                                super.onDismiss(popupView);
                                // 更新已经盘点标签的数据
                                for (int i = 0; i < beanList.size(); i++) {
                                    InventoryBean inventoryBean = beanList.get(i);
                                    if(dataBaseMap.containsKey(inventoryBean.getEpc())){
                                        String name = dataBaseMap.get(inventoryBean.getEpc());
                                        inventoryBean.setName(name);
                                    }

                                }
                                labelAdapter.notifyDataSetChanged();
                            }
                        })
                        .asCustom(customPopup)
                        .show();


            }
        });
        labelAdapter.setOnItemLongClickListener(new BaseRecyclerAdapter.OnItemLongClickListener() {
            @Override
            public void itemLongClickListener(int position) {

                InventoryBean inventoryBean = beanList.get(position);
                String epc = inventoryBean.getEpc();
                String title = "设置名称";
                String epcName = DatabaseUtils.queryEpcName(mContext,epc);
                boolean isAdd = true;
                if (epcName != null) {
                    title = "修改名称";
                    isAdd = false;
                }
                boolean finalIsAdd = isAdd;

                popupView = new XPopup.Builder(getContext())
                        .isDestroyOnDismiss(true) //对于只使用一次的弹窗对象，推荐设置这个
                        .isDarkTheme(false).autoDismiss(false)
                        .autoOpenSoftInput(false)
                        .autoFocusEditText(false) //是否让弹窗内的EditText自动获取焦点，默认是true
                        .setPopupCallback(new SimpleCallback(){
                            @Override
                            public void onShow(BasePopupView p) {
                                super.onShow(p);
                                EditText editText = popupView.getEditText();
                                if(editText != null){
                                    // 设置限制输入最大长度
                                    editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
                                }
                            }

                            @Override
                            public void onDismiss(BasePopupView p) {
                                super.onDismiss(p);

                                DatabaseHelper.getInstance(mContext).closeLink();

                            }
                        })
                        .asInputConfirm(title, "", epcName, "请输入标签名称",
                                new OnInputConfirmListener() {
                                    @Override
                                    public void onConfirm(String text) {
                                        if (text.isEmpty()) {

                                            HintDialog.messageDialog(mContext, "名称不能为空");
                                            return;
                                        }
                                        long l;
                                        if (finalIsAdd) {
                                            l = DatabaseUtils.addEpcName(mContext,epc, text);
                                            LogUtil.d("addEpcName", l);
                                        } else {
                                            l = DatabaseUtils.updateEpcName(mContext,epc, text);
                                            LogUtil.d("updateEpcName", l);
                                        }
                                        if (l == -2) {
                                            HintDialog.faileDialog(mContext, "失败，名称重复，请重新输入");
                                        } else if (l == -1) {
                                            HintDialog.faileDialog(mContext, "失败");
                                        } else {
                                            HintDialog.successDialog(mContext, "设置成功");
                                            inventoryBean.setName(text);
                                            dataBaseMap.put(inventoryBean.getEpc(),text);
                                            labelAdapter.notifyItemChanged(position);
                                            popupView.dismiss();
                                        }
                                    }
                                }, new OnCancelListener() {
                                    @Override
                                    public void onCancel() {
                                        EditText editText = popupView.getEditText();
                                        if(editText != null){
                                            // 设置限制输入最大长度
                                            editText.clearFocus();
                                            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
                                        }
                                    }
                                },0);
                popupView.show();
            }
        });

    }

    /**
     * 查询所有数据
     *
     */
    private void queryAll() {
        dataBaseMap.clear();
        dataBaseList.clear();
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(mContext);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openReadLink();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+DatabaseHelper.getTableName()+"",null);
//        Cursor cursor = sqLiteDatabase.query(DatabaseHelper.getTableName(), null, null, null, null, null, null);
        while (cursor.moveToNext()){
            String epc = cursor.getString(0);
            String name = cursor.getString(1);
            dataBaseMap.put(epc,name);
            InventoryBean inventoryBean = new InventoryBean();
            inventoryBean.setName(name);
            inventoryBean.setEpc(epc);
            dataBaseList.add(inventoryBean);
        }
        databaseHelper.closeLink();
        LogUtil.d("database",dataBaseMap.size());

    }
private void CtrlButtons(boolean en)
{
    btnAccess.setEnabled(en);
    btnInventory.setEnabled(en);
    btnExFunc.setEnabled(en);
    btnPowerOn.setEnabled(en);
    btnPowerOff.setEnabled(en);
    int colr = en ? Color.WHITE : Color.GRAY;
    btnAccess.setTextColor(colr);
    btnInventory.setTextColor(colr);
    btnExFunc.setTextColor(colr);
    btnPowerOn.setTextColor(colr);
    btnPowerOff.setTextColor(colr);
}
    private void ButtonCfg(Button but,boolean en)
    {
        but.setEnabled(en);
        but.setTextColor(en ? Color.WHITE : Color.GRAY);
    }

    @OnClick({R.id.btn_inventory, R.id.btn_PowerOn, R.id.btn_PowerOff, R.id.button_access, R.id.button_ex_func})
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_inventory:
                if (isInventory) {
                    isInventory = false;
                    value = 1;
                    int ret = RfidLibrary.stopInventory();
                    handlerThread.quit();
                    if (ret == 1) {
                        btnInventory.setText("开始盘点");
                        CtrlButtons(true);
                    } else {
                        HintDialog.faileDialog(mContext, "停止失败");
                    }
                } else {
                    handlerSound();
                    isInventory = true;
                    btnInventory.setText("停止盘点");
                    stringBuffer.setLength(0);
                    beanList.clear();
                    hashMap.clear();
                    labelAdapter.setList(beanList);
                    //loadingDialog.show();
                    tvCount.setText("加载中...");
                    RfidLibrary.stopInventory();
                    RfidLibrary.Inventory(value, new RfidLibrary.CallbackInterface() {
                        @Override
                        public void onCallback(byte[] message) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //loadingDialog.dismiss();
                                }
                            });
                            parseData(message);
                        }
                    });
                    CtrlButtons(false);
                    ButtonCfg(btnInventory,true);
                }
                break;
            case R.id.btn_PowerOn:
                beanList.clear();
                hashMap.clear();
                labelAdapter.setList(beanList);
                int RadioOpenstatus = MainActivity.OpenRadio();
                tvCount.setText("Power On,status = " + RadioOpenstatus);
                CtrlButtons(false);
                ButtonCfg(btnInventory,true);
                ButtonCfg(btnPowerOff,true);
                break;
            case R.id.btn_PowerOff:
                beanList.clear();
                hashMap.clear();
                labelAdapter.setList(beanList);
                RfidLibrary.FmshRadioClose();
                PowerUtils.powerCtrl(PowerUtils.VCC_RFID_DOWN);
                tvCount.setText("Power Off,status = 0");
                CtrlButtons(false);
                ButtonCfg(btnPowerOn,true);
                break;
            case R.id.button_access:
                ArrayList<String> s_epcList = new ArrayList<>();
                for (int i = 0; i < beanList.size(); i++) {
                    s_epcList.add(beanList.get(i).getEpc());
                }
                Intent it = new Intent(this.getActivity(), AccessActivity.class);
                it.putStringArrayListExtra("epcArray", s_epcList);
                startActivity(it);
                break;
            case R.id.button_ex_func:
                ArrayList<String> e_epcList = new ArrayList<>();
                for (int i = 0; i < beanList.size(); i++) {
                    e_epcList.add(beanList.get(i).getEpc());
                }
                Intent e_it = new Intent(this.getActivity(), ExFuncActivity.class);
                e_it.putStringArrayListExtra("epcArray", e_epcList);
                startActivity(e_it);
                break;
        }

    }

    private void parseData(byte[] data) {
        //LogUtil.d(FMUtil.byteToHex(data));

        InventoryBean inventoryBean = ParseUtils.parsePacket(data);
        if(get_sound() < 3) {
            add_sound();
            handler.sendMessage(handler.obtainMessage());
        }
        if (inventoryBean.getEpc() != null) {
            if (!hashMap.containsKey(inventoryBean.getEpc())) {
                String name = dataBaseMap.get(inventoryBean.getEpc());
                inventoryBean.setName(name);
                hashMap.put(inventoryBean.getEpc(), inventoryBean);
                beanList.add(inventoryBean);
                //LogUtil.d(inventoryBean.toString());
            } else {
                InventoryBean bean = hashMap.get(inventoryBean.getEpc());
                if (bean != null) {
                    bean.setPhase(inventoryBean.getPhase());
                    bean.setRSSI(inventoryBean.getRSSI());
                    bean.setMS_Ctr(inventoryBean.getMS_Ctr());
                    bean.setChIdx(inventoryBean.getChIdx());
                    bean.setPhyAtn(inventoryBean.getPhyAtn());
                    bean.setLabelCount(bean.getLabelCount() + 1);
                }
            }
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvCount.setText("盘点到标签数量:" + beanList.size());
                    labelAdapter.setList(beanList);
                }
            });
        }
    }

    @Override
    public String getTitle() {
        return "标签";
    }

    @Override
    public void onResume() {
        super.onResume();
        if(mScanManager != null) {
            mScanManager.disableScanKey(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if(mScanManager != null) {
            mScanManager.disableScanKey(false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (isInventory) {
            isInventory = false;
            RfidLibrary.stopInventory();
            SystemClock.sleep(200);
        }
        FragmentActivity fa = getActivity();
        if(null != fa)
        {
            fa.finish();
        }
    }
    public boolean dispatchKeyEvent(KeyEvent event){
        Log.d(TAG, "dispatchKeyEvent "+event.getKeyCode());
        if(event.getKeyCode() == 566 && event.getAction() == KeyEvent.ACTION_UP) {
            if (isInventory) {
                isInventory = false;
                value = 1;
                int ret = RfidLibrary.stopInventory();
                handlerThread.quit();
                if (ret == 1) {
                    btnInventory.setText("开始盘点");
                    CtrlButtons(true);
                } else {
                    HintDialog.faileDialog(mContext, "停止失败");
                }
            } else {
                handlerSound();
                isInventory = true;
                btnInventory.setText("停止盘点");
                stringBuffer.setLength(0);
                beanList.clear();
                hashMap.clear();
                labelAdapter.setList(beanList);
                //loadingDialog.show();
                tvCount.setText("加载中...");
                RfidLibrary.stopInventory();
                RfidLibrary.Inventory(value, new RfidLibrary.CallbackInterface() {
                    @Override
                    public void onCallback(byte[] message) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //loadingDialog.dismiss();
                            }
                        });
                        parseData(message);
                    }
                });
                CtrlButtons(false);
                ButtonCfg(btnInventory,true);
            }
        }
        return false;
    }
}
