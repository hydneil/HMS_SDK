package com.fmsh.fmshrfid.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.fmsh.base.utils.LogUtil;
import com.fmsh.fmshrfid.bean.InventoryBean;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/11/13 16:21
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class DatabaseUtils {


    /**
     * 添加 数据 epc 对应的名称
     *
     * @param epc
     * @param name
     * @return 返回结果 失败返回-1, -2,代表名称已存在 成功返回1
     */
    public static long addEpcName(Context context, String epc, String name) {
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(context);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openWriteLink();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", epc);
        contentValues.put("name", name);
        String queryName = queryName(context,epc, name);
        if (queryName == null) {
            return sqLiteDatabase.insert(DatabaseHelper.getTableName(), null, contentValues);
        } else {
            return -2;
        }
    }



    /**
     * 根据epc 查询 名称
     *
     * @param epc
     * @return 不存在返回 null
     */
    public static  String queryEpcName(Context context,String epc) {
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(context);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openReadLink();
        Cursor cursor = sqLiteDatabase.query(DatabaseHelper.getTableName(), null, "id=?", new String[]{String.valueOf(epc)}, null, null, null);
        boolean toFirst = cursor.moveToFirst();
        if (toFirst) {
            return cursor.getString(1);
        } else {
            return null;
        }
    }

    /**
     * 根据name 查询 名称
     *
     * @param name
     * @return 不存在返回 null
     */
    public static  String queryName(Context context,String epc, String name) {
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(context);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openReadLink();
        Cursor cursor = sqLiteDatabase.query(DatabaseHelper.getTableName(), null, "name=? and id <>?", new String[]{String.valueOf(name), String.valueOf(epc)}, null, null, null);
        boolean toFirst = cursor.moveToFirst();
        if (toFirst) {
            return cursor.getString(1);
        } else {
            return null;
        }
    }

    /**
     * 根据 epc 更新 名称
     *
     * @param epc
     * @param name
     * @return 返回结果 失败返回-1， -2,代表名称已存在 成功返回1
     */
    public static  long updateEpcName(Context context,String epc, String name) {
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(context);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openWriteLink();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", epc);
        contentValues.put("name", name);
        contentValues.put("time", System.currentTimeMillis());
        String queryName = queryName(context,epc, name);
        if (queryName == null) {
            return sqLiteDatabase.update(DatabaseHelper.getTableName(), contentValues, "id=?", new String[]{String.valueOf(epc)});
        } else {
            return -2;
        }

    }

    /**
     * 根据epc 删除
     * @param epc
     * @return 返回结果
     */
    public static long deleteEpcName(Context context,String epc){
        DatabaseHelper databaseHelper = DatabaseHelper.getInstance(context);
        SQLiteDatabase sqLiteDatabase = databaseHelper.openWriteLink();
        int delete = sqLiteDatabase.delete(DatabaseHelper.getTableName(), "id=?", new String[]{epc});
        databaseHelper.closeLink();
        LogUtil.d("deleteEpcName",delete);
        return delete;

    }
}
