package com.fmsh.fmshrfid.fragment;

import android.media.SoundPool;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.activity.MainActivity;
import com.fmsh.fmshrfid.adapter.LabelAdapter;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelReadFragment extends BaseFragment {
    @BindView(R.id.button_read)
    Button btnRead;
    @BindView(R.id.rd_text)
    EditText readTextView;
    @BindView(R.id.tv_readcount)
    TextView tvReadCount;
    @BindView(R.id.rd_epc_filter_spinner)
    Spinner epc_filter_Spinner;
    @BindView(R.id.rd_bank_spinner)
    Spinner bank_Spinner;
    @BindView(R.id.rd_password)
    EditText rd_pwd;
    @BindView(R.id.rd_startaddr)
    EditText rd_start_addr;
    @BindView(R.id.rd_length)
    EditText rd_len;

    private StringBuffer stringBuffer = new StringBuffer();
//    private LabelAdapter labelAdapter;
    private ArrayList<String> epcList;
    private HashMap<String,InventoryBean> hashMap = new HashMap<>();
    private QMUITipDialog loadingDialog;
    private boolean isInventory = false;
    int cur_proto;

    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_read;
    }

    private void epc_filter_init(){
        if(epcList.size()>0)
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_filter_Spinner.setAdapter(epc_filter_adapter);
        }
    }
    private void bank_init(){
        String[] bankArray = {"Reserve","EPC","TID","USER"};
        ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, bankArray);
        epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bank_Spinner.setAdapter(epc_filter_adapter);
        bank_Spinner.setSelection(3);
    }
    @Override
    protected void initView(View view) {
        epc_filter_init();
        bank_init();
        loadingDialog = HintDialog.loadingDialog(mContext);
        cur_proto = RfidLibrary.GetCurProto();
    }

    @Override
    protected void initData() {

    }
    private int OnSetMatchRegister(){
        int stat = 0;
        if(epcList.size()>0) {
            String match_str = epcList.get(epc_filter_Spinner.getSelectedItemPosition());
            stat = RfidLibrary.SetmatchRule(cur_proto, match_str, match_str.length());
        }
        return stat;
    }
    private void OnBnClickedBtnRead(){
        int stat = 0;
        readTextView.setText("");
        tvReadCount.setText("");
        int bank = bank_Spinner.getSelectedItemPosition();
        String buff_str ="";
        String stroffset = rd_start_addr.getText().toString().trim();
        if ("".equals(stroffset)) {
            HintDialog.messageDialog(mContext, "请设置起始地址");
            return;
        }
        String strwordcount = rd_len.getText().toString().trim();
        if ("".equals(strwordcount)) {
            HintDialog.messageDialog(mContext, "请设置读取字数");
            return;
        }
        String strpasswd = rd_pwd.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置读口令");
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            return;
        }
        int offset = Integer.parseInt(stroffset);
        int wordcount = Integer.parseInt(strwordcount);
        int passwd = Integer.parseInt(strpasswd);
        byte[] pbuffer = new byte[wordcount * 2 + 6];
        int real_bank = RfidLibrary.switch_bank_ind(cur_proto, bank);
        if (0xFF == real_bank)
        {
            HintDialog.messageDialog(mContext, "读标签失败,bank错误。");
            return;
        }
        if(0 != (stat = RfidLibrary.ReadTag(real_bank, offset, pbuffer, wordcount, passwd)))
        {
            buff_str = String.format("读标签失败,status=%d", stat);
            HintDialog.messageDialog(mContext, buff_str);
            return;
        }
        byte tag_stat = pbuffer[0];
        byte operat_stat = pbuffer[1];
        if (0 != tag_stat)
        {
            buff_str = String.format("读标签失败,Tag status = 0x%02X", tag_stat);
            HintDialog.messageDialog(mContext, buff_str);
        }
        else if (0 != operat_stat)
        {
            buff_str = String.format("读标签失败,Operate status = 0x%02X", operat_stat);
            HintDialog.messageDialog(mContext, buff_str);
        }
        else
        {
            for(int i=1;i<=wordcount;i++)
            {

                buff_str += String.format("%02X",pbuffer[i*2+1]);
                buff_str += String.format("%02X",pbuffer[i*2]);
            }
            readTextView.setText(buff_str);
        }
       return;
}
    @OnClick({R.id.button_read })
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.button_read:
                OnBnClickedBtnRead();
                break;
        }

    }

//    private void parseData(byte[] data) {
//        LogUtil.d(FMUtil.byteToHex(data));
//
//        InventoryBean inventoryBean = ParseUtils.parsePacket(data);
//        handler.sendMessage(handler.obtainMessage());
//        if (inventoryBean.getEpc() != null) {
//            if (!hashMap.containsKey(inventoryBean.getEpc())) {
//                hashMap.put(inventoryBean.getEpc(),inventoryBean);
//                beanList.add(inventoryBean);
//                LogUtil.d(inventoryBean.toString());
//            }else {
//                InventoryBean bean = hashMap.get(inventoryBean.getEpc());
//                if (bean!= null){
//                    bean.setPhase(inventoryBean.getPhase());
//                    bean.setRSSI(inventoryBean.getRSSI());
//                    bean.setMS_Ctr(inventoryBean.getMS_Ctr());
//                    bean.setChIdx(inventoryBean.getChIdx());
//                    bean.setPhyAtn(inventoryBean.getPhyAtn());
//                    bean.setLabelCount(bean.getLabelCount()+1);
//                }
//            }
//            getActivity().runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    tvReadCount.setText("盘点到标签数量:" + beanList.size());
//                    labelAdapter.setList(beanList);
//
//                }
//            });
//        }
//    }

    @Override
    public String getTitle() {
        return "读标签";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
