package com.fmsh.fmshrfid.fragment;

import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.base.utils.SpUtils;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import butterknife.BindView;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class SettingFragment extends BaseFragment {
    @BindView(R.id.seekbar_power)
    SeekBar seekbarPower;
    @BindView(R.id.tv_power)
    TextView tvPower;
    @BindView(R.id.et_freq)
    EditText etFreq;
    @BindView(R.id.btn_time)
    Button btnTime;
    @BindView(R.id.spinner)
    Spinner spinner;
    @BindView(R.id.spin_target)
    Spinner spinner_target;
    @BindView(R.id.spin_session)
    Spinner spinner_session;
    @BindView(R.id.but_set_tar_ses)
    Button btn_set_tar_ses;
    @BindView(R.id.but_get_tar_ses)
    Button btn_get_tar_ses;
    @BindView(R.id.btn_setting)
    Button btnSetting;
    @BindView(R.id.profile_spinner)
    Spinner profileSpinner;
    @BindView(R.id.btn_recover)
    Button btnRecover;
    @BindView(R.id.et_on)
    EditText etOn;
    @BindView(R.id.et_off)
    EditText etOff;
    @BindView(R.id.btn_setting_power)
    Button btnSettingPower;
    @BindView(R.id.btn_Profile)
    Button btnProfile;
    private String[] Region = {"Div 48(FCC)", "Div 120(EISI)", "Div 96(CHINA0)", "Div 96(CHINA1)"};
    private String[] str_target = {"A","B"};
    private String[] str_session = {"S0","S1","S2","S3"};

    private Integer[] profileArray = new Integer[33];
    private int currentRegion;
    private int currentTarget;
    private  int currentSession;
    private QMUITipDialog loadingDialog;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_setting;
    }

    @Override
    protected void initView(View view) {
        try {
            loadingDialog = HintDialog.loadingDialog(mContext);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, Region);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);

            ArrayAdapter<String> targetadapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, str_target);
            targetadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_target.setAdapter(targetadapter);
            ArrayAdapter<String> sessionadapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, str_session);
            sessionadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_session.setAdapter(sessionadapter);

            seekbarPower.setMax(330);
            for (int i = 0; i < 33; i++) {
                profileArray[i] = i;
            }
            ArrayAdapter<Integer> adapter1 = new ArrayAdapter<Integer>(mContext, android.R.layout.simple_spinner_item, profileArray);
            adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            profileSpinner.setAdapter(adapter1);

            int power = SpUtils.getIntValue(mContext, "power", 0);
            seekbarPower.setProgress(power);
            tvPower.setText(String.valueOf(power));

            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String freq = SpUtils.getStringValue(mContext, "freq", "915.25");
                        etFreq.setText(freq);
                        currentRegion = SpUtils.getIntValue(mContext, "Region", 0);
                        spinner.setSelection(currentRegion);
                        int[] ints = RfidLibrary.GetFreq();
                        etFreq.setText(String.valueOf(ints[0] / 1000.00));
                        spinner.setSelection(ints[1]);

                        byte[]data = RfidLibrary.readReg(new byte[]{0x09, 0x00});
                        if((((char)data[3]) & 0x10) == 0x10)
                        {
                            currentTarget = 1;
                        }
                        currentSession = 0x03&((char)(((char)data[3])>>5));
                        spinner_target.setSelection(currentTarget);
                        spinner_session.setSelection(currentSession);

                        int[] nPort = new int[1];
                        int[]nPower = new int[1];
                        int[]dwelltime = new int[1];
                        int sta = RfidLibrary.GetAntenna(nPort, nPower, dwelltime);
                        if(sta ==0 )
                        {
                            seekbarPower.setProgress(nPower[0]);
                            tvPower.setText(String.valueOf(nPower[0]));
                        }

                        int profile = RfidLibrary.GetCurrentLinkProfile();
                        if (profile > profileArray.length) {
                            profile = 0;
                        }
                        profileSpinner.setSelection(profile);

                        byte[] bytes = RfidLibrary.readOemReg(new byte[]{0x00, (byte) 0xB5});
                        //Log.i("JNILOG", "readOemReg: "+FMUtil.byteToHex(bytes));
                        if (bytes != null && bytes.length == 4) {
                            int end = ((bytes[1]&0xFF) >> 1)  + (bytes[0] & 0xFF) * 128;
                            etOff.setText(String.valueOf(end));
                            int start = ((bytes[3]& 0xFF) >> 1 ) + (bytes[2] & 0xFF) * 128;
                            etOn.setText(String.valueOf(start));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initData() {
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentRegion = position;
                SpUtils.putIntValue(mContext, "Region", position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        profileSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpUtils.putIntValue(mContext, "profile", position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner_target.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentTarget = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner_session.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentSession = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        seekbarPower.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int progress = seekBar.getProgress();
                SpUtils.putIntValue(mContext, "power", progress);
                tvPower.setText(String.valueOf(progress));
            }
        });

        btnSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingDialog.show();
                Thread myThread = new Thread() {
                    @Override
                    public void run() {
                        super.run();
                        String freq = etFreq.getText().toString().trim();
                        if ("".equals(freq)) {
                            HintDialog.messageDialog(mContext, "请设置频率值");
                            return;
                        }
                        float aFloat = Float.parseFloat(freq);
                        int value = (int) (aFloat * 1000);
                        int ret = RfidLibrary.SetFreq(value, currentRegion);
                        LogUtil.d(ret);

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                loadingDialog.dismiss();
                                if (ret == 0) {
                                    HintDialog.successDialog(mContext, "设置成功");
                                } else {
                                    HintDialog.faileDialog(mContext, "设置失败");
                                }
                            }
                        });

                    }
                };
                myThread.start();
            }
        });

        btnSettingPower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sta = RfidLibrary.SetAntenna(3, 0, seekbarPower.getProgress(), 0);
                if(sta !=0 )
                {
                    HintDialog.successDialog(mContext, "设置失败");

                }
                else {
                    HintDialog.successDialog(mContext, "设置成功");

                }
            }
        });
        btn_set_tar_ses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                byte[]data = RfidLibrary.readReg(new byte[]{0x09, 0x00});
                data[3] =  (byte)((char)data[3] & (~0x70));
                if(currentTarget==1)
                {
                    data[3] = (byte)(data[3]|0x10);
                }
                data[3]= (byte)((char)data[3] | (char)((currentSession&0x03)<<5));
                int sta = RfidLibrary.writeReg(new byte[]{0x09, 0x00},data);
                if(sta !=0 )
                {
                    HintDialog.successDialog(mContext, "设置失败");

                }
                else {
                    HintDialog.successDialog(mContext, "设置成功");

                }
            }
        });
        btn_get_tar_ses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                byte[]data = RfidLibrary.readReg(new byte[]{0x09, 0x00});
                if((((char)data[3]) & 0x10) == 0x10)
                {
                    currentTarget = 1;
                }
                currentSession = 0x03&((char)(((char)data[3])>>5));
                spinner_target.setSelection(currentTarget);
                spinner_session.setSelection(currentSession);
            }
        });
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RfidLibrary.SetCurrentLinkProfile(profileSpinner.getSelectedItemPosition());
                HintDialog.successDialog(mContext, "设置成功");
            }
        });

        btnRecover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ret = RfidLibrary.writeReg(new byte[]{0x01, 0x0D}, new byte[]{0});
                LogUtil.d(ret);
                if (ret == 0) {
                    HintDialog.successDialog(mContext, "设置成功");
                } else {
                    HintDialog.faileDialog(mContext, "设置失败");
                }
            }
        });

        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String start = etOn.getText().toString().trim();
                String end = etOff.getText().toString().trim();
                if (start.isEmpty()) {
                    HintDialog.messageDialog(mContext, "请设置开始时间");
                    return;
                }
                if (end.isEmpty()) {
                    HintDialog.messageDialog(mContext, "请设置结束时间");
                    return;
                }
                int startTime = Integer.parseInt(start) << 1 | 0x01; //Bits 0  0表示不使用,1使用 ,1默认使用
                int endTime = Integer.parseInt(end) << 1 | 0x01; // Bits 16  0表示不使用,1使用 ,1默认使用
                byte[] time = {(byte) (endTime >> 8 & 0xff), (byte) (endTime & 0xff),
                        (byte) (startTime >> 8 & 0xff), (byte) (startTime & 0xff)};
                byte[] address = new byte[]{0x00, (byte) 0xB5};
                LogUtil.d(FMUtil.byteToHex(address));
                LogUtil.d(FMUtil.byteToHex(time));
                int sta = RfidLibrary.writeOemReg(address, time);
                if(0 == sta){
                    HintDialog.successDialog(mContext, "设置成功");
                }
                else {
                    HintDialog.successDialog(mContext, "设置失败:"+ sta);
                }

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public String getTitle() {
        return "设置";
    }
}
