package com.fmsh.fmshrfid.adapter;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fmsh.fmshrfid.R;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView UsbLogView;
    public MyViewHolder(@NonNull View itemview){
        super(itemview);
        UsbLogView = itemview.findViewById(R.id.LogView);
    }
}
