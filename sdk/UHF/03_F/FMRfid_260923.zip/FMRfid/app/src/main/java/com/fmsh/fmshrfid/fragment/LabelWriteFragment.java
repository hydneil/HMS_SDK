package com.fmsh.fmshrfid.fragment;

import android.media.SoundPool;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.activity.MainActivity;
import com.fmsh.fmshrfid.adapter.LabelAdapter;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelWriteFragment extends BaseFragment {
    @BindView(R.id.button_write)
    Button btnWrite;
    @BindView(R.id.tv_writecount)
    TextView tvWriteCount;
    @BindView(R.id.wr_epc_filter_spinner)
    Spinner epc_filter_Spinner;
    @BindView(R.id.wr_bank_spinner)
    Spinner bank_Spinner;
    @BindView(R.id.Data)
    EditText wr_data;
    @BindView(R.id.wr_password)
    EditText wr_pwd;
    @BindView(R.id.wr_startaddr)
    EditText wr_start_addr;
    @BindView(R.id.wr_length)
    EditText wr_len;
    private StringBuffer stringBuffer = new StringBuffer();
    private LabelAdapter labelAdapter;
    private ArrayList<String> epcList;
    private HashMap<String,InventoryBean> hashMap = new HashMap<>();
    private QMUITipDialog loadingDialog;
    private boolean isInventory = false;

    int value = 1;
    int cur_proto;
    private SoundPool soundPool;
    private int mMusic;
    public HandlerThread handlerThread;
    private Handler handler;

    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
    }
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_write;
    }

    private void epc_filter_init(){
        if(epcList.size()>0)
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_filter_Spinner.setAdapter(epc_filter_adapter);
        }
    }
    private void bank_init(){
        String[] bankArray = {"Reserve","EPC","TID","USER"};
        ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, bankArray);
        epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bank_Spinner.setAdapter(epc_filter_adapter);
        bank_Spinner.setSelection(3);
    }

    @Override
    protected void initView(View view) {
        epc_filter_init();
        bank_init();
        loadingDialog = HintDialog.loadingDialog(mContext);
        cur_proto = RfidLibrary.GetCurProto();
        //soundPool = new SoundPool(1, AudioManager.STREAM_SYSTEM, 0);

        //mMusic = soundPool.load(mContext, R.raw.beep, 1);

        //handlerSound();
    }

//    private void handlerSound(){
//        handlerThread = new HandlerThread("sound");
//        handlerThread.start();
//        handler = new Handler(handlerThread.getLooper()){
//            @Override
//            public void handleMessage(@NonNull Message msg) {
//                super.handleMessage(msg);
//                soundPool.play(mMusic, 1, 1, 0, 0, 1);
//                SystemClock.sleep(100);
//            }
//        };
//
//    }



    @Override
    protected void initData() {

    }

    @OnClick({R.id.button_write })
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.button_write:
                OnBnClickedBtnWrite();
                break;
        }

    }
    private int OnSetMatchRegister(){
        int stat = 0;
        if(epcList.size()>0) {
            String match_str = epcList.get(epc_filter_Spinner.getSelectedItemPosition());
            stat = RfidLibrary.SetmatchRule(cur_proto, match_str, match_str.length());
        }
        return stat;
    }
    private void OnBnClickedBtnWrite(){
        int stat = 0;
        int bank = bank_Spinner.getSelectedItemPosition();

        String stroffset = wr_start_addr.getText().toString().trim();
        if ("".equals(stroffset)) {
            HintDialog.messageDialog(mContext, "请设置起始地址");
            return;
        }
        String strwordcount = wr_len.getText().toString().trim();
        if ("".equals(strwordcount)) {
            HintDialog.messageDialog(mContext, "请设置读取字数");
            return;
        }
        String strpasswd = wr_pwd.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置读口令");
            return;
        }
        String strdata = wr_data.getText().toString().trim();
        if ("".equals(strdata)) {
            HintDialog.messageDialog(mContext, "请设置写入数据");
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            return;
        }
        int offset = Integer.parseInt(stroffset);
        int wordcount = Integer.parseInt(strwordcount);
        int passwd = Integer.parseInt(strpasswd);

        byte[] wr_buf = new byte[strdata.length()/2];
        for(int i=0;i<wr_buf.length/2;i++)
        {
            int word_data = Integer.parseInt(strdata.substring(i*4, i*4+4),16);
            wr_buf[i*2+1] = (byte)(word_data&0xFF);
            wr_buf[i*2] = (byte)((word_data>>8)&0xFF);
        }
        int real_bank = RfidLibrary.switch_bank_ind(cur_proto, bank);
        if (0xFF == real_bank)
        {
            HintDialog.messageDialog(mContext, "写标签失败");
            return;
        }
        if(0 == (stat = RfidLibrary.WriteTag(real_bank, offset, wr_buf, wordcount, passwd)))
        {
            Calendar ca = Calendar.getInstance();
            String Date_Chuo = String.format("%d-%d-%d %d:%d:%d",ca.get(Calendar.YEAR),
                    ca.get(Calendar.MONTH)+1, ca.get(Calendar.DAY_OF_MONTH),ca.get(Calendar.HOUR_OF_DAY)
                    , ca.get(Calendar.MINUTE),ca.get(Calendar.SECOND));
            tvWriteCount.setText(Date_Chuo+":写入" + wordcount+"word 数据:");
        }
        else
        {
            HintDialog.messageDialog(mContext, "写标签失败:stat=" + stat);
        }
        return;
    }

    @Override
    public String getTitle() {
        return "写标签";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
