package com.fmsh.fmshrfid.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.Constant;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import butterknife.BindView;
import butterknife.OnClick;
/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelFreqCfgFragment extends BaseFragment {
    @BindView(R.id.region_spinner)
    Spinner RegionSpinner;
    ListView freqList;
    int m_region;
    FREQ_CFG m_freqCfgDats[];
    private QMUITipDialog loadingDialog;
    private FreqConfig fc[];

    private Handler handler;
    private Lock lock=new ReentrantLock();
    String[] data;
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_freq_cfg;
    }

    private void handlerReadfreqCfg(){
        HandlerThread handlerThread = new HandlerThread("read_freq_cfg");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                lock.lock();
                switch(msg.what)
                {
                    case Constant.MSB_BOX_INIT:
                        loadingDialog = HintDialog.loadingDialog(mContext);
                        break;
                    case Constant.MSG_BOX_SHOW:
                        OnShowWaittingMsg();
                        break;
                    case Constant.MSG_BOX_HIDE:
                        OnHideWaittingMsg();
                        break;
                    case Constant.MSG_BOX_SUCCESS:
                        OnShowSuccessMsg(msg.getData().getString("success_str"));
                        break;
                    case Constant.MSG_BOX_ERR:
                        OnShowErrMsg(msg.getData().getString("err_str"));
                        break;
                }
                lock.unlock();
            }
        };
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        View Pager = inflater.inflate(getLayoutId(),container,false);
        freqList = Pager.findViewById(R.id.freq_list);
        return Pager;
    }

    @Override
    protected void initView(View view) {
    }

    @Override
    protected void initData() {
        fc  =new FreqConfig[4];
        fc[0] = new FreqConfig_FCC((float)902.75, (float)0.5, 0, 50);
        fc[1] =  new FreqConfig_ETSI((float)865.7, (float)0.6, 1, 4);
        fc[2] = new FreqConfig_CHINA0((float)840.125, (float)0.25, 2, 19);
        fc[3] = new FreqConfig_CHINA1((float)920.125, (float)0.25, 3, 19);
        m_freqCfgDats = new FREQ_CFG[50];
        for (int i = 0; i < 50; i++) {
            m_freqCfgDats[i] = new FREQ_CFG( 1,0,0 );
        }
        handlerReadfreqCfg();
        OnSendMsg(Constant.MSB_BOX_INIT,"");
        String[] region={"Div 48(FCC)","Div 120(TESI)","Div 96(CHINA0)","Div 96(CHINA1)"};
        ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, region);
        epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        RegionSpinner.setAdapter(epc_filter_adapter);
        RegionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                m_region = position;
                OnCbnSelchangeCombo1();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    @OnClick({R.id.button_select_all, R.id.button_select_none, R.id.button_write_freq_cfg, R.id.button_read_freq_cfg })
    public void onClick(View view) {
        setBusy(Constant.FUNC_IN_BUSY);
        switch (view.getId()) {
            case R.id.button_select_all:
                for (int i = 0; i < data.length;i++) {
                    freqList.setItemChecked(i,true);
                }
                break;
            case R.id.button_select_none:
                for (int i = 0; i < data.length;i++) {
                    freqList.setItemChecked(i,false);
                }
                break;
            case R.id.button_read_freq_cfg:
                Onread_freq_cfg();
                break;
            case R.id.button_write_freq_cfg:
                Onwrite_freq_cfg();
                break;
        }
        setBusy(Constant.FUNC_IN_READY);
    }
    private void OnSendMsg(int msg_num,String msg_str)
    {
        lock.lock();
        Bundle bundle = new Bundle();
        if(Constant.MSG_BOX_SUCCESS == msg_num) {
            bundle.putString("success_str", msg_str);
        }else if(Constant.MSG_BOX_ERR == msg_num){
            bundle.putString("err_str", msg_str);
        }
        Message msg = new Message();
        msg.what = msg_num;
        msg.setData(bundle);
        handler.sendMessage(msg);
        lock.unlock();
    }
    private void OnShowWaittingMsg()
    {
        loadingDialog.show();
    }
    private void OnHideWaittingMsg()
    {
        loadingDialog.dismiss();
    }
    private void OnShowSuccessMsg(String s_err)
    {
        HintDialog.SuccessDialog(mContext,s_err);
    }private void OnShowErrMsg(String s_err)
    {
        HintDialog.faileDialog(mContext, s_err);
    }
    private void Onread_freq_cfg(){
        OnSendMsg(Constant.MSG_BOX_SHOW,"");
        int[] freq_para = RfidLibrary.GetFreq();
        RfidLibrary.SetFreq(freq_para[0], freq_para[1]);
        RegionSpinner.setSelection(freq_para[1]);
        int[] data = new int[50*3];
        int[] sz = new int[1];
        int ret = RfidLibrary.ReadFreqCfgs(data, sz);
        if (ret != 0) {
            OnCbnSelchangeCombo1();
            OnSendMsg(Constant.MSG_BOX_HIDE,"");
            OnSendMsg(Constant.MSG_BOX_ERR,"频段参数读取失败,错误码:" + String.format("%d",ret));
        }
        else
        {
            for(int i=0;i<sz[0];i++) {
                m_freqCfgDats[i].ChanInfo = data[i*3];
                m_freqCfgDats[i].PllDivMult = data[i*3+1];
                m_freqCfgDats[i].Rfu = data[i*3+2];
            }
            OnCbnSelchangeCombo1();
            OnSendMsg(Constant.MSG_BOX_HIDE,"");
            OnSendMsg(Constant.MSG_BOX_SUCCESS,"频段参数读取成功");
        }
    }
    private void Onwrite_freq_cfg(){
        OnSendMsg(Constant.MSG_BOX_SHOW,"");
        int[] freq_para = RfidLibrary.GetFreq();
        int sz = 0;
        m_region = RegionSpinner.getSelectedItemPosition();
        int ret = RfidLibrary.SetFreq(freq_para[0], m_region);
        if(ret != 0)
        {
            OnCbnSelchangeCombo1();
            OnSendMsg(Constant.MSG_BOX_HIDE,"");;
            OnSendMsg(Constant.MSG_BOX_ERR,"频段参数设置失败,错误码::" + String.format("%d",ret));
            return;
        }
        sz = fc[m_region].getCountFreq();
        int[] data = new int[sz *3];
        for (int i = 0; i < sz; i++) {
            int ufreq = fc[m_region].getFreqDWORD(i);

            m_freqCfgDats[i].PllDivMult = ufreq;
            data[i*3+1] = ufreq;
            if(freqList.isItemChecked(i)){
                m_freqCfgDats[i].ChanInfo = 3;
                data[i*3] = 3;
            }
            else {
                m_freqCfgDats[i].ChanInfo = 1;
                data[i*3] = 1;
            }
        }
        ret = RfidLibrary.WriteFreqCfgs(data, sz);
        OnCbnSelchangeCombo1();
        OnSendMsg(Constant.MSG_BOX_HIDE,"");
        if (ret != 0) {
            OnSendMsg(Constant.MSG_BOX_ERR,"频段参数设置失败,错误码:" + String.format("%d",ret));
            return;
        }
        OnSendMsg(Constant.MSG_BOX_SUCCESS,"频段参数设置成功");
    }
private void OnCbnSelchangeCombo1(){
    data = new String[fc[m_region].getCountFreq()];
    //if(data.length>12)
    //{
        ViewGroup.LayoutParams default_params = getView().findViewById(R.id.freq_list_item).getLayoutParams();
        default_params.height = 900;
        getView().findViewById(R.id.freq_list_item).setLayoutParams(default_params);
    //}
    for (int i = 0; i < data.length;i++) {
        float ffreq = fc[m_region].getFreq(i);
        int ufreq = fc[m_region].getFreqDWORD(i);
        data[i] =String.format("%.3f --- 0x%08X", ffreq, ufreq);
    }
    ArrayAdapter<String> adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_multiple_choice,data);
    freqList.setAdapter(adapter);
    for (int i = 0; i < data.length;i++) {
        if (m_freqCfgDats[i].ChanInfo == 3) {
            freqList.setItemChecked(i,true);
        }
    }
}
    @Override
    public String getTitle() {
        return "频段设置";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
