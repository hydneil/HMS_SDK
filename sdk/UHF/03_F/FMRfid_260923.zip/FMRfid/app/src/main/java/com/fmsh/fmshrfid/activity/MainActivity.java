package com.fmsh.fmshrfid.activity;
import android.content.Intent;

import com.fmsh.fmshrfid.fragment.RfidHandle4Android;
import com.fmsh.fmshrfid.utils.PowerUtils;
import com.fmsh.fmshrfid.utils.SerialUtil;
import com.hoho.android.usbserial.driver.UsbSerialPort;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fmsh.base.ui.BaseActivity;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.adapter.itemdata;
import com.fmsh.fmshrfid.adapter.myAdapter;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.Constant;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.jetbrains.annotations.NotNull;
import butterknife.BindView;
import butterknife.OnClick;

public class MainActivity extends BaseActivity  {
    @BindView(R.id.et_com)
    EditText etCom;
    @BindView(R.id.et_baud)
    EditText etBaud;
    @BindView(R.id.tv_version)
    TextView tvVersion;
    @BindView(R.id.btn_connect)
    Button btnConnect;
    @BindView(R.id.btn_exit)
    Button btnExit;
    @BindView(R.id.UsbLog)
    RecyclerView UsbLogs;

    public static SerialUtil serial_port;
    public static  RfidHandle4Android rh4h = null;
    public static String devPath = PowerUtils.CONNECT_ADDRESS;
    private QMUITipDialog MessageBox;
    private Lock main_lock=new ReentrantLock();
    private myAdapter LogAdapter;
    private List<itemdata> LogList = new ArrayList<>();
    private int RadioOpenstatus = 0;
    private int device_type = Constant.DEVICE_UART;
    private Handler handler = new Handler( ){
        @Override
        public void handleMessage(@NotNull Message msg) {
            super.handleMessage(msg);
            main_lock.lock();
            switch(msg.what)
            {
                case Constant.MSB_BOX_INIT:
                    MessageBox = HintDialog.loadingDialog(mContext,"模组初始化中, 请稍后...");
                    break;
                case Constant.MSG_BOX_SHOW:
                    MessageBox.show();
                    break;
                case Constant.MSG_BOX_HIDE:
                    MessageBox.dismiss();
                    break;
                case Constant.MSG_BOX_SUCCESS:
                    HintDialog.SuccessDialog(mContext,msg.getData().getString("success_str"));
                    break;
                case Constant.MSG_BOX_ERR:
                    HintDialog.faileDialog(mContext, msg.getData().getString("err_str"));
                    break;
                case Constant.MSG_USB_DISC:
                    LogList.set(0, new itemdata("未发现USB设备!"));
                    try {
                        LogAdapter.notifyItemChanged(0);
                    }
                    catch (Exception e)
                    {
                        Log.i("JNILOG", "Exception="+ e);
                    }
                    break;
                case Constant.MSG_USB_CLR_INFO:
                    try {
                        if(1 == LogList.size()) {
                            LogList.set(0, new itemdata("未发现USB设备!"));
                            LogAdapter.notifyItemChanged(0);
                        }
                        else
                        {
                            while(LogList.size() > 1)
                            {
                                LogList.remove(1);
                                LogAdapter.notifyItemRemoved(1);
                            }
                            LogList.set(0, new itemdata("未发现USB设备!"));
                            LogAdapter.notifyItemChanged(0);
                        }
                    }
                    catch (Exception e)
                    {
                        Log.i("JNILOG", "Exception="+ e);
                    }
                    break;
            }
            main_lock.unlock();
        }
    };
    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }
    @Override
    protected void initView() {
        LogList.clear();
        etCom.setText(PowerUtils.CONNECT_ADDRESS);///dev/ttyMT1
        etBaud.setText("115200");
        serial_port = new SerialUtil(mContext);
        rh4h = new RfidHandle4Android(this);
        LogAdapter = new myAdapter(LogList);
        UsbLogs.setAdapter(LogAdapter);
        UsbLogs.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        SerialUtil.UsbStatus usbStat = serial_port.getSerialUtilStatus();
        switch (usbStat)
        {
            case NO_USB_DEVICE:
                LogList.add(new itemdata("未发现USB设备!"));
                break;
            case NO_USB_DRIVER:
                LogList.add(new itemdata("未发现USB设备对应驱动!"));
                break;
            case NO_USB_PERMISSION:
                LogList.add(new itemdata("未获取USB设备权限!"));
                break;
            case OPEN_USB_FAILED:
                LogList.add(new itemdata("打开USB设备失败!"));
                break;
            case USB_CONECTED:
                LogList.add(new itemdata("USB设备连接成功!"));
                LogList.add(new itemdata("Path: " + serial_port.getDeviceName()));
                LogList.add(new itemdata("ProductName: " + serial_port.getProductName()));
                LogList.add(new itemdata("VID: " + Integer.toString (serial_port.getVendorId(),16).toUpperCase()));
                LogList.add(new itemdata("PID: " + Integer.toString (serial_port.getProductId(),16).toUpperCase()));
                etCom.setText("/dev/ttyUSB0");
                device_type = Constant.DEVICE_USB;
                break;
        }
    }
    private void ConnectThread(){
        new Thread("WriteFifoThread"){
            @Override
            public void run(){
                onConnect();
            }
        }.start();
    }
    private void UsBCheckThread(){
        new Thread("UsBCheckThread"){
            @Override
            public void run(){
                while(true) {
                    onUsBCheck();
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
//                    if(SerialUtil.UsbStatus.USB_CONECTED == serial_port.getSerialUtilStatus())
//                    {
//                        return;
//                    }
                }
            }
        }.start();
    }
private void onUsBCheck(){
    if((device_type == Constant.DEVICE_UART) && (SerialUtil.UsbStatus.USB_CONECTED !=serial_port.getSerialUtilStatus()))
    {
        serial_port.setSerialUtilStatus(SerialUtil.UsbStatus.USB_CONECTED);
    }
    else if ((device_type == Constant.DEVICE_USB)&&(null == serial_port.getSerial()))
    {
        serial_port.setSerialUtilStatus(SerialUtil.UsbStatus.USB_DISCONECTED);
        if(LogList.size() > 1)
        {
            OnSendMsg(Constant.MSG_USB_CLR_INFO,"");
        }
        else if(1 == LogList.size() && ("未发现USB设备!" != LogList.get(0).getName()))
        {
            OnSendMsg(Constant.MSG_USB_DISC,"");
        }
    }
}
    @Override
    protected void initData() {
        //handlerReadfreqCfg();
        OnSendMsg(Constant.MSB_BOX_INIT,"");
        UsBCheckThread();
        ConnectThread();
    }
    public SerialUtil getserial_port(){
        return serial_port;
    }
    private void OnSendMsg(int msg_num,String msg_str)
    {
        main_lock.lock();
        Bundle bundle = new Bundle();
        if(Constant.MSG_BOX_SUCCESS == msg_num) {
            bundle.putString("success_str", msg_str);
        }else if(Constant.MSG_BOX_ERR == msg_num){
            bundle.putString("err_str", msg_str);
        }
        Message msg = new Message();
        msg.what = msg_num;
        msg.setData(bundle);
        handler.sendMessage(msg);
        main_lock.unlock();
    }
    @OnClick({R.id.btn_connect, R.id.btn_exit})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_connect:
                onConnect();
//                startActivity(new Intent(this, FunctionActivity.class));
                break;
            case R.id.btn_exit:
                try{
                    RfidLibrary.FmshRadioClose();
                    PowerUtils.powerCtrl(PowerUtils.VCC_RFID_DOWN);
                    System.exit(0);
                }
                catch (Exception e)
                {
                    Log.i("JNILOG", "FmshRadioClose Exception"+e);
                }
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + view.getId());
        }
    }
    public static int OpenRadio()
    {
        PowerUtils.powerCtrl(PowerUtils.VCC_RFID_UP);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        if(null==rh4h)
        {
            return -10;
        }
        Log.d("FM","RfidLibrary.FmshRadioOpen start");
        int ret = RfidLibrary.FmshRadioOpen(devPath);
        Log.d("FM","RfidLibrary.FmshRadioOpen end"+ret);
        return ret;
    }
    public void onConnect() {
        SystemClock.sleep(500);
        OnSendMsg(Constant.MSG_BOX_SHOW,"");
        devPath = etCom.getText().toString();
        if(device_type == Constant.DEVICE_USB)
        {
            try{
                String baud = etBaud.getText().toString();
                serial_port.setParameters(Integer.parseInt(baud), 8, 1, UsbSerialPort.PARITY_NONE);
            }catch (UnsupportedOperationException | IOException e){
                LogList.add(new itemdata("USB设备参数异常!"));
            }
            RadioOpenstatus = OpenRadio();
            OnSendMsg(Constant.MSG_BOX_HIDE,"");
            Intent it = new Intent(this, FunctionActivity.class);
            startActivity(it);
        }
        else
        {
            RadioOpenstatus = OpenRadio();
            if (0 == RadioOpenstatus) {
                String baud = etBaud.getText().toString();
                int ret = RfidLibrary.FmshRadioConfig(Integer.parseInt(baud));
                if (ret == 0) {
                    OnSendMsg(Constant.MSG_BOX_HIDE,"");
                    Intent it = new Intent(this, FunctionActivity.class);
                    startActivity(it);
                } else {
                    RfidLibrary.FmshRadioClose();
                    OnSendMsg(Constant.MSG_BOX_HIDE,"");
                    OnSendMsg(Constant.MSG_BOX_ERR,"破特率设置失败");
                }
            } else if(-9971 == RadioOpenstatus)
            {
                OnSendMsg(Constant.MSG_BOX_HIDE,"");
                OnSendMsg(Constant.MSG_BOX_ERR,"模块异常，请更新固件");
                Intent it = new Intent(this, ExFuncActivity.class);
                startActivity(it);
            }else {
                RfidLibrary.FmshRadioClose();
                OnSendMsg(Constant.MSG_BOX_HIDE,"");
                OnSendMsg(Constant.MSG_BOX_ERR,"串口设置失败:" + RadioOpenstatus);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mUHFDevice.UhfStop_long();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        RfidLibrary.FmshRadioClose();
        PowerUtils.powerCtrl(PowerUtils.VCC_RFID_DOWN);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        LogUtil.d(keyCode);
        if (keyCode == KeyEvent.KEYCODE_F1) {
            // 处理F1按键事件
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_F2) {
            // 处理F2按键事件
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}