package com.fmsh.fmshrfid.fragment;
import com.fmsh.fmshrfid.activity.MainActivity;

public class RfidHandle4Android {
    private MainActivity m_activity;
    public RfidHandle4Android(MainActivity mainActivity) {
        m_activity = mainActivity;
    }

    public int rfidread(byte[] buffer, int len)
    {
        int llen = m_activity.getserial_port().recv_uart(buffer,len);
        return llen;
    }
    public int rfidwrite(byte[] buffer, int len)
    {
        return m_activity.getserial_port().send_uart(buffer, len);
    }
}
