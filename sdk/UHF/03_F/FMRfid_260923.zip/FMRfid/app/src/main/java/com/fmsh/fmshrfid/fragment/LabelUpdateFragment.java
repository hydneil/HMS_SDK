package com.fmsh.fmshrfid.fragment;

import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.CircleProgressBar;
import com.fmsh.fmshrfid.utils.Constant;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import butterknife.BindView;
import butterknife.OnClick;


/**
 * @author : sunjun
 * @version : 0.0.1
 * @Date : 2023/12/11 15:19
 * @E-Mail : sunjun@fmsh.com.cn
 */
public class LabelUpdateFragment extends BaseFragment {
    @BindView(R.id.FirmVersion)
    TextView firmversion;
    @BindView(R.id.Tips)
    TextView TipsText;
    @BindView(R.id.circleProgressBar2)
    CircleProgressBar circleProgressBar;
    @BindView(R.id.UpdateFirm)
    Button butFirmUpdate;
    private String m_path;
    private FM4IN1 fm4in1;
    private Handler progressHandler;
    long tiamStamp_1, tiamStamp_2;
    int ind = 0;
    short m_crc = 0;
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_update;
    }

    @Override
    protected void initView(View view) {
        circleProgressBar.setVisibility(View.GONE);
        circleProgressBar.setFirstColor(Color.LTGRAY);
        circleProgressBar.setSecondColor(Color.BLUE);
        circleProgressBar.setCircleWidth(6);
        progressHandler = new Handler(){
            @Override
            public void handleMessage(@NonNull Message msg) {
                String errstr;
                super.handleMessage(msg);
                switch(msg.what)
                {
                    case Constant.MSG_PROG_START_WRITE:
                        circleProgressBar.setVisibility(View.VISIBLE);
                        circleProgressBar.setMax(msg.arg1);
                        circleProgressBar.setProgress(0);
                        break;
                    case Constant.MSG_PROG_UPDATE_WRITE:
                        circleProgressBar.setProgress(msg.arg2);
                        break;
                    case Constant.MSG_PROG_SUCCESS_WRITE:
                        circleProgressBar.setProgress(ind);
                        errstr = "更新成功:" + String.format("%.2f",((float)ind) / (2*(tiamStamp_2 - tiamStamp_1))) +"KB/S";
                        HintDialog.SuccessDialog(mContext, errstr);
                        circleProgressBar.setVisibility(View.GONE);
                        EnAllCtrls(true);
                        break;
                    case Constant.MSG_PROG_FAILED_WRITE:
                        errstr = "更新失败";
                        HintDialog.faileDialog(mContext, errstr);
                        circleProgressBar.setVisibility(View.GONE);
                        EnAllCtrls(true);
                        break;
                }
            }
        };
    }
    private void SendProgressMsg(int msg_num,int arg1, int arg2)
    {
        Message msg = new Message();
        msg.what = msg_num;
        msg.arg1 = arg1;
        msg.arg2 = arg2;
        progressHandler.sendMessage(msg);
    }
    @Override
    protected void initData() {
        fm4in1 = new FM4IN1();
        firmversion.setText("当前固件信息:\n\n"+fm4in1.GetDeviceSn() + "\n\n" + fm4in1.GetMacVer());
        TipsText.setVisibility(View.GONE);
    }
    private void EnAllCtrls(boolean en) {
        butFirmUpdate.setEnabled(en);
        if(en)
        {
            setBusy(Constant.FUNC_IN_READY);
        }
        else
        {
            setBusy(Constant.FUNC_IN_BUSY);
        }
    }
    private int asctohex(byte[]src, int offset, byte[]dst, int nLen)
    {
        int n = 0, nPos = offset;
        while(src[nPos] > ' ' && n < nLen){
            byte ch, cl;
            if(src[nPos] >= '0' && src[nPos] <='9'){
                ch = (byte)(src[nPos] - '0');
            }else if(src[nPos] >= 'a' && src[nPos] <='z'){
                ch = (byte)(src[nPos] - 'a' + 0x0a);
            }else if(src[nPos] >= 'A' && src[nPos] <='Z'){
                ch = (byte)(src[nPos] - 'A' + 0x0a);
            }else{
                n = -1;
                break;
            }
            ++nPos;
            if(src[nPos] >= '0' && src[nPos] <='9'){
                cl =  (byte)(src[nPos] - '0');
            }else if(src[nPos] >= 'a' && src[nPos] <='z'){
                cl =  (byte)(src[nPos] - 'a' + 0x0a);
            }else if(src[nPos] >= 'A' && src[nPos] <='Z'){
                cl =  (byte)(src[nPos] - 'A' + 0x0a);
            }else{
                n = -1;
                break;
            }
            dst[n++] =  (byte)(ch * 0x10 + cl);
            ++nPos;
        }
        return n;
    }
    private int UpdataFirmware(int nStartAddr, byte[]buffer, int nBuffLen)
    {
        int ret = 0;
        int nDataLen = FM4IN1.X_UPDATE_LENGTH;
        if(nBuffLen < FM4IN1.X_UPDATE_LENGTH){
            nDataLen = nBuffLen;
        }
        m_crc = fm4in1.CalculateIapCrc((short)(~m_crc), buffer, nBuffLen);
        ret = fm4in1.UpdataFirmware(nStartAddr, buffer, nDataLen);
        if(0 == ret) {
            ind += nBuffLen;
        }
        return ret;
    }
    private int UpdataFirmwareThread(byte[] StreamBuffer)
    {
        int length = 0;
        int nPos = 0;
        int nLen =0;
        int nFileLen = StreamBuffer.length;
        int nStartAddr = 0, offset = 0;
        byte[]buffer = StreamBuffer;
        byte[] scBuff = new byte [100 + FM4IN1.X_UPDATE_LENGTH];
        SendProgressMsg(Constant.MSG_PROG_START_WRITE, nFileLen,0);
        while(true){
            nPos += nLen * 2;
            while(nPos < nFileLen){
                if(buffer[nPos] > ' '){
                    break;
                }
                ++nPos;
            }
            if(nPos == nFileLen){
                break;
            }
            ++nPos; // 首字节':'不在整理范围内
            byte[] buff = buffer;
            // 按行整理数据
            nLen = asctohex(buffer, nPos, buff, nFileLen);
            if(nLen >= 5){
                if(buff[3] == FM4IN1.RECORD_DATA){
                    if(offset == 0){
                        offset = buff[1] * 0x100 +  buff[2];
                        nStartAddr += offset;
                        offset= -1;
                    }
                    int nDataLen = buff[0];
                    System.arraycopy(buff,4, scBuff,length, nDataLen);//memcpy(scBuff + length, buff + 4, nDataLen);
                    length += nDataLen;
                    if(length >= FM4IN1.X_UPDATE_LENGTH){
                        int ret = UpdataFirmware(nStartAddr, scBuff, length);
                        if(ret != 0) return ret;

                        nStartAddr += FM4IN1.X_UPDATE_LENGTH;
                        length = length - FM4IN1.X_UPDATE_LENGTH;
                        System.arraycopy(scBuff,FM4IN1.X_UPDATE_LENGTH, scBuff,0, length);//memcpy(scBuff, scBuff + FM4IN1.X_UPDATE_LENGTH, length);
                        SendProgressMsg(Constant.MSG_PROG_UPDATE_WRITE,0,nPos);
                    }
                }else if(buff[3] == FM4IN1.RECORD_END_OF_FILE){
                    if(length > 0){
                        int ret = UpdataFirmware(nStartAddr, scBuff, length);
                        if(ret != 0) return ret;
                    }
                    break;
                }else if(buff[3] == FM4IN1.RECORD_EXT_LINEAR_ADDRESS){
                    if(length > 0){
                        int ret = UpdataFirmware(nStartAddr, scBuff, length);
                        if(ret != 0) return ret;
                        length = 0;
                        SendProgressMsg(Constant.MSG_PROG_UPDATE_WRITE,0,nPos);
                    }
                    offset = 0;
                    //////////////////////////////////////////////////////////////////////////
                    // check data
                    byte s_crc = 0;
                    for(int i = 0; i < nLen - 1; ++i){
                        s_crc += buff[i];
                    }
                    s_crc = (byte)(0x100 - s_crc);
                    if(s_crc != buff[nLen - 1]){
                        return -2;
                    }
                    //////////////////////////////////////////////////////////////////////////
                    //nStartAddr = (buff[4] * 0x100 + buff[5]) * 0x10000;
                }
            }else if(nLen == -1){
                return -1;
            }
        }
        return 0;
    }
    @OnClick({R.id.UpdateFirm })
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.UpdateFirm:
                EnAllCtrls(false);
                ind = 0;
                m_crc = 0;
                byte[] hexStream = ReadFromFile();
                if(fm4in1.SetApp(FM4IN1.BOOT)){
                    new Thread("FirmUpdateThread"){
                        @Override
                        public void run(){
                                    tiamStamp_1 = System.currentTimeMillis();
                                     if(0 != fm4in1.EraseFirmware()){
                                        SendProgressMsg(Constant.MSG_PROG_FAILED_WRITE, 0,0);
                                     }
                                    if(0 != UpdataFirmwareThread(hexStream)){
                                        SendProgressMsg(Constant.MSG_PROG_FAILED_WRITE, 0,0);
                                    }
                                    tiamStamp_2 = System.currentTimeMillis();
                                    if(0 == fm4in1.IapFinish((short)m_crc, ind) ){
                                        SendProgressMsg(Constant.MSG_PROG_SUCCESS_WRITE, 0,0);
                                        firmversion.setText("当前固件信息:\n\n"+fm4in1.GetDeviceSn() + "\n\n" + fm4in1.GetMacVer() + "\n\n CRC: " +  String.format("%04X", m_crc ));
                                    }
//                                    else if(0 == fm4in1.FirmwareUpdateEnd() )
//                                    {
//                                        SendProgressMsg(Constant.MSG_PROG_SUCCESS_WRITE, 0,0);
//                                    }
                                    else{
                                        SendProgressMsg(Constant.MSG_PROG_FAILED_WRITE, 0,0);
                                    }
                                }
                        }.start();
                    return;
                }
                break;
        }
    }

    public byte[] ReadFromFile(){
        File hexFile = new File(m_path);
        byte[] buffer;
        int rd_sz = 0;
        if(hexFile.isFile() && hexFile.exists())
        {
            FileInputStream readfs = null;
            try {
                readfs = new FileInputStream(hexFile);
                int m_file_len = (int)hexFile.length();
                buffer = new byte[m_file_len];
                rd_sz = readfs.read(buffer,0, m_file_len);
                readfs.close();
                if(rd_sz != m_file_len)
                {
                    return null;
                }
                return buffer;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        else
        {
            hexFile.mkdirs();
            return null;
        }
        return null;
    }

    public void SetPath(String path){
        m_path = path;
    }
    public void SetTips(String tips){
        TipsText.setVisibility(View.VISIBLE);
        TipsText.setText(tips);
    }
    @Override
    public String getTitle() {
        return "固件更新";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
