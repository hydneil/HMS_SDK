package com.fmsh.fmshrfid.fragment;

public abstract class FreqConfig {
    private float m_firstFreq;
    private float m_step;
    private int m_region;
    private int m_count;

    protected float getFirstFreq() { return m_firstFreq; }
    protected float getStepFreq() { return m_step; }
    protected int getRegion() { return m_region; }
    protected int getCountFreq() { return m_count; }
    protected abstract int getFreqDWORD(int index);
    protected void initdata(float f_freq,float s_freq,int region,int cnt)
    {
        m_firstFreq = f_freq;
        m_step = s_freq;
        m_region = region;
        m_count = cnt;
    }
    protected float getFreq(int index)  {
        if (index < 0 || index >= m_count) {
            return 0;
        }
        else {
            return m_firstFreq + m_step * index;
        }
    }
}

class FreqConfig_FCC extends FreqConfig{

    public FreqConfig_FCC(float f_freq,float s_freq,int region,int cnt){
        //initdata(902.75, 0.5, 0, 50);
        initdata(f_freq, s_freq, region, cnt);
    }
    @Override protected int getFreqDWORD(int index){
        //0x300E1B = 902.75 * 48 / 12 + 3145728
        if (index < 0 || index >= getCountFreq()) {
            return 0;
        }
        else {
            float ffreq = getFreq(index);
            return (int)((ffreq * 48 / 12) + 3145728);
        }
    }
}

class FreqConfig_ETSI extends FreqConfig{

    public FreqConfig_ETSI(float f_freq,float s_freq,int region,int cnt){
        initdata(f_freq, s_freq, region, cnt);
    }
    @Override protected int getFreqDWORD(int index){
        //0x7821D1= 865.7 * 120 / 12+7864320
        if (index < 0 || index >= getCountFreq()) {
            return 0;
        }
        else {
            float ffreq = getFreq(index);
            return (int)((ffreq * 120 / 12) + 7864320);
        }
    }
}

class FreqConfig_CHINA0 extends FreqConfig{

    public FreqConfig_CHINA0(float f_freq,float s_freq,int region,int cnt){
        initdata(f_freq, s_freq, region, cnt);
    }
    @Override protected int getFreqDWORD(int index){
        //0x601A41 =(840.125 * 96 / 12)+ 6291456
        if (index < 0 || index >= getCountFreq()) {
            return 0;
        }
        else {
            float ffreq = getFreq(index);
            return (int)((ffreq * 96 / 12) + 6291456);

        }
    }
}

class FreqConfig_CHINA1 extends FreqConfig{

    public FreqConfig_CHINA1(float f_freq,float s_freq,int region,int cnt){
        initdata(f_freq, s_freq, region, cnt);
    }
    @Override protected int getFreqDWORD(int index){
        //0x601CC1= (920.125 * 96 / 12)+ 6291456
        if (index < 0 || index >= getCountFreq()) {
            return 0;
        }
        else {
            float ffreq = getFreq(index);
            return (int)((ffreq * 96 / 12) + 6291456);
        }
    }
}

class FREQ_CFG{
    int  ChanInfo;
    int  PllDivMult;
    int  Rfu;
    FREQ_CFG(int  ci,int  pm,int  rfu)
    {
        ChanInfo = ci;
        PllDivMult = pm;
        Rfu =rfu;
    }
};