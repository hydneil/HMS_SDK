package com.fmsh.fmshrfid.activity;

import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.fmsh.base.ui.BaseActivity;
import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.base.utils.UIUtils;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.adapter.LabelAdapter;
import com.fmsh.fmshrfid.adapter.NonSwipeableViewPager;
import com.fmsh.fmshrfid.adapter.ViewPagerAdapter;
import com.fmsh.fmshrfid.fragment.LabelFragment;
import com.fmsh.fmshrfid.fragment.SettingFragment;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.google.android.material.tabs.TabLayout;
import com.qmuiteam.qmui.widget.QMUITopBarLayout;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/6/15 11:01
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class FunctionActivity extends BaseActivity {


    @BindView(R.id.topbar)
    QMUITopBarLayout topbar;
    @BindView(R.id.viewPager)
    NonSwipeableViewPager viewPager;
    @BindView(R.id.tabLayout)
    TabLayout tabLayout;
    private LabelFragment labelFragment;


    @Override
    protected int getLayoutId() {
        return R.layout.activity_function;
    }

    @Override
    protected void initView() {
        setTitle(UIUtils.getString(mContext,R.string.app_name)+ " " +UIUtils.getVersion(mContext));

        viewPager.setSwipeEnabled(false);

    }

    @Override
    protected void initData() {
        ArrayList<BaseFragment> list = new ArrayList<>();
        labelFragment = new LabelFragment();
        SettingFragment settingFragment = new SettingFragment();
        list.add(labelFragment);
        list.add(settingFragment);
        ViewPagerAdapter adapter = new ViewPagerAdapter(this, getSupportFragmentManager(), list);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tabAt = tabLayout.getTabAt(i);
            tabAt.setCustomView(adapter.getTabView(i));
        }

        tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                ImageView viewById = tab.getCustomView().findViewById(R.id.title_icon);
                TextView title = tab.getCustomView().findViewById(R.id.title);
                title.setTextColor(UIUtils.getColor(mContext, R.color.colorPrimary));
                switch (tab.getPosition()) {
                    case 0:
                        viewById.setImageResource(R.mipmap.label_press);
                        break;
                    case 1:
                        viewById.setImageResource(R.mipmap.setting_press);
                        break;

                    default:
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                ImageView viewById = tab.getCustomView().findViewById(R.id.title_icon);
                TextView title = tab.getCustomView().findViewById(R.id.title);
                title.setTextColor(UIUtils.getColor(mContext, R.color.qmui_config_color_gray_5));
                switch (tab.getPosition()) {
                    case 0:
                        viewById.setImageResource(R.mipmap.label_normal);
                        break;
                    case 1:
                        viewById.setImageResource(R.mipmap.setting_normal);
                        break;
                    default:
                        break;
                }
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
        viewPager.setCurrentItem(1);
        // 直接设置0没有起作用
        viewPager.setCurrentItem(0);
        //禁止页面切换重新onCreate
        viewPager.setOffscreenPageLimit(1);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (labelFragment != null){
            return labelFragment.dispatchKeyEvent(event);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onPause() {
        super.onPause();
//        LogUtil.d("stop");
//        RfidLibrary.stopInventory();
//        if(labelFragment != null && labelFragment.handlerThread != null){
//            labelFragment.handlerThread.quit();
//        }
//        RfidLibrary.RFID_Close();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }





}
