package com.fmsh.fmshrfid.fragment;

import android.os.SystemClock;

import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.fmshrfid.jni.RfidLibrary;
public class FM4IN1 {
    final static char FM_CMD_GET_INFO               = 0x4F;
    final static char FM_CMD_SET_APP                = 0x0B;
    final static char FM_CMD_HEART_BEAT             = 0x10;
    final static char FM_BOOT_CMD_FIRM_UPDATE       = 0x09;
    final static char FM_BOOT_CMD_FIRM_DOWNLOAD     = 0x0A;
    final static char FM_BOOT_CMD_FIRM_ERASE        = 0x7;
    final static char FW_UPDATA_MCU                 = 0x01;

    final static char RECORD_DATA                   = 0x00;
    final static char RECORD_END_OF_FILE            = 0x01;
    final static char RECORD_EXT_SEG_ADDRESS        = 0x02;
    final static char RECORD_START_SEG_ADDRESS      = 0x03;
    final static char RECORD_EXT_LINEAR_ADDRESS     = 0x04;
    final static char RECORD_START_LINEAR_ADDRESS   = 0x05;

    final static char X_UPDATE_LENGTH               = 1024;

    final static char APP                           = 0x00;
    final static char BOOT                          = 0x01;

    private String mac_ver;
    private String device_sn;
    private byte[] cmdLine;
    private byte[] Resp;
    private int RespLen[];
    public FM4IN1(){
        byte[] data = RfidLibrary.FmshGetSerialNum();
        byte[] version = RfidLibrary.FmshGetVersion();
        mac_ver =  FMUtil.byteToString(version);
        device_sn = "Serial Number : " + FMUtil.byteToString(data);

        Resp = new byte[300];
        RespLen = new int[1];
    }
    public String GetMacVer(){
        return mac_ver;
    }

    public String GetDeviceSn(){
        return device_sn;
    }

    private int GetAppStatus(){//获取设备运行模式(1-BOOT 0-APP)
        cmdLine = new byte[]{0x00,FM_CMD_GET_INFO,0x00,0x00,0x00};
        if(0 == RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen)){
            if((3 == RespLen[0])&&(0 == Resp[0])&&(1 == Resp[1])){
                cmdLine = null;
                return Resp[2];
            }
        }
        cmdLine = null;
        return -1;
    }
    public boolean SetApp(char flag){//(1-BOOT 0-APP)
        int AppStatus = GetAppStatus();
        if(AppStatus<0){
            return false;
        }
        if(flag != AppStatus) {
            cmdLine = new byte[]{0x00,FM_CMD_SET_APP,0x00,0x00,0x00};
            if(0 == RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen)){
                SystemClock.sleep(1000);
                cmdLine = null;
                return  (flag == GetAppStatus());
            }
        }
        cmdLine = null;
        return true;
    }
    public int IapFinish(short crc,int len) {//FW_UPDATA_MCU
        cmdLine = new byte[]{0x00, 0x0A, 0x00, 0x00, (byte)(crc&0xFF), (byte)((crc>>8)&0xFF), (byte)((len>>24)&0xFF), (byte)((len>>16)&0xFF), (byte)((len>>8)&0xFF), (byte)(len&0xFF)};
        int status = RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen);
        cmdLine = null;
        return status;
    }
    public int FirmwareUpdateEnd() {//FW_UPDATA_MCU
        cmdLine = new byte[]{0x0D, 0x09, 0x00, 0x00, (byte)(0xFF)};
        int status = RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen);
        cmdLine = null;
        return status;
    }

    //计算CRC
    private short UpdateCrc(byte ch, short[]lpwCrc)
    {
        ch = (byte) (ch^(byte)((lpwCrc[0]) & 0xFF));
        ch = (byte) (ch^(ch<<4));

        lpwCrc[0] = (short)(((0xFF)&(lpwCrc[0] >> 8))^(((short)ch << 8)&0xFFFF)^(((short)ch<<3)&0x7FF)^((0xF)&((short)(ch>>4))));
        return lpwCrc[0];
    }

    private short ComputeCrc(short InitCRC, byte[]Data, int Length)
    {
        byte chBlock;
        int  InLength = Length;
        short wCrc[] = new short[]{InitCRC};
        int i = 0;
        do
        {
            chBlock = Data[i++];
            UpdateCrc(chBlock, wCrc);
        } while ((--InLength) > 0);
        return (short)(~wCrc[0]);
    }

    public short CalculateIapCrc(short ori_crc, byte[] data,int len)
    {
        return ComputeCrc(ori_crc, data, len);
    }
    public int EraseFirmware() {//FM_BOOT_CMD_FIRM_ERASE
        cmdLine = new byte[]{0x00, FM_BOOT_CMD_FIRM_ERASE, 0x00, 0x00};
        int status =  RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen);
        cmdLine = null;
        return status;
    }
    public int UpdataFirmware(int startAddr, byte[]data, int dataLen){
        cmdLine = new byte[dataLen + 10];
        cmdLine[0] = 0x00;
        cmdLine[1] = 0x09;
        cmdLine[2] = cmdLine[3] = 0;
        cmdLine[4] = (byte)(startAddr>>24);
        cmdLine[5] = (byte)(startAddr>>16);
        cmdLine[6] = (byte)(startAddr>>8);
        cmdLine[7] = (byte)(startAddr);
        cmdLine[8] = (byte)(dataLen>>8);
        cmdLine[9] = (byte)(dataLen);
        System.arraycopy(data,0,cmdLine,10,dataLen);
        int status =   RfidLibrary.Cmdprocess(cmdLine, cmdLine.length, Resp, RespLen);
        cmdLine = null;
        return status;
    }
}
