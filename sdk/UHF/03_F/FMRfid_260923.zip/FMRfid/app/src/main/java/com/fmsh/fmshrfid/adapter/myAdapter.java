package com.fmsh.fmshrfid.adapter;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.fmsh.fmshrfid.R;
import androidx.annotation.NonNull;
import java.util.List;


public class myAdapter extends RecyclerView.Adapter<MyViewHolder>{
    private List<itemdata> nmitemdata;//数据源
    //myAdapter，加入了数据源参数，在构造的时候赋值给nmitemdata
    public myAdapter(List<itemdata> mitemdata) {
        nmitemdata = mitemdata;
    }
//    //静态内部类， 每个条目对应的布局
//    static class ViewHolder extends RecyclerView.ViewHolder{
//        TextView names;
//        public ViewHolder(@NonNull View itemView) {
//            super(itemView);
//            names = (TextView) itemView.findViewById(R.id.LogView);
//        }
//    }
    //用于创建ViewHolder实例,并把加载的布局传入到ViewHolder的构造函数去
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_log, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }
    //是用于对子项的数据进行赋值,会在每个子项被滚动到屏幕内时执行。position得到当前项的实例
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        itemdata Itemata = nmitemdata.get(position);
        holder.UsbLogView.setText(Itemata.getName());
    }
    //返回RecyclerView的子项数目
    @Override
    public int getItemCount() {
        return nmitemdata.size();
    }
}