package com.fmsh.fmshrfid.fragment;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.Constant;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelLedCtrlFragment extends BaseFragment {
    @BindView(R.id.led_ctrl_epc_filter_spinner)
    Spinner epc_flt_Spinner;
    @BindView(R.id.led_ctrl_password)
    EditText led_ctrl_password;
    @BindView(R.id.on_time)
    EditText led_on_time;
    private ArrayList<String> epcList;
    private QMUITipDialog loadingDialog;
    int cur_proto;
    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
        if((epcList!= null) && (epcList.size()>0))
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_flt_Spinner.setAdapter(epc_filter_adapter);

            cur_proto = RfidLibrary.GetCurProto();
            loadingDialog = HintDialog.loadingDialog(mContext);
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_led_ctrl;
    }

    @Override
    protected void initView(View view) {
    }
    private int OnSetMatchRegister(){
        int stat = 0;
        if(epcList.size()>0) {
            String match_str = epcList.get(epc_flt_Spinner.getSelectedItemPosition());
            stat = RfidLibrary.SetmatchRule(cur_proto, match_str, match_str.length());
        }
        return stat;
    }
    void OnClickedLedOn(){
        String strpasswd = led_ctrl_password.getText().toString().trim();
        String strontime = led_on_time.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置口令");
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            return;
        }
        int passwd = Integer.parseInt(strpasswd);
        int ontime = Integer.parseInt(strontime);
        if(0 == (RfidLibrary.LedCtrl(1, ontime, passwd)))
        {
            HintDialog.successDialog(mContext, "LED点亮成功!");
        }
        else
        {
            HintDialog.successDialog(mContext, "LED点亮失败!");
        }
    }
    void OnClickedLedOff(){
        String strpasswd = led_ctrl_password.getText().toString().trim();
        String strontime = led_on_time.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置口令");
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            return;
        }
        int passwd = Integer.parseInt(strpasswd);
        int ontime = Integer.parseInt(strontime);
        if(0 == (RfidLibrary.LedCtrl(0, ontime, passwd)))
        {
            HintDialog.successDialog(mContext, "LED熄灭成功!");
        }
        else
        {
            HintDialog.successDialog(mContext, "LED熄灭失败!");
        }
    }
    @OnClick({R.id.led_on,R.id.led_off })
    public void onClick(View view) {
        setBusy(Constant.FUNC_IN_BUSY);
        switch (view.getId()) {
            case R.id.led_on:
                OnClickedLedOn();
                break;
            case R.id.led_off:
                OnClickedLedOff();
                break;
        }
        setBusy(Constant.FUNC_IN_READY);
    }
    @Override
    protected void initData() {
    }
    @Override
    public String getTitle() {
        return "Led Control";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
