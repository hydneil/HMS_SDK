package com.fmsh.fmshrfid.utils;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/13 14:36
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class Constant {
    public static final int RFID_PACKET_TYPE_COMMAND_BEGIN = 0x0000; // 开始
    public static final int RFID_PACKET_TYPE_COMMAND_END = 0x0001; // 结束
    public static final int RFID_PACKET_TYPE_18K6C_INVENTORY = 0x0005; // 盘点数据
    public static final int MSB_BOX_INIT                = -1;
    public static final int MSG_BOX_HIDE                = 0;
    public static final int MSG_BOX_SHOW                = 1;
    public static final int MSG_BOX_SUCCESS             = 2;
    public static final int MSG_BOX_ERR                 = 3;

    public static final int MSG_PROG_START_READ         = 4;
    public static final int MSG_PROG_UPDATE_READ        = 5;
    public static final int MSG_PROG_FAILED_READ        = 6;
    public static final int MSG_PROG_SUCCESS_READ       = 7;

    public static final int MSG_PROG_START_WRITE        = 8;
    public static final int MSG_PROG_UPDATE_WRITE       = 9;
    public static final int MSG_PROG_FAILED_WRITE       = 10;
    public static final int MSG_PROG_SUCCESS_WRITE      = 11;

    public static final int MSG_USB_DISC                = 12;
    public static final int MSG_USB_CLR_INFO            = 13;
    public static final int FUNC_IN_HALT                = 0;
    public static final int FUNC_IN_READY               = 1;
    public static final int FUNC_IN_BUSY                = 2;

    public static final int DEVICE_USB                  = 1;
    public static final int DEVICE_UART                 = 2;
}