package com.fmsh.fmshrfid.fragment;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.FMUtil;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.base.utils.LogUtil;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.adapter.LabelAdapter;
import com.fmsh.fmshrfid.bean.InventoryBean;
import com.fmsh.fmshrfid.utils.ParseUtils;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelLockFragment extends BaseFragment {
    @BindView(R.id.button_lock)
    Button btnLock;
    @BindView(R.id.tv_lockcount)
    TextView tvReadCount;
    @BindView(R.id.lk_epc_filter_spinner)
    Spinner epc_filter_Spinner;
    private LabelAdapter labelAdapter;
    private ArrayList<String> epcList;
    private List<InventoryBean> beanList = new ArrayList<>();
    private HashMap<String,InventoryBean> hashMap = new HashMap<>();
    private QMUITipDialog loadingDialog;
    private boolean isInventory = false;

    int value = 1;
    private SoundPool soundPool;
    private int mMusic;
    public HandlerThread handlerThread;
    private Handler handler;
    private void epc_filter_init(){
        if(epcList.size()>0)
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_filter_Spinner.setAdapter(epc_filter_adapter);
        }
    }
    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
    }
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_lock;
    }


    @Override
    protected void initView(View view) {
        epc_filter_init();
        loadingDialog = HintDialog.loadingDialog(mContext);

        soundPool = new SoundPool(1, AudioManager.STREAM_SYSTEM, 0);

        mMusic = soundPool.load(mContext, R.raw.beep, 1);

        handlerSound();
    }

    private void handlerSound(){
        handlerThread = new HandlerThread("sound");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                soundPool.play(mMusic, 1, 1, 0, 0, 1);
                SystemClock.sleep(100);
            }
        };

    }



    @Override
    protected void initData() {

    }

    @OnClick({R.id.button_lock })
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.button_lock:
                break;
        }

    }

    private void parseData(byte[] data) {
        LogUtil.d(FMUtil.byteToHex(data));

        InventoryBean inventoryBean = ParseUtils.parsePacket(data);
        handler.sendMessage(handler.obtainMessage());
        if (inventoryBean.getEpc() != null) {
            if (!hashMap.containsKey(inventoryBean.getEpc())) {
                hashMap.put(inventoryBean.getEpc(),inventoryBean);
                beanList.add(inventoryBean);
                LogUtil.d(inventoryBean.toString());
            }else {
                InventoryBean bean = hashMap.get(inventoryBean.getEpc());
                if (bean!= null){
                    bean.setPhase(inventoryBean.getPhase());
                    bean.setRSSI(inventoryBean.getRSSI());
                    bean.setMS_Ctr(inventoryBean.getMS_Ctr());
                    bean.setChIdx(inventoryBean.getChIdx());
                    bean.setPhyAtn(inventoryBean.getPhyAtn());
                    bean.setLabelCount(bean.getLabelCount()+1);
                }
            }
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvReadCount.setText("锁定操作执行成功");
                    labelAdapter.setList(beanList);

                }
            });
        }
    }

    @Override
    public String getTitle() {
        return "锁定标签";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
