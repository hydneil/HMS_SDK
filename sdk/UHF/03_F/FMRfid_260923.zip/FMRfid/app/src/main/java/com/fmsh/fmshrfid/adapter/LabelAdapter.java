package com.fmsh.fmshrfid.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.fmsh.base.adapter.BaseRecyclerAdapter;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.bean.InventoryBean;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author wuyajiang
 * @date 2022/2/28
 */
public class LabelAdapter extends BaseRecyclerAdapter {


    public LabelAdapter(Context context) {
        super(context);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_lable;
    }

    @Override
    public RecyclerView.ViewHolder getViewHolder(View view) {
        return new ViewHolder(view);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void setBindHolder(RecyclerView.ViewHolder holder, int position) {
        ViewHolder viewHolder = (ViewHolder) holder;
        InventoryBean inventoryBean = (InventoryBean) mList.get(position);

        viewHolder.tvPc.setText(inventoryBean.getPc());
        viewHolder.tvEpc.setText(inventoryBean.getEpc());
        //viewHolder.tvPhase.setText(String.format("%.2f",inventoryBean.getPhase()));
        //viewHolder.tvRssi.setText(String.format("%.2f",inventoryBean.getRSSI()));
        viewHolder.tvTime.setText(String.valueOf(inventoryBean.getMS_Ctr()));
        viewHolder.tv_chIdx.setText(String.valueOf(inventoryBean.getChIdx()));
        viewHolder.tv_PhyAtn.setText(String.valueOf(inventoryBean.getPhyAtn()));
        viewHolder.tv_count.setText("盘点次数:"+String.valueOf(inventoryBean.getLabelCount()));
        if(inventoryBean.getName() == null){
            viewHolder.ll_name.setVisibility(View.GONE);
        }else {
            viewHolder.ll_name.setVisibility(View.VISIBLE);
            viewHolder.epc_name.setText(inventoryBean.getName());
        }
        if(inventoryBean.getTid() == null){
            viewHolder.ll_t.setVisibility(View.GONE);
        }else {
            viewHolder.ll_t.setVisibility(View.VISIBLE);
            viewHolder.tv_tid.setText(inventoryBean.getTid());
        }


    }




    static
    class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_pc)
        TextView tvPc;
        @BindView(R.id.tv_epc)
        TextView tvEpc;
        @BindView(R.id.tv_phase)
        TextView tvPhase;
        @BindView(R.id.tv_rssi)
        TextView tvRssi;
        @BindView(R.id.tv_time)
        TextView tvTime;
        @BindView(R.id.tv_chIdx)
        TextView tv_chIdx;
        @BindView(R.id.tv_PhyAtn)
        TextView tv_PhyAtn;
        @BindView(R.id.tv_count)
        TextView tv_count;
        @BindView(R.id.tv_name)
        TextView tv_name;
        @BindView(R.id.epc_name)
        TextView epc_name;
        @BindView(R.id.ll_name)
        LinearLayout ll_name;
        @BindView(R.id.ll_t)
        LinearLayout ll_t;
        @BindView(R.id.tv_tid)
        TextView tv_tid;


        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

}
