package com.fmsh.fmshrfid.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.fmsh.base.ui.BaseActivity;
import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.UIUtils;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.fragment.LabelAboutUs;
import com.fmsh.fmshrfid.fragment.LabelFifoAccessFragment;
import com.fmsh.fmshrfid.fragment.LabelFreqCfgFragment;
import com.fmsh.fmshrfid.fragment.LabelLedCtrlFragment;
import com.fmsh.fmshrfid.fragment.LabelTempMeasFragment;
import com.fmsh.fmshrfid.fragment.LabelUpdateFragment;
import com.fmsh.fmshrfid.utils.Constant;
import com.fmsh.fmshrfid.utils.PickUtils;

import java.util.ArrayList;

/**
 * @author : Sunjun
 * @version : 0.0.1
 * @Date : 2023/10/13 14:00
 * @E-Mail : sunjun@fmsh.com.cn
 */
public class ExFuncActivity extends BaseActivity {
    public ArrayList<String> m_epcArray;
    private LabelLedCtrlFragment ledCtrlFragment = new LabelLedCtrlFragment();
    private LabelTempMeasFragment TempFragment = new LabelTempMeasFragment();
    private LabelFifoAccessFragment fifoFragment = new LabelFifoAccessFragment();
    private LabelFreqCfgFragment freqCfgFragment = new LabelFreqCfgFragment();
    private LabelUpdateFragment UpdateFragment = new LabelUpdateFragment();
    //button_update
    private LabelAboutUs AboutUsFragment = new LabelAboutUs();

    private int default_height;
    private BaseFragment cur_bf;
    private FragmentTransaction ftr = getSupportFragmentManager().beginTransaction();
    private Intent m_int;
    private ActivityResultLauncher<Intent> IntentActivityLauncher;
    @Override
    protected int getLayoutId() {
        return R.layout.activity_ex_func;
    }

    @Override
    protected void initView() {
        setTitle(UIUtils.getString(mContext,R.string.title_activity_ex_function));
    }

    private void onEnFragment(BaseFragment bf, boolean en)
    {
        ftr.hide(ledCtrlFragment);
        ftr.hide(TempFragment);
        ftr.hide(fifoFragment);
        ftr.hide(freqCfgFragment);
        ftr.hide(UpdateFragment);
        ftr.hide(AboutUsFragment);
        if(en) {
            bf.setBusy(Constant.FUNC_IN_READY);
            ftr.show(bf);
        }
        ftr.commit();
    }
    private void onInitClickCallback(BaseFragment bf)
    {
        cur_bf = bf;
        ViewGroup.LayoutParams default_params;
        ((TextView)findViewById(R.id.topic_title)).setText(bf.getTitle());
        ftr = getSupportFragmentManager().beginTransaction();

        onEnFragment(bf, true);

        findViewById(R.id.func_layout_content).setVisibility(View.VISIBLE);
        findViewById(R.id.main_layout_content).setVisibility(View.GONE);
        FrameLayout fl = (FrameLayout)findViewById(R.id.main_layout_content);
        default_params = fl.getLayoutParams();
        default_height = default_params.height;
        default_params.height = 1;
        findViewById(R.id.main_layout_content).setLayoutParams(default_params);
    }

    private boolean onReturnCallback(){
        if(cur_bf!= null)
        {
            switch (cur_bf.getBusy())
            {
                case Constant.FUNC_IN_HALT:
                    return true;
                case Constant.FUNC_IN_READY:
                    cur_bf.setBusy(Constant.FUNC_IN_HALT);
                    break;
                case Constant.FUNC_IN_BUSY:
                    return false;
            }
        }
        else
        {
            return true;
        }
        ViewGroup.LayoutParams default_params;
        ((TextView)findViewById(R.id.topic_title)).setText(UIUtils.getString(mContext,R.string.title_activity_ex_function));
        findViewById(R.id.main_layout_content).setVisibility(View.GONE);
        default_params = ((FrameLayout)findViewById(R.id.main_layout_content)).getLayoutParams();
        default_params.height = default_height;
        findViewById(R.id.main_layout_content).setVisibility(View.VISIBLE);
        findViewById(R.id.main_layout_content).setLayoutParams(default_params);
        findViewById(R.id.func_layout_content).setVisibility(View.GONE);
        ftr = getSupportFragmentManager().beginTransaction();
        ftr.hide(cur_bf);
        ftr.commit();
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex_func);
        ftr.add(R.id.func_layout_content, fifoFragment);
        ftr.add(R.id.func_layout_content, TempFragment);
        ftr.add(R.id.func_layout_content, ledCtrlFragment);
        ftr.add(R.id.func_layout_content, freqCfgFragment);
        ftr.add(R.id.func_layout_content, UpdateFragment);

        ftr.add(R.id.func_layout_content, AboutUsFragment);

        onEnFragment(ledCtrlFragment, false);
        //led control
        Button led_ctrl_but = findViewById(R.id.button_led_control);
        ((TextView)findViewById(R.id.topic_title)).setText(UIUtils.getString(mContext,R.string.title_activity_ex_function));
        findViewById(R.id.button_led_control).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ledCtrlFragment.onInit(m_epcArray);
                onInitClickCallback(ledCtrlFragment);
            }
        });

        //温度测量
        Button temp_meas_but = findViewById(R.id.button_temp_meas);
        temp_meas_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TempFragment.onInit(m_epcArray);
                onInitClickCallback(TempFragment);
            }
        });

        //FIFO Access
        Button fifo_access_but = findViewById(R.id.button_fifo_access);
        fifo_access_but.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                fifoFragment.onInit(m_epcArray);
                onInitClickCallback(fifoFragment);
            }
        });

        //频率设置
        Button freqCfgBut = findViewById(R.id.button_freq_cfg);
        freqCfgBut.setOnClickListener(new View.OnClickListener(){
            @Override public void onClick(View v){
                onInitClickCallback(freqCfgFragment);
            }
        });
        if((null == m_epcArray)){
            led_ctrl_but.setEnabled(false);
            temp_meas_but.setEnabled(false);
            fifo_access_but.setEnabled(false);
            freqCfgBut.setEnabled(false);
        }
        else if(m_epcArray.size() == 0) {
            led_ctrl_but.setEnabled(false);
            temp_meas_but.setEnabled(false);
            fifo_access_but.setEnabled(false);
        }
        //update firmware
        findViewById(R.id.button_update).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentActivityLauncher.launch(m_int);
            }
        });
        //About Us
        findViewById(R.id.button_about).setOnClickListener(new View.OnClickListener(){
            @Override public void onClick(View v){
                onInitClickCallback(AboutUsFragment);
            }
        });

        m_int = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        m_int.setType("*/*");
        m_int.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            IntentActivityLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode() == Activity.RESULT_OK){
                        try{
                            String path = PickUtils.getPath(getBaseContext(),result.getData().getData());
                            UpdateFragment.SetPath(path);
                            UpdateFragment.SetTips("\n固件路径: " + path + "\n");
                            onInitClickCallback(UpdateFragment);
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            });
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void initData() {
        ArrayList<BaseFragment> list = new ArrayList<>();
        m_epcArray = getIntent().getStringArrayListExtra("epcArray");
    }


    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            if(!onReturnCallback()) {
                return true;
            }
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    protected void onPause() {
            super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
