package com.fmsh.fmshrfid.sql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.fmsh.base.utils.LogUtil;

/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/11/9 10:56
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "rfid.db";
    private static final int DB_VERSION = 1;
    private static DatabaseHelper mHelper = null;
    private static SQLiteDatabase mReadDatabase = null;
    private static SQLiteDatabase mWriteDatabase = null;

    private static final String  TABLE_NAME = "chip";

    public static String getTableName() {
        return TABLE_NAME;
    }

    //单例模式
    public static DatabaseHelper getInstance(@Nullable Context context) {
        if (mHelper == null) {
            synchronized (DatabaseHelper.class) {
                if (mHelper == null) {
                    mHelper = new DatabaseHelper(context);
                }
            }
        }
        return mHelper;
    }
    public static DatabaseHelper getInstance(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        if (mHelper == null) {
            synchronized (DatabaseHelper.class) {
                if (mHelper == null) {
                    mHelper = new DatabaseHelper(context, name, factory, version);
                }
            }
        }
        return mHelper;
    }

    //构造方法，必须调用父类的构造方法，单例模式的构造方法需要是私有的。
    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    private DatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //打开写链接
    public SQLiteDatabase openWriteLink() {
        if (mWriteDatabase == null || !mWriteDatabase.isOpen()) {
            mWriteDatabase = mHelper.getWritableDatabase();
        }
        return mWriteDatabase;
    }

    //打开读链接
    public SQLiteDatabase openReadLink() {
        if (mReadDatabase == null || !mReadDatabase.isOpen()) {
            mReadDatabase = mHelper.getReadableDatabase();
        }
        return mReadDatabase;
    }

    //关闭链接
    public void closeLink() {
        if (mReadDatabase != null && mReadDatabase.isOpen()) {
            mReadDatabase.close();
            mReadDatabase = null;
        }
        if (mWriteDatabase != null && mWriteDatabase.isOpen()) {
            mWriteDatabase.close();
            mWriteDatabase = null;
        }
    }

    //数据库初始化时需要进行的一些操作，比如创建数据表
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" (" +
                "id VARCHAR(32) PRIMARY KEY  NOT NULL," +
                "name VARCHAR(32) NOT NULL UNIQUE," +
                "time TIMESTAMP DEFAULT CURRENT_TIMESTAMP );";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // 升级数据库版本时的操作
        LogUtil.d("onUpgrade","oldVersion--"+oldVersion+"newVersion---"+newVersion);
        String dropTableQuery = "DROP TABLE IF EXISTS "+TABLE_NAME+ "";
        sqLiteDatabase.execSQL(dropTableQuery);
        onCreate(sqLiteDatabase);
    }
}

