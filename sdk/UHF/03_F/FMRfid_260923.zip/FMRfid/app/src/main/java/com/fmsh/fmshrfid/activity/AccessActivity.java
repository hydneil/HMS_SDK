package com.fmsh.fmshrfid.activity;

import android.widget.ImageView;
import android.widget.TextView;

import com.fmsh.base.ui.BaseActivity;
import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.UIUtils;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.adapter.NonSwipeableViewPager;
import com.fmsh.fmshrfid.adapter.ViewPagerAdapter;
import com.fmsh.fmshrfid.fragment.LabelKillFragment;
import com.fmsh.fmshrfid.fragment.LabelLockFragment;
import com.fmsh.fmshrfid.fragment.LabelReadFragment;
import com.fmsh.fmshrfid.fragment.LabelWriteFragment;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * @author : Sunjun
 * @version : 0.0.1
 * @Date : 2023/9/15 11:01
 * @E-Mail : sunjun@fmsh.com.cn
 */
public class AccessActivity extends BaseActivity {
    @BindView(R.id.accessViewPager)
    NonSwipeableViewPager viewPager;
    @BindView(R.id.accessLayout)
    TabLayout tabLayout;
    public ArrayList<String> m_epcArray;
    private LabelReadFragment ReadFragment;
    private LabelWriteFragment WriteFragment;
    private LabelLockFragment LockFragment;
    private LabelKillFragment KillFragment;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_access;
    }

    @Override
    protected void initView() {
        setTitle(UIUtils.getString(mContext,R.string.title_activity_tag_access));
        viewPager.setSwipeEnabled(false);
    }

    @Override
    protected void initData() {
        ArrayList<BaseFragment> list = new ArrayList<>();
        m_epcArray =  getIntent().getStringArrayListExtra("epcArray");
        ReadFragment  = new LabelReadFragment();
        WriteFragment = new LabelWriteFragment();
        LockFragment  = new LabelLockFragment();
        KillFragment  = new LabelKillFragment();
        ReadFragment.onInit(m_epcArray);
        WriteFragment.onInit(m_epcArray);
        LockFragment.onInit(m_epcArray);
        KillFragment.onInit(m_epcArray);
        list.add(ReadFragment);
        list.add(WriteFragment);
        list.add(LockFragment);
        list.add(KillFragment);
        ViewPagerAdapter adapter = new ViewPagerAdapter(this, getSupportFragmentManager(), list);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tabAt = tabLayout.getTabAt(i);
            tabAt.setCustomView(adapter.getTabView(i));
        }

        tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                ImageView viewById = tab.getCustomView().findViewById(R.id.title_icon);
                TextView title = tab.getCustomView().findViewById(R.id.title);
                title.setTextColor(UIUtils.getColor(mContext, R.color.colorPrimary));
                switch (tab.getPosition()) {
                    case 0:
                        viewById.setImageResource(R.mipmap.read_press);
                        break;
                    case 1:
                        viewById.setImageResource(R.mipmap.write_press);
                        break;
                    case 2:
                        viewById.setImageResource(R.mipmap.lock_press);
                        break;
                    case 3:
                        viewById.setImageResource(R.mipmap.kill_press);
                        break;
                    default:
                        break;
                }


            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                ImageView viewById = tab.getCustomView().findViewById(R.id.title_icon);
                TextView title = tab.getCustomView().findViewById(R.id.title);
                title.setTextColor(UIUtils.getColor(mContext, R.color.qmui_config_color_gray_5));
                switch (tab.getPosition()) {
                    case 0:
                        viewById.setImageResource(R.mipmap.read_normal);
                        break;
                    case 1:
                        viewById.setImageResource(R.mipmap.write_normal);
                        break;
                    case 2:
                        viewById.setImageResource(R.mipmap.lock_normal);
                        break;
                    case 3:
                        viewById.setImageResource(R.mipmap.kill_normal);
                        break;
                    default:
                        break;
                }


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager.setCurrentItem(3);
        viewPager.setCurrentItem(2);
        viewPager.setCurrentItem(1);
        viewPager.setCurrentItem(0);

        //禁止页面切换重新onCreate
        viewPager.setOffscreenPageLimit(3);


    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
