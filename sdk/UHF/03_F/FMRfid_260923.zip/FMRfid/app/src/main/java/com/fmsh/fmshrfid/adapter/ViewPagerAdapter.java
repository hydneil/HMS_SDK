package com.fmsh.fmshrfid.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.UIUtils;
import com.fmsh.fmshrfid.R;

import java.util.ArrayList;


/**
 * @author wuyajiang
 * @date 2020/3/13
 */
public class ViewPagerAdapter extends FragmentPagerAdapter {
    private ArrayList<BaseFragment> mList ;
    private Context mContext;
    public ViewPagerAdapter(Context context, FragmentManager fragmentManager, ArrayList<BaseFragment> list){
        super(fragmentManager);
        this.mList = list;
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return mList.size();
    }



//    @Nullable
//    @Override
//    public CharSequence getPageTitle(int position) {
//        return UIUtils.getString(titles[position]);
//    }

    @Override
    public Fragment getItem(int i) {
        return mList.get(i);
    }

    public View getTabView(int position) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.tablayout_item, null);
        ImageView titleIcon = view.findViewById(R.id.title_icon);
        TextView title = view.findViewById(R.id.title);
        titleIcon.setImageResource(mList.get(position).getImageId());
        title.setText(mList.get(position).getTitle());
        title.setTextColor(UIUtils.getColor(mContext,R.color.qmui_config_color_gray_5));
        return view;
    }
}
