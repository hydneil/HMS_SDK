package com.fmsh.fmshrfid.fragment;

import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.fmsh.base.ui.BaseFragment;
import com.fmsh.base.utils.HintDialog;
import com.fmsh.fmshrfid.R;
import com.fmsh.fmshrfid.jni.RfidLibrary;
import com.fmsh.fmshrfid.utils.CircleProgressBar;
import com.fmsh.fmshrfid.utils.Constant;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

class Fifo_Struct
{
    int addr;
    byte[] data;
    String RdBuffer;
    int len;
    int pwd;
    char retries;
};
/**
 * @author : wuyajiang
 * @version : 0.0.1
 * @Date : 2023/7/17 09:19
 * @E-Mail : wuyajiang@fmsh.com.cn
 */
public class LabelFifoAccessFragment extends BaseFragment {
    @BindView(R.id.fifo_epc_filter_spinner)
    Spinner epc_fltr_Spinner;
    @BindView(R.id.fifo_read)
    Button but_fifo_read;
    @BindView(R.id.fifo_write)
    Button but_fifo_write;
    @BindView (R.id.FifoText)
    EditText FifoText;
    @BindView(R.id.fifo_password)
    EditText fifoPwd;
    @BindView(R.id.fifo_start_addr)
    EditText fifoStartAddr;
    @BindView(R.id.fifo_len)
    EditText fifoLen;
    @BindView(R.id.tv_fifo_count)
    TextView tvFifoCount;
    @BindView(R.id.circleProgressBar)
    CircleProgressBar circleProgressBar;

    private ArrayList<String> epcList;
    private QMUITipDialog loadingDialog;
    private Handler progressHandler;
    int cur_proto;
    int ind = 0;
    int process_desc = 0;
    long tiamStamp_1, tiamStamp_2;
    Fifo_Struct MS;

    private String HexToString(byte[] srcHex,int srcLen)
    {
        String strDst="";
        int i;
        for (i=0;i<srcLen;i++)
        {
            strDst += Integer.toHexString((srcHex[i]>>4)&0x0F).toUpperCase();
            strDst += Integer.toHexString(srcHex[i]&0x0F).toUpperCase();
        }
        return strDst;
    }

    private int StringToHex( String srcStr,byte[] dstByte)
    {
        int i;
        int len = srcStr.length();
        if((dstByte.length == 0)||((dstByte.length - 6)*2 != len))
        {
            return -1;
        }

        for (i=0;i<len/2;i+=2)
        {
            short data = (short)Integer.parseInt(srcStr.substring(i*2, (i+2)*2),16);
            dstByte[i+1] = (byte)((data>>8)&0xFF);
            dstByte[i] = (byte)(data&0xFF);
        }
        return 0;
    }
    private void EnAllCtrls(boolean en) {
        epc_fltr_Spinner.setEnabled(en);
        fifoPwd.setEnabled(en);
        fifoLen.setEnabled(en);
        fifoStartAddr.setEnabled(en);
        but_fifo_read.setEnabled(en);
        but_fifo_write.setEnabled(en);
        FifoText.setEnabled(en);
        if(en)
        {
            setBusy(Constant.FUNC_IN_READY);
        }
        else
        {
            setBusy(Constant.FUNC_IN_BUSY);
        }
    }
    public void onInit(ArrayList<String> epcs)
    {
        epcList = epcs;
        if((epcList!= null) && (epcList.size()>0))
        {
            String[] epcArray = (String[])epcList.toArray(new String[epcList.size()]);
            ArrayAdapter<String> epc_filter_adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_spinner_item, epcArray);
            epc_filter_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            epc_fltr_Spinner.setAdapter(epc_filter_adapter);

            cur_proto = RfidLibrary.GetCurProto();
            loadingDialog = HintDialog.loadingDialog(mContext);
            cur_proto = RfidLibrary.GetCurProto();
            circleProgressBar.setVisibility(View.GONE);
            circleProgressBar.setFirstColor(Color.LTGRAY);
            circleProgressBar.setSecondColor(Color.BLUE);
            circleProgressBar.setCircleWidth(6);
            //circleProgressBar.setBackgroundColor(Color.LTGRAY);
            progressHandler = new Handler(){
                @Override
                public void handleMessage(@NonNull Message msg) {
                    String errstr;
                    super.handleMessage(msg);
                    switch(msg.what)
                    {
                        case Constant.MSG_PROG_START_READ:
                        case Constant.MSG_PROG_START_WRITE:
                            circleProgressBar.setVisibility(View.VISIBLE);
                            circleProgressBar.setMax(msg.arg1);
                            circleProgressBar.setProgress(0);
                            break;
                        case Constant.MSG_PROG_UPDATE_READ:
                        case Constant.MSG_PROG_UPDATE_WRITE:
                            circleProgressBar.setProgress(msg.arg2);
                            break;
                        case Constant.MSG_PROG_SUCCESS_READ:
                            //tiamStamp_2 = System.currentTimeMillis();
                            circleProgressBar.setProgress(ind);
                            errstr = "读取成功:" + (ind * 1000) / (tiamStamp_2 - tiamStamp_1) +"字节每秒";
                            HintDialog.SuccessDialog(mContext, errstr);

                            tvFifoCount.setText("读取" + Integer.toString(ind)+"字数据");
                            FifoText.setText(MS.RdBuffer);
                            circleProgressBar.setVisibility(View.GONE);

                            EnAllCtrls(true);
                            break;
                        case Constant.MSG_PROG_FAILED_READ:
                            errstr = "读FIFO失败,读出" + msg.arg2 +"字数据, 标签状态码=" + String.format("%02X",(msg.arg1)&0xFF)+
                                    ", 操作状态码 =" + String.format("%02X", (msg.arg1>>8)&0xFF);
                            HintDialog.faileDialog(mContext, errstr);
                            circleProgressBar.setVisibility(View.GONE);
                            EnAllCtrls(true);
                            break;
                        case Constant.MSG_PROG_SUCCESS_WRITE:
                            //tiamStamp_2 = System.currentTimeMillis();
                            circleProgressBar.setProgress(ind);
                            errstr = "写入成功:" + (ind * 1000) / (tiamStamp_2 - tiamStamp_1) +"字节每秒";
                            HintDialog.SuccessDialog(mContext, errstr);

                            tvFifoCount.setText("写入" + Integer.toString(ind)+"字数据");
                            //FifoText.setText(MS.RdBuffer);
                            circleProgressBar.setVisibility(View.GONE);
                            EnAllCtrls(true);
                            break;
                        case Constant.MSG_PROG_FAILED_WRITE:
                            errstr = "写FIFO失败,写入" + msg.arg2 +"字数据, 标签状态码=" + String.format("%02X",(msg.arg1)&0xFF)+
                                    ", 操作状态码 =" + String.format("%02X", (msg.arg1>>8)&0xFF);
                            HintDialog.faileDialog(mContext, errstr);
                            circleProgressBar.setVisibility(View.GONE);
                            EnAllCtrls(true);
                            break;
                    }
                }
            };
        }
    }

    private int OnSetMatchRegister(){
        int stat = 0;
        if(epcList.size()>0) {
            String match_str = epcList.get(epc_fltr_Spinner.getSelectedItemPosition());
            stat = RfidLibrary.SetmatchRule(cur_proto, match_str, match_str.length());
        }
        return stat;
    }
    private int onMassReadThread(Fifo_Struct pMS)
    {
        int word_cnt = (pMS.len) >> 1;
        int m_len = 0;
        int m_retries, cut_len;
        int start_addr = pMS.addr;
        ind = 0;
        String tmpData = "";
        process_desc = 0;
        pMS.RdBuffer = "";
        tiamStamp_1 = System.currentTimeMillis();
        while (word_cnt > 0)
        {
            if (word_cnt > 128)
            {
                m_len = 128;
                word_cnt -= 128;
            }
            else
            {
                m_len = word_cnt;
                word_cnt = 0;
            }
            m_retries = pMS.retries;
            do
            {
                if (0 != RfidLibrary.ReadFifo(start_addr, pMS.data, m_len, pMS.pwd))
                {
                    if (m_retries > 0)
                    {
//                        if (m_len > 1)
//                        {
//                            cut_len = m_len / 2;
//                            word_cnt += cut_len;
//                            m_len -= cut_len;
//                        }
                        continue;
                    }
                    process_desc = 1;
                    SendProgressMsg(Constant.MSG_PROG_FAILED_READ,(pMS.data[0]<<8)|pMS.data[1],ind);
                    return process_desc;
                }
                else
                {
                    break;
                }
            } while ((m_retries--) > 0);
            tmpData = HexToString(pMS.data, m_len << 1);

            pMS.RdBuffer += tmpData;
            start_addr += m_len;
            ind += m_len;
            SendProgressMsg(Constant.MSG_PROG_UPDATE_READ,0,ind);
        }
        tiamStamp_2 = System.currentTimeMillis();
        process_desc = 2;
        SendProgressMsg(Constant.MSG_PROG_SUCCESS_READ,0,ind);
        return 0;
    }

    private int onMassWriteThread(Fifo_Struct pMS)
    {
        int word_cnt = (pMS.len) >> 1;
        int m_len = 0;
        int m_retries, cut_len;
        int start_addr = pMS.addr;
        ind = 0;
        String tmpData = "";
        process_desc = 0;
        pMS.RdBuffer = "";
        byte[]pbyte = new byte[128*2];
        tiamStamp_1 = System.currentTimeMillis();
        while (word_cnt > 0)
        {
            if (word_cnt > 128)
            {
                m_len = 128;
                word_cnt -= 128;
            }
            else
            {
                m_len = word_cnt;
                word_cnt = 0;
            }
            m_retries = pMS.retries;
            do
            {
                System.arraycopy(pMS.data, ind<<1, pbyte,0, m_len*2);
                if (0 != RfidLibrary.WriteFifo(start_addr, pbyte, m_len, pMS.pwd))
                {
                    if (m_retries > 0)
                    {
//                        if (m_len > 1)
//                        {
//                            cut_len = m_len / 2;
//                            word_cnt += cut_len;
//                            m_len -= cut_len;
//                        }
                        continue;
                    }
                    process_desc = 1;
                    SendProgressMsg(Constant.MSG_PROG_FAILED_WRITE,(pMS.data[0]<<8)|pMS.data[1],ind);
                    return process_desc;
                }
                else
                {
                    break;
                }
            } while ((m_retries--) > 0);
            tmpData = HexToString(pMS.data, m_len << 1);

            pMS.RdBuffer += tmpData;
            start_addr += m_len;
            ind += m_len;
            SendProgressMsg(Constant.MSG_PROG_UPDATE_WRITE,0,ind);
        }
        tiamStamp_2 = System.currentTimeMillis();
        process_desc = 2;
        SendProgressMsg(Constant.MSG_PROG_SUCCESS_WRITE,0,ind);
        return 0;
    }
    private void ReadFifoThread(Fifo_Struct s_MS){
        new Thread("ReadFifoThread"){
            @Override
            public void run(){
                onMassReadThread(s_MS);
            }
        }.start();
    }
    private void WriteFifoThread(Fifo_Struct s_MS){
        new Thread("WriteFifoThread"){
            @Override
            public void run(){
                onMassWriteThread(s_MS);
            }
        }.start();
    }
    private void SendProgressMsg(int msg_num,int arg1, int arg2)
    {
        Message msg = new Message();
        msg.what = msg_num;
        msg.arg1 = arg1;
        msg.arg2 = arg2;
        progressHandler.sendMessage(msg);
    }

    private void OnBnClickedBtnFifoRead(){
        FifoText.setText("");
        String stroffset = fifoStartAddr.getText().toString().trim();
        if ("".equals(stroffset)) {
            HintDialog.messageDialog(mContext, "请设置起始地址");
            EnAllCtrls(true);
            return;
        }
        String strwordcount = fifoLen.getText().toString().trim();
        if ("".equals(strwordcount)) {
            HintDialog.messageDialog(mContext, "请设置读取字数");
            EnAllCtrls(true);
            return;
        }
        String strpasswd = fifoPwd.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置访问口令");
            EnAllCtrls(true);
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            EnAllCtrls(true);
            return;
        }
        int offset = Integer.parseInt(stroffset);
        int wordcount = Integer.parseInt(strwordcount);
        int passwd = Integer.parseInt(strpasswd);
        MS = new Fifo_Struct();
        MS.data = new byte[4096];
        MS.addr = offset;
        MS.len = wordcount << 1;
        MS.pwd = passwd;
        MS.retries = 4;
        SendProgressMsg(Constant.MSG_PROG_START_READ, wordcount,0);
        ReadFifoThread(MS);
        return;
    }

    private void OnBnClickedBtnFifoWrite(){
        int stat = 0;
        String stroffset = fifoStartAddr.getText().toString().trim();
        if ("".equals(stroffset)) {
            HintDialog.messageDialog(mContext, "请设置起始地址");
            EnAllCtrls(true);
            return;
        }
        String strwordcount = fifoLen.getText().toString().trim();
        if ("".equals(strwordcount)) {
            HintDialog.messageDialog(mContext, "请设置写入字数");
            EnAllCtrls(true);
            return;
        }
        String strtext = FifoText.getText().toString().trim();
        if ("".equals(strtext)) {
            HintDialog.messageDialog(mContext, "请设置写入数据");
            EnAllCtrls(true);
            return;
        }
        String strpasswd = fifoPwd.getText().toString().trim();
        if ("".equals(strpasswd)) {
            HintDialog.messageDialog(mContext, "请设置访问口令");
            EnAllCtrls(true);
            return;
        }
        if (0 != OnSetMatchRegister())
        {
            HintDialog.successDialog(mContext, "EPC匹配失败");
            EnAllCtrls(true);
            return;
        }
        int offset = Integer.parseInt(stroffset);
        int wordcount = Integer.parseInt(strwordcount);
        if(wordcount*4 < strtext.length()){
            strtext = strtext.substring(0,wordcount*4);
        }
        else {
            int len =wordcount * 4 - strtext.length();
            for (int i = 0; i < len; i++) {
                strtext += "0";
            }
        }
        int passwd = Integer.parseInt(strpasswd);
        MS = new Fifo_Struct();
        MS.data = new byte[wordcount * 2 + 6];//防止wordcount=0时data为空 +6
        MS.addr = offset;
        MS.len = wordcount << 1;
        MS.pwd = passwd;
        MS.retries = 4;
        if(0 != StringToHex(strtext, MS.data)) {
            HintDialog.successDialog(mContext, "数据异常,检查数据长度、内容是否符合要求");
            EnAllCtrls(true);
            return;
        }
        SendProgressMsg(Constant.MSG_PROG_START_WRITE, wordcount,0);
        //tiamStamp_1 = System.currentTimeMillis();
        WriteFifoThread(MS);
        return;
    }
    @OnClick({R.id.fifo_read, R.id.fifo_write })
    public void onClick(View view) {
        EnAllCtrls(false);
        switch (view.getId()) {
            case R.id.fifo_read:
                OnBnClickedBtnFifoRead();
                break;
            case R.id.fifo_write:
                OnBnClickedBtnFifoWrite();
                break;
        }
    }
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_label_fifo_access;
    }

    @Override
    protected void initView(View view) {
    }

    @Override
    protected void initData() {
    }
    @Override
    public String getTitle() {
        return "Fifo Access";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
