package com.fmsh.base.handler;

import android.os.Bundle;

/**
 * @author wuyajiang
 * @date 2022/2/28
 */
public  interface UIHandlerCallback {
    void callback(Bundle bundle);
}
