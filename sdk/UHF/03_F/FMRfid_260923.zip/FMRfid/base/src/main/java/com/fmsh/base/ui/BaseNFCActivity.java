package com.fmsh.base.ui;

import android.app.PendingIntent;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.Settings;

import androidx.annotation.Nullable;

import com.fmsh.base.utils.BroadcastManager;
import com.qmuiteam.qmui.widget.dialog.QMUIDialog;

/**
 * @author wuyajiang
 * @date 2020/3/12
 */
public abstract class BaseNFCActivity extends BaseActivity {

    private NfcAdapter mNfcAdapter;
    private PendingIntent mPendingIntent;
    public Tag mTag;
    private QMUIDialog mQmuiDialog;
    public static final String KEY_TAG = "KEY_TAG";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkNfc();

        if (mNfcAdapter != null) {
            mPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE);
        }

    }

    public void startReaderMode() {
//        Bundle bundle = new Bundle();
//        bundle.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 500);
        mNfcAdapter.enableReaderMode(this, new NfcAdapter.ReaderCallback() {
            @Override
            public void onTagDiscovered(Tag tag) {
                mTag = tag;
                Bundle bundle = new Bundle();
                bundle.putParcelable(KEY_TAG, mTag);
                BroadcastManager.getInstance(mContext).sendBroadcast(KEY_TAG, bundle);
                if(nfcReaderCallback!= null){
                    nfcReaderCallback.onTagDiscovered(tag);
                }
            }

        }, NfcAdapter.FLAG_READER_NFC_A , null);
    }

    public NFCReaderCallback nfcReaderCallback;
    public void  setNfcReaderCallback(NFCReaderCallback nfcReaderCallback){
        if(nfcReaderCallback != null){
            this.nfcReaderCallback = nfcReaderCallback;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        //设置优先与所有NFC的处理
        startReaderMode();
        if (mNfcAdapter != null) {
            /**
             * 设置前台识别过滤 为null都识别
             */
            mNfcAdapter.enableForegroundDispatch(this, mPendingIntent, null, null);
        }

    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mNfcAdapter != null) {
            mNfcAdapter.disableForegroundDispatch(this);
            mNfcAdapter.disableReaderMode(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        BroadcastManager.getInstance(mContext).destroy(KEY_TAG);
    }

    private void checkNfc() {
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter != null) {
            if (!mNfcAdapter.isEnabled()) {
                Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
                startActivity(intent);
            }
        }
    }




}
