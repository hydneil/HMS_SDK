package com.fmsh.base.utils;

import com.fmsh.base.R;
import com.qmuiteam.qmui.widget.dialog.QMUIDialog;
import com.qmuiteam.qmui.widget.dialog.QMUIDialogAction;

/**
 * @author wuyajiang
 * @date 2022/3/1
 */
public class NFCDialog {
    private static QMUIDialog mQmuiDialog;
    public static void showNfcDialog() {
        if (mQmuiDialog == null) {
            mQmuiDialog = new QMUIDialog.CustomDialogBuilder(ActivityUtils.instance.getCurrentActivity())
                    .setLayout(R.layout.dialog_nfc_hint).addAction("取消", new QMUIDialogAction.ActionListener() {
                        @Override
                        public void onClick(QMUIDialog dialog, int index) {
                            dialog.dismiss();
                        }
                    }).create(R.style.DialogTheme2);
            mQmuiDialog.show();
        } else {
            mQmuiDialog.show();
        }
    }
    public static void dismissNfcDialog(){
        if(mQmuiDialog != null){
            mQmuiDialog.dismiss();
        }
    }

    public static boolean isShow(){
        if(mQmuiDialog!=null &&  mQmuiDialog.isShowing()){
            return true;
        }
        return false;
    }
}
