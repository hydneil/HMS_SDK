package com.fmsh.base.handler;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import androidx.annotation.NonNull;

/**
 * @author wuyajiang
 * @date 2022/2/28
 */
public  class BaseHandler extends Handler {
    private static BaseHandler baseHandler =new BaseHandler();

    public static BaseHandler getInstance(){
        return baseHandler;
    }

    private BaseHandler(){

    }
    private UIHandlerCallback mUIHandlerCallback;

    @Override
    public void handleMessage(@NonNull Message msg) {
        super.handleMessage(msg);
        Bundle data = msg.getData();
        if(data == null){
            data = new Bundle();
            data.putInt("what",msg.what);
        }

        if(mUIHandlerCallback != null){
            mUIHandlerCallback.callback(data);
        }





    }

    public void setUIHandlerCallback(UIHandlerCallback UIHandlerCallback) {
        mUIHandlerCallback = UIHandlerCallback;
    }
}
