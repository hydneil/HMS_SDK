package com.fmsh.base.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fmsh.base.utils.BroadcastManager;

import butterknife.ButterKnife;

/**
 * @author wuyajiang
 * @date 2020/3/10
 */
public abstract class BaseFragment extends Fragment  {


    public String TAG = this.getClass().getSimpleName();
    public Context mContext;
    public BaseNFCActivity mActivity;

    public int m_busy;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
        if(getActivity() instanceof BaseNFCActivity){
            this.mActivity = (BaseNFCActivity) getActivity();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(getLayoutId(),container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this,view);
        initView(view);
        initData();
    }

    protected abstract int getLayoutId();

    protected abstract void initView(View view);

    protected abstract void initData();
    public String getTitle(){
        return "";
    }

    public void setBusy(int en){
        m_busy = en; }
    public int getBusy(){
        return m_busy;
    }

    public  int getImageId(){
        return 0;
    }

    public void startActivity(Bundle bundle, Class<?> cla){
        Intent intent = new Intent(getActivity(), cla);
        if(bundle != null){
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        BroadcastManager.getInstance(mContext).destroy(BaseNFCActivity.KEY_TAG);
    }




}
