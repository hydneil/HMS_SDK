package com.fmsh.base.ui;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.LayoutRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.fmsh.base.R;
import com.fmsh.base.utils.ActivityUtils;
import com.fmsh.base.utils.HintDialog;
import com.qmuiteam.qmui.util.QMUIStatusBarHelper;
import com.qmuiteam.qmui.widget.QMUITopBarLayout;
import com.qmuiteam.qmui.widget.dialog.QMUIDialog;
import com.qmuiteam.qmui.widget.dialog.QMUIDialogBuilder;
import com.qmuiteam.qmui.widget.dialog.QMUIDialogView;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.io.FileNotFoundException;
import java.io.IOException;

import butterknife.ButterKnife;


/**
 * @author wuyajiang
 * @date 2020/3/10
 */
public abstract class BaseActivity extends AppCompatActivity {
    public String TAG = this.getClass().getSimpleName();
    public Context mContext;
    public QMUITopBarLayout mTopBar;
    public QMUITipDialog mQmuiTipDialog;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());
        ButterKnife.bind(this);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mTopBar = findViewById(R.id.topbar);
        ActivityUtils.instance.addActivity(this);
        QMUIStatusBarHelper.translucent(this);
        this.mContext = this;
        mQmuiTipDialog = HintDialog.loadingDialog(this);
        initView();
        initData();

    }

    protected abstract int getLayoutId();

    protected abstract void initView();

    protected abstract void initData();

    @Override
    protected void onDestroy() {
        ActivityUtils.instance.removeActivity(this);
        super.onDestroy();
    }

    /**
     * 设置标题
     *
     * @param title
     */
    public void setTitle(String title) {
        if (mTopBar != null) {
            mTopBar.setTitle(title);
        }
    }

    /**
     * 设置标题的位置
     *
     * @param Gravity
     */
    public void setTitleGravity(int Gravity) {
        if (mTopBar != null) {
            mTopBar.setTitleGravity(Gravity);
        }
    }

    /**
     * 设置是否显示返回按钮
     */
    public void setBackImage() {
        if (mTopBar != null) {
            mTopBar.addLeftBackImageButton().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    });

                }
            });
        }
    }


    public void startActivity(Bundle bundle, Class<?> cla) {
        Intent intent = new Intent(this, cla);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    /**
     * 自定义对话框内容区域的 Builder
     */
    public static class CustomDialogBuilder extends QMUIDialogBuilder {

        private int mLayoutId;
        private View mInflate;

        public CustomDialogBuilder(Context context) {
            super(context);
        }

        /**
         * 设置内容区域的 layoutResId
         *
         * @return
         */
        public CustomDialogBuilder setLayout(@LayoutRes int layoutResId) {
            mLayoutId = layoutResId;
            return this;
        }

        public View getInflate() {
            return mInflate;
        }

        public CustomDialogBuilder setLayout(View view) {
            mInflate = view;
            return this;
        }

        @Nullable
        @Override
        protected View onCreateContent(QMUIDialog dialog, QMUIDialogView parent, Context context) {
            if (mLayoutId != 0) {
                mInflate = LayoutInflater.from(context).inflate(mLayoutId, parent, false);
            }
            return mInflate;
        }
    }


}
