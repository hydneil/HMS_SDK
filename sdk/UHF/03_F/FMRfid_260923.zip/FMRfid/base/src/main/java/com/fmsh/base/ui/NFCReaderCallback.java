package com.fmsh.base.ui;

import android.nfc.Tag;

public interface NFCReaderCallback {
    void onTagDiscovered(Tag tag);
}
