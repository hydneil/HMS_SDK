package com.example.module_android_demo;

import java.util.HashMap;
import java.util.Map;

import com.function.CallbackBundle;
import com.pow.api.cls.RfidPower;
import com.uhf.api.cls.R2000Command;
import com.uhf.api.cls.Reader;
import com.uhf.api.cls.Reader.READER_ERR;
import com.zguang.api.comm.linuxcomm;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Dialog;


public class UpdateActivity extends Activity {
	
	private MyApplication myapp;
	Button button_selectfile,button_selectfile2,button_stupdate;
	 static private int openfileDialogId = 0; 
	 private final int HandlerorPlatBoard=0;//0�ֻ�1ƽ��
	 ProgressBar prb;
	 String filename;
	 String serialportPath;
	 public Message amsg;
	 private Thread runthread;
	 String fileexten="mdfw";
	 Dialog dialog;
	 linuxcomm lreader;

	 Runnable Run=new Runnable(){
       
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				//serialportPath=myapp.Address;
				String devstr="";
				int baudrate=115200;
				if(myapp.Rpower.GetType()!=RfidPower.PDATYPE.NONE)
				serialportPath=myapp.Rpower.GetDevPath();
				else
					serialportPath=myapp.Address;
                baudrate=myapp.Baudrate;
				if(myapp.Mreader!=null&&myapp.haveinit)
				myapp.Mreader.CloseReader();
				myapp.Rpower.PowerUp();
				READER_ERR err=READER_ERR.MT_OK_ERR;
				String errmsg="";
				if(fileexten.equals("mdfw"))
					err=Reader.FirmwareLoadFromSerialPort(serialportPath,filename);
				else
				{
					try{
						lreader=new linuxcomm();
						String[] parscom=null;

						if(serialportPath.contains(":")) {
							parscom = serialportPath.split(":");
							devstr=parscom[0].trim();
							baudrate=Integer.parseInt(parscom[1]);
						}
						else
							devstr=serialportPath;
						int re=lreader.OpenComm(devstr,baudrate);

						if(re!=0)
							throw new Exception("openserial err:"+String.valueOf(re)+" "+devstr+" "+String.valueOf(baudrate));
						lreader.InitStream();
						R2000Command.is = lreader.getInputStream();
						R2000Command.os = lreader.getOutputStream();

						final Exception[] threadex = {null};
						final float[] finalVal = new float[1];

						new Thread(new Runnable(){

							@Override
							public void run() {
								try {
									R2000Command.Updatebyserial(filename, finalVal);
									return;
								} catch (Exception e) {
									threadex[0] =e;
								}
							}
						}).start();

						do {
							if (threadex[0] != null)
							{	throw threadex[0];}
							if(finalVal[0]>=1)
								break;

							Message msg = new Message();
							msg.what = 0;
							Bundle bundle = new Bundle();
							bundle.putFloat("ps", (float)finalVal[0]);
							msg.setData(bundle);
							handler.sendMessage(msg);
							Thread.sleep(500);
						}
						while (true);

					}catch (Exception ex)
					{
						err=READER_ERR.MT_OTHER_ERR;
						errmsg="("+devstr+" "+String.valueOf(baudrate)+")"+ ex.getMessage();
					}
					finally
					{
						if(R2000Command.is!=null)
							R2000Command.is.close();
						if(R2000Command.os!=null)
							R2000Command.os.close();
						if(lreader!=null)
							lreader.CloseStream();
					}
				}
				Message msg = new Message(); 
				 Bundle bundle = new Bundle();  
				 msg.what = 2; 
				if(err!=READER_ERR.MT_OK_ERR)
                    bundle.putCharSequence("ps", "ʧ��:"+err.toString()+" "+errmsg);
				else
                    bundle.putCharSequence("ps", "�ɹ�:���������Ӷ�д��:"+err.toString());
				 msg.setData(bundle);  
				handler.sendMessage(msg);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				    Message msg = new Message(); 
      		    
	                msg.what = 1;  
	                Bundle bundle = new Bundle();  
	                
	                bundle.putCharSequence("ps", e.toString());
	               
	                msg.setData(bundle);  
				    handler.sendMessage(msg);
			}
		}
		 
	 };
	 
	 public  Handler handler = new Handler()  
	    {  
			
	        public void handleMessage(Message msg)  
	        {  
	            switch (msg.what)  
	            {  
	            case 0:  
	                {  
	                    //ȡ���������¿ؼ�  
	                	Bundle bd=msg.getData();
	                	float v=bd.getFloat("ps");
	                	float vps=v*100;
	            		TextView et= (TextView)findViewById(R.id.textView_ps);
	            		String vstr=String.valueOf(vps);
	            		vstr=vstr.substring(0,vstr.indexOf(".")+2)+"%";
	            		et.setText(vstr);
	            		et.refreshDrawableState();
	            		if(!vstr.contains("ʧ��"))
		            		prb.setProgress((int)(v*100));
	                }  
	                break;  
	            case 1:  
	            {
	            	Bundle bd=msg.getData();
                	String v=(String) bd.getCharSequence("ps");
                	TextView et= (TextView)findViewById(R.id.textView_ps);
            		 
            		et.setText(v);
            		prb.setProgress(0);
	            }
	            break;
	            case 2:
	            {
	            	Bundle bd=msg.getData();
                	String v=(String) bd.getCharSequence("ps");
                	 TextView et= (TextView)findViewById(R.id.textView_ps);
                     if(!v.contains("ʧ��")) {
                         et.setText("100%-"+v);
                         et.refreshDrawableState();
                         prb.setProgress(100);
                     }
                     else
                    	 et.setText("0%-"+v);
					Toast.makeText(UpdateActivity.this, v,
							Toast.LENGTH_SHORT).show();
	            }
	            default:  
	                break;  
	            }  
	            super.handleMessage(msg);  
	        }  
	          
	    };  
	      
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update);
		button_selectfile=(Button)this.findViewById(R.id.button_selectfile);
		button_selectfile.setOnClickListener(new View.OnClickListener(){

			@SuppressWarnings("deprecation")
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				fileexten="mdfw";
				showDialog(openfileDialogId);  
				
			}
 	 
		});
		
		button_selectfile2=(Button)this.findViewById(R.id.button_selectfile2);
		button_selectfile2.setOnClickListener(new View.OnClickListener(){

			@SuppressWarnings("deprecation")
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				fileexten="bin";
				showDialog(openfileDialogId);  
				
			}
 	 
		});
		
		button_stupdate=(Button)this.findViewById(R.id.button_startupdate);
		button_stupdate.setOnClickListener(new View.OnClickListener() {
		 
			@Override
			public void onClick(View arg0) {
				filename="";
				// TODO Auto-generated method stub
				TextView et=(TextView)findViewById(R.id.textView_path);
				 filename=(String) et.getText();
				if(filename.isEmpty()||filename.endsWith("path"))
				{
					 Toast.makeText(UpdateActivity.this, "ѡ�������ļ�/*."+fileexten,
								Toast.LENGTH_SHORT).show();
					 return ;
				}
			 
				try {
					 
					runthread=new Thread(Run);
					runthread.start();
	                 
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Toast.makeText(UpdateActivity.this, "����ʧ��",
							Toast.LENGTH_SHORT).show();
				 return ;
				}
				 prb.setProgress(0);
				Toast.makeText(UpdateActivity.this, "������ʼ",
						Toast.LENGTH_SHORT).show();
			}
		});
		
		prb=(ProgressBar) findViewById(R.id.progressBar1);

		myapp=(MyApplication) getApplication(); 
	 
	}
	
	protected void dialog1() {
		  AlertDialog.Builder builder = new Builder(UpdateActivity.this);
		  builder.setMessage("��ȷ��������д���Ƿ��ڸ��ϵ�����״̬��");

		  builder.setTitle("��ʾ");

		  builder.setPositiveButton("��", new OnClickListener() {

		   @Override
		   public void onClick(android.content.DialogInterface dialog, int which) {
		    dialog.dismiss();

		    UpdateActivity.this.finish();
		   }
 
		  });

		  builder.setNegativeButton("��", new OnClickListener() {

		   @Override
		   public void onClick(DialogInterface dialog, int which) {
		    dialog.dismiss();
		   }
		  });

		  builder.create().show();
		 }
 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override  
	   protected Dialog onCreateDialog(int id) {  
	        if(id==openfileDialogId){  
	            Map<String, Integer> images = new HashMap<String, Integer>();  
	           // ���漸�����ø��ļ����͵�ͼ�꣬ ��Ҫ���Ȱ�ͼ�����ӵ���Դ�ļ���   
	           images.put(OpenFileDialog.sRoot, R.drawable.filedialog_root);   // ��Ŀ¼ͼ��   
               images.put(OpenFileDialog.sParent, R.drawable.filedialog_folder_up);    //������һ���ͼ��   
	           images.put(OpenFileDialog.sFolder, R.drawable.filedialog_folder);   //�ļ���ͼ��   
	           images.put(fileexten, R.drawable.filedialog_file);  
	          //images.put("wav", R.drawable.filedialog_wavfile);   //wav�ļ�ͼ��   //wav�ļ�ͼ��   
	            images.put(OpenFileDialog.sEmpty, R.drawable.filedialog_root);  
	            dialog= OpenFileDialog.createDialog(id, this, "���ļ�", new CallbackBundle() {  
	                @Override  
	              public void callback(Bundle bundle) {  
	                  String filepath = bundle.getString("path");  
	                 // setTitle(filepath); // ���ļ�·����ʾ�ڱ�����   
	                  TextView et=(TextView)findViewById(R.id.textView_path);
	  				  et.setText(filepath);
	  				 dialog.dismiss();
	  				 removeDialog(openfileDialogId);
	                }  
	               
                },   
	           "."+fileexten+";",  
	          images); 
	            
	            dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
             	   @Override
             	   public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event)
             	   {
             	   if (keyCode == KeyEvent.KEYCODE_BACK)
             	    {
             		    removeDialog(openfileDialogId);
             	      
             	    }
             	    return true;
             	   }
             	  });
	        return dialog;  
	        
	      }  
	     return null;  
	   }  
}
