LOCAL_PATH:= $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE_TAGS := optional
LOCAL_SRC_FILES := $(call all-java-files-under,app/src/main/java)
LOCAL_PACKAGE_NAME := Test
LOCAL_SDK_VERSION := current
#LOCAL_PROGUARD_FLAG_FILES := prog

LOCAL_USE_AAPT2 := true

#ָ��Manifest�ļ�
LOCAL_MANIFEST_FILE := app/src/main/AndroidManifest.xml

LOCAL_RESOURCE_DIR := $(addprefix $(LOCAL_PATH)/,app/src/main/res)

#�ظ���Դ�Զ�����
LOCAL_AAPT_FLAGS += \
    --auto-add-overlay \
    --extra-packages androidx.appcompat.app \
    --extra-packages androidx.recyclerview.recyclerview.widget \

#constraint-layout ��Ҫ��jar
LOCAL_STATIC_JAVA_LIBRARIES := \
    androidx.appcompat_appcompat \
    androidx.recyclerview_recyclerview \


include $(BUILD_PACKAGE)

# Use the folloing include to make our test apk.
include $(call all-makefiles-under,$(LOCAL_PATH))