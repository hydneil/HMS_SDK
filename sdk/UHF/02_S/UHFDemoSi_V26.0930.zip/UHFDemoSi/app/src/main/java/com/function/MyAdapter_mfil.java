package com.function;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import java.util.ArrayList;
import java.util.HashMap;

import com.example.module_android_demo.R;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;

/**
 * ����ѡ�Զ���list������
 *
 * @author Administrator
 *
 */
public class MyAdapter_mfil extends BaseAdapter {
    // ������ݵ�list
    private ArrayList<String> list;
    //��ѡ�е�����
    private ArrayList<String> slist;
    // ��������CheckBox��ѡ��״��
    private static HashMap<Integer, Boolean> isSelected;
    // �������벼��
    private LayoutInflater inflater = null;

    // ������
    @SuppressLint("UseSparseArrays")
    public MyAdapter_mfil(ArrayList<String> list,ArrayList<String> slist, Context context) {
        this.list = list;
        this.slist=slist;
        inflater = LayoutInflater.from(context);
        isSelected = new HashMap<Integer, Boolean>();
        // ��ʼ������
        initDate();
    }

    // ��ʼ��isSelected������
    private void initDate() {
        for (int i = 0; i < list.size(); i++) {

            if(slist.contains(list.get(i)))
                getIsSelected().put(i, true);
        else
                getIsSelected().put(i, false);


        }
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder_mfil holder = null;
        if (convertView == null) {
            // ���ViewHolder����
            holder = new ViewHolder_mfil();
            // ���벼�ֲ���ֵ��convertview
            convertView = inflater.inflate(R.layout.listitemview_mfil, null);

            holder.cb = (CheckBox) convertView.findViewById(R.id.checkBox_fltag);
            // Log.d("SLB4.0", (String)getItem(position));

            // Ϊview���ñ�ǩ
            convertView.setTag(holder);
        } else {
            // ȡ��holder
            holder = (ViewHolder_mfil) convertView.getTag();
        }
        holder.cb.setText((String) getItem(position));
        // ����isSelected������checkbox��ѡ��״��
        holder.cb.setChecked(getIsSelected().get(position));

        return convertView;
    }

    public static HashMap<Integer, Boolean> getIsSelected() {
        return isSelected;
    }

    public static void setIsSelected(HashMap<Integer, Boolean> isSelected) {
        MyAdapter_mfil.isSelected = isSelected;
    }

    public static class ViewHolder_mfil {
        public CheckBox cb;
    }
}
