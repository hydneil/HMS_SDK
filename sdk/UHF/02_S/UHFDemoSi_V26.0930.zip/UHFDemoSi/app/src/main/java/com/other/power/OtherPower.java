package com.other.power;

import android.content.Context;

//import android.app.*;


public class OtherPower {
   // �ϲ�ӿڣ��ڽӿ���ʵ�־�����ֳֻ�ƽ̨�ϵ磬���緽��
   public static boolean isotherpowerup = true;
	public static Context Ctt;
    public static String OpAddr = "/dev/ttyHS1";
    public static boolean oPowerUp()
    {
        PowerUtils.powerCtrl(PowerUtils.VCC_RFID_UP);
        return true;
    }

    public static boolean oPowerDown()
    {
        PowerUtils.powerCtrl(PowerUtils.VCC_RFID_DOWN);
        return true;
    }
}
