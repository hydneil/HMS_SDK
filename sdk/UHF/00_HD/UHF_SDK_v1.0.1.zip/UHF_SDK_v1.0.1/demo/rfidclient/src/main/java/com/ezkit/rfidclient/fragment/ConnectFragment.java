package com.ezkit.rfidclient.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.ezkit.rfidclient.R;
import com.ezkit.rfidclient.RfidClientApplication;
import com.ezkit.rfidclient.model.SharedViewModel;
import com.ezkit.rfidclient.util.ToastUtil;

import net.ezkit.rfid.RfidManager;
import net.ezkit.rfid.bean.UHFInformation;
import net.ezkit.rfid.util.Constant;
import net.ezkit.rfid.util.LogUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ConnectFragment extends BaseFragment {

    private EditText mAddressEdit;
    private Spinner mRateSpinner;
    private ArrayAdapter adapter;

    private Button mConnect;
    private Button mDisconnect;
    private TextView mUHFInfo;
    private UHFInformation uhfInformation;

    private String mAddress = "/dev/ttyHS1";// sprd use "/dev/ttyS0";
    private int mRate = 115200;
    String[] strBaudRate = {"57600", "115200"};
    private ViewPager mViewPager;
    RfidManager rfidManager ;
    private ProgressDialog mWaitingDialog;
    private SharedViewModel sharedViewModel;
    private static final int MSG_TIMER = 1;
    private static final int MSG_CONTROL_SERVICES = 2;
    private static final int MSG_WAITING_DIALOG_TIMER = 3;
    private Handler mMessageHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_WAITING_DIALOG_TIMER:
                    stopWaitingDialog();
                    break;
            }
        }
    };

    public ConnectFragment(){
    }

    public ConnectFragment(ViewPager mViewPager) {
        this.mViewPager = mViewPager;
    }


    @Override
    public void onStart() {
        super.onStart();
        // 注册事件总线
        EventBus.getDefault().register(this);
        if (!RfidClientApplication.getInstance().serviceConnected){
            showWaitingDialog(getString(R.string.str_waiting_title),getString(R.string.str_waiting_service_msg),5000);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMyEvent(Integer msg) {
        if (msg == Constant.DeviceState.OPEN_SUCCESSFUL){
            if (mViewPager != null){
                mDisconnect.setEnabled(true);
                mConnect.setEnabled(false);
                uhfInformation = rfidManager.getUHFInformation();
                updateUHFInformation(rfidManager.getDeviceID());
                RfidClientApplication.getInstance().mDeviceConnected = true;
                int baudRate = rfidManager.getBaudRate();
                mRateSpinner.setSelection(baudRate == 115200 ? 1 : 0);
                mViewPager.setCurrentItem(1);
            }
            stopWaitingDialog();
        } else if (msg == Constant.DeviceState.OPEN_FAILED){
            ToastUtil.showToast(getContext(), getString(R.string.str_connect_failed));
            stopWaitingDialog();
        } else if (msg == Constant.DeviceState.SERVICE_CONNECTED){
            stopWaitingDialog();
            rfidManager = RfidClientApplication.getInstance().getRfidManager();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_connect, container, false);
        mRateSpinner = view.findViewById(R.id.sp_rate);
        mAddressEdit = view.findViewById(R.id.edit_address);
        mAddressEdit.setText(mAddress);
        mConnect = view.findViewById(R.id.connect);
        mDisconnect = view.findViewById(R.id.disconnect);
        mUHFInfo = view.findViewById(R.id.uhf_info);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strBaudRate);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mRateSpinner.setAdapter(adapter);
        mRateSpinner.setSelection(1);
        mDisconnect.setEnabled(false);
        mConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRate =  Integer.parseInt((String) mRateSpinner.getSelectedItem());
                if (rfidManager != null){
                    rfidManager.connect(mRate);
                    showWaitingDialog(getString(R.string.str_waiting_title),getString(R.string.str_waiting_module_msg),0);
                } else {
                    ToastUtil.showToast(getContext(),getString(R.string.str_connect_service_not_connected));
                    rfidManager = RfidClientApplication.getInstance().getRfidManager();
                }
            }
        });

        mDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RfidManager rfidManager = RfidClientApplication.getInstance().getRfidManager();
                if (rfidManager != null){
                    rfidManager.disConnect();
                    RfidClientApplication.getInstance().mDeviceConnected = false;
                    mUHFInfo.setText("");
                    sharedViewModel.sendClearDataEvent();
                } else {
                    rfidManager = RfidClientApplication.getInstance().getRfidManager();
                    ToastUtil.showToast(getContext(),getString(R.string.str_connect_service_not_connected));
                }
                mConnect.setEnabled(true);
                mDisconnect.setEnabled(false);
            }
        });
    }
    private void updateUHFInformation(String sn){
        if (uhfInformation!=null){
            mUHFInfo.setText("Version:"+uhfInformation.getVersion()+ "\r\nSerial Number:"+sn);
        }
    }

    private void showWaitingDialog(String title, String message,int timeout) {
        boolean isFinishingFlag = getActivity().isFinishing();
        if (!isFinishingFlag) {
            if (mWaitingDialog == null) {
                mWaitingDialog = new ProgressDialog(getContext());
                mWaitingDialog.setIndeterminate(true);
                mWaitingDialog.setCancelable(false);
            }
            mWaitingDialog.setTitle(new String(title));
            mWaitingDialog.setMessage(message);
            try {
                mWaitingDialog.show();
            } catch (WindowManager.BadTokenException bte) {
                bte.printStackTrace();
            }
            mMessageHandler.removeMessages(MSG_WAITING_DIALOG_TIMER);
            if (timeout > 0) {
                mMessageHandler.sendMessageDelayed(
                        mMessageHandler.obtainMessage(MSG_WAITING_DIALOG_TIMER, message), timeout);
            }
        }
    }

    private synchronized void stopWaitingDialog() {
        mMessageHandler.removeMessages(MSG_WAITING_DIALOG_TIMER);
        if (mWaitingDialog != null) {
            try {
                mWaitingDialog.cancel();
                mWaitingDialog = null;
            } catch (IllegalArgumentException e) {
                mWaitingDialog = null;
            }
        }
    }

}
