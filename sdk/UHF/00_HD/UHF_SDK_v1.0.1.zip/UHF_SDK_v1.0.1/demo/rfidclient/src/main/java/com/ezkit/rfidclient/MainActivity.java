package com.ezkit.rfidclient;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import net.ezkit.rfid.IRfidFramework;
import net.ezkit.rfid.bean.ReadTagData;
import net.ezkit.rfid.callback.IRfidCallback;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private Button mInventory;
    private Button mInventoryOnce;
    private Button mStopInventory;
    private Button mFindEpc;
    private IRfidFramework mRfidFramework;
//    private String devport = "/dev/ttyHS1";
    private ListView mLvTags;
    SimpleAdapter adapter;
    private ArrayList<HashMap<String, String>> tagList;
    private HashMap<String, String> map;

    private RfidCallback mRfidCallback = new RfidCallback();

    private static final int MSG_UPDATE_LISTVIEW = 0;
    private Handler handler = new Handler(){
        @Override
        public void dispatchMessage(@NonNull Message msg) {
            super.dispatchMessage(msg);
            if (msg.what == MSG_UPDATE_LISTVIEW){
                String result = msg.obj + "";
                String[] strs = result.split(",");
                if (strs.length == 2) {
                    addEPCToList(strs[0], strs[1]);
                } else {
                    addEPCToList(strs[0] + "," + strs[1], strs[2]);
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mInventory = findViewById(R.id.BtInventory);
        mInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mRfidFramework!=null){
                        mRfidFramework.startInventory();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mStopInventory = findViewById(R.id.BtStopInventory);
        mStopInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mRfidFramework!=null){
                        mRfidFramework.stopInventory();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mInventoryOnce = findViewById(R.id.BtStartInventoryOnce);
        mInventoryOnce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mRfidFramework!=null){
                        mRfidFramework.startInventoryOnce();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mFindEpc = findViewById(R.id.FindEpc);
        mFindEpc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mRfidFramework!=null){
                        HashMap<String, String> item = tagList.get(0);
                        ReadTagData readTagData = mRfidFramework.findEPC(item.get("tagUii"));
                        mRfidCallback.handleReadTag(readTagData);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mLvTags = findViewById(R.id.LvTags);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("net.ezkit.rfid","net.ezkit.rfid.RfidService"));
        intent.setPackage("net.ezkit.rfid");
        bindService(intent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                Toast.makeText(getApplicationContext(),"connect service",Toast.LENGTH_SHORT).show();
                Log.d("neil",">>>>>>>>>>>>>>>>>>> onServiceConnected <<<<<<<<<<<<<<<<<<<<<<<<<");
                mRfidFramework = IRfidFramework.Stub.asInterface(iBinder);
                try {
                    if (mRfidFramework!=null){
                       mRfidFramework.connect(115200);
                        if (true){
                            mRfidFramework.setRfidCallBack(mRfidCallback);
                        }else {
                            Log.d("neil","connect faild");
                        }
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                Log.d("neil",">>>>>>>>>>>>>>>>>>> onServiceDisconnected <<<<<<<<<<<<<<<<<<<<<<<<<");

                mRfidFramework = null;
            }
        }, Context.BIND_AUTO_CREATE);
        tagList = new ArrayList<HashMap<String, String>>();
        adapter = new SimpleAdapter(this, tagList, R.layout.listtag_items,
                new String[]{"tagUii", "tagLen", "tagCount", "tagRssi"},
                new int[]{R.id.TvTagUii, R.id.TvTagLen, R.id.TvTagCount,
                        R.id.TvTagRssi});
        mLvTags.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (mRfidFramework!=null){
                mRfidFramework.disConnect();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void addEPCToList(String rfid, String rssi) {
        if (!TextUtils.isEmpty(rfid)) {
            String epc = "";
            String[] data = rfid.split(",");
            if (data.length == 1) {
                epc = data[0];
            } else {
                epc = "EPC:" + data[0] + "\r\nMem:" + data[1];
            }

            int index = checkIsExist(epc);
            map = new HashMap<String, String>();

            map.put("tagUii", epc);
            map.put("tagCount", String.valueOf(1));
            map.put("tagRssi", rssi);
            if (index == -1) {
                tagList.add(map);
                mLvTags.setAdapter(adapter);
//                mlist.add(data[0]);
            } else {
                int tagcount = Integer.parseInt(
                        tagList.get(index).get("tagCount"), 10) + 1;

                map.put("tagCount", String.valueOf(tagcount));

                tagList.set(index, map);

            }
            adapter.notifyDataSetChanged();

        }
    }
    public int checkIsExist(String strEPC) {
        int existFlag = -1;
        if (strEPC == null || strEPC.length() == 0) {
            return existFlag;
        }
        String tempStr = "";
        for (int i = 0; i < tagList.size(); i++) {
            HashMap<String, String> temp = new HashMap<String, String>();
            temp = tagList.get(i);
            tempStr = temp.get("tagUii");
            if (strEPC.equals(tempStr)) {
                existFlag = i;
                break;
            }
        }
        return existFlag;
    }
    private class RfidCallback extends IRfidCallback.Stub{

        @Override
        public void deviceStateChange(int state){
            
        }

        @Override
        public void readTagCallback(ReadTagData readTagData) throws RemoteException {
            Log.d("neil",">>>>>>>>>>>>>>>>>>> readTagCallback  <<<<<<<<<<<<<<<<<<<<<<<<<" + readTagData.toString());
            handleReadTag(readTagData);
//            lastCount++;
//            if (System.currentTimeMillis() - lastTime >= 1000) {
//                msg = handler.obtainMessage();
//                msg.what = MSG_UPDATE_SPEED;
//                msg.obj = ((lastCount * 1000) / (System.currentTimeMillis() - lastTime)) + "";
//                handler.sendMessage(msg);
//                lastTime = System.currentTimeMillis();
//                lastCount = 0;
//            }
        }
        public void handleReadTag(ReadTagData readTagData){
            String epc = "";
            String mem = "";
            if (readTagData.getTagID() != null)
                epc = readTagData.getTagID().toUpperCase();
            if (readTagData.getMemBank() != null)
                mem = readTagData.getMemBank().toUpperCase();

            String rssi = String.valueOf(readTagData.getRssi());
            Message msg = handler.obtainMessage();

            msg.what = MSG_UPDATE_LISTVIEW;
            if (mem.length() == 0)
                msg.obj = epc + "," + rssi;
            else
                msg.obj = epc + "," + mem + "," + rssi;
            handler.sendMessage(msg);
        }
    }
}