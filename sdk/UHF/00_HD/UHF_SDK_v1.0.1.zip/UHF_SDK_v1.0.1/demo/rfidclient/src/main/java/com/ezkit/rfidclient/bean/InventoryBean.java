package com.ezkit.rfidclient.bean;

import net.ezkit.rfid.bean.ReadTagData;

public class InventoryBean {
    public int count;
    public ReadTagData mReadTagData;

    public InventoryBean(){

    }

    public InventoryBean(int count, ReadTagData mReadTagData) {
        this.count = count;
        this.mReadTagData = mReadTagData;
    }
}
