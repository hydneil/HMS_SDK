package com.ezkit.rfidclient.listener;

import net.ezkit.rfid.bean.ReadTagData;

public interface RfidResultListener {
    public void onResultReceiver(ReadTagData data);
}
