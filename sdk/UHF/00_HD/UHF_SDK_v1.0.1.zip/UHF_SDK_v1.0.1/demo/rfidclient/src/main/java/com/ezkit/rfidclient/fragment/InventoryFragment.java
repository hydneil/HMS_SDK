package com.ezkit.rfidclient.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.android.hdms.HDMSManager;
import com.android.hdms.scanner.ScanManager;
import com.ezkit.rfidclient.R;
import com.ezkit.rfidclient.RfidClientApplication;
import com.ezkit.rfidclient.adapter.InventoryAdapter;
import com.ezkit.rfidclient.bean.InventoryBean;
import com.ezkit.rfidclient.listener.RfidResultListener;
import com.ezkit.rfidclient.model.SharedViewModel;
import com.ezkit.rfidclient.util.IOUtil;
import com.ezkit.rfidclient.util.ToastUtil;

import net.ezkit.rfid.RfidManager;
import net.ezkit.rfid.bean.ReadTagData;
import net.ezkit.rfid.util.Constant;
import net.ezkit.rfid.util.LogUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class InventoryFragment extends BaseFragment {
    private ViewPager mViewPager;
    private RadioGroup mRadioGroup;
    private RadioButton mOnce;
    private RadioButton mCycle;
    private Button mStart;
    private Button mExport;
    private Button mClear;
    private TextView mCount;
    private TextView mTimes;
    private TextView mTime;
    private TextView mSpeed;
    private RecyclerView mRecycler;
    private InventoryAdapter adapter;

    private boolean mCycleInventory = true;
    private boolean mInventorying;
    private RfidManager mRfidManager;
    private List<InventoryBean> list = new ArrayList<>();
    private Timer timer;
    public long beginTime;
    public long lastTime=0;
    public int lastCount=0;
    private ScanManager mScanManager;
    private SharedViewModel sharedViewModel;
    private static final int MSG_DISPATCH_RFID_RESULT = 0x01;
    private static final int MSG_UPDATE_TIME = 0x02;
    private static final int MSG_UPDATE_SPEED = 0x03;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (msg.what == MSG_DISPATCH_RFID_RESULT) {
                ReadTagData data = (ReadTagData) msg.obj;
                boolean newTag = true;
                for (InventoryBean bean : list) {
                    if (bean.mReadTagData.getTagID().equals(data.getTagID())) {
                        bean.count++;
                        bean.mReadTagData = data;
                        newTag = false;
                        break;
                    }
                }
                if (newTag) {
                    InventoryBean inventoryBean = new InventoryBean(1, data);
                    list.add(inventoryBean);
                }
                updateUI();
                adapter.notifyDataSetChanged();
            } else if (msg.what == MSG_UPDATE_TIME) {
                String ReadTime = msg.obj+"";
                long CurTime = Integer.valueOf(ReadTime);
                long hour=CurTime/(60*60*1000);
                long min=(CurTime/1000 - (hour*60*60))/60;
                long sec=(CurTime/1000-hour*60*60-min*60);
                String strHour = String.valueOf(hour);
                if(strHour.length()<2) strHour="0"+strHour;
                String strmin = String.valueOf(min);
                if(strmin.length()<2) strmin="0"+strmin;
                String strsec = String.valueOf(sec);
                if(strsec.length()<2) strsec="0"+strsec;
                mTime.setText(strHour+":"+strmin+":"+strsec);
            } else if (msg.what == MSG_UPDATE_SPEED) {
                mSpeed.setText(msg.obj+"");
            }
        }
    };

    private RfidResultListener listener = new RfidResultListener() {
        @Override
        public void onResultReceiver(ReadTagData data) {
            Message message = mHandler.obtainMessage(MSG_DISPATCH_RFID_RESULT);
            message.obj = data;
            mHandler.sendMessage(message);
            lastCount++;
            if(System.currentTimeMillis() - lastTime>=1000)
            {
                Message msg = mHandler.obtainMessage();
                msg.what = MSG_UPDATE_SPEED;
                msg.obj = ((lastCount*1000)/(System.currentTimeMillis() - lastTime)) + "";
                mHandler.sendMessage(msg);
                lastTime = System.currentTimeMillis();
                lastCount=0;
            }
        }
    };

    public InventoryFragment() {
    }

    public InventoryFragment(ViewPager mViewPager) {
        this.mViewPager = mViewPager;
        mScanManager = (ScanManager) HDMSManager.getInstance().getModuleManager(HDMSManager.MODULE_TYPE.SCANNER);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

    }

    @Override
    public void dispatchKeyEvent(KeyEvent event) {
        super.dispatchKeyEvent(event);
        if (event.getKeyCode() == 566 && event.getRepeatCount() == 0){
            if (event.getAction() == KeyEvent.ACTION_DOWN){
                if (!mInventorying) {
                    if (!mCycleInventory) {
                        mRfidManager.startInventoryOnce();
                    } else {
                        mRfidManager.startInventory();
                        mInventorying = true;
                        mStart.setText(R.string.str_inventory_stop);
                        if(timer == null) {
                            beginTime = System.currentTimeMillis();
                            timer = new Timer();
                            timer.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                    long ReadTime = System.currentTimeMillis() - beginTime;
                                    Message msg = mHandler.obtainMessage();
                                    msg.what = MSG_UPDATE_TIME;
                                    msg.obj = String.valueOf(ReadTime) ;
                                    mHandler.sendMessage(msg);
                                }
                            }, 0, 200);
                        }
                    }
                } else {
                    if(timer != null){
                        timer.cancel();
                        timer = null;
                    }
                    mRfidManager.stopInventory();
                    mInventorying = false;
                    mStart.setText(R.string.str_inventory_start);
                }
            }
        }
    }

    @Override
    protected void onResumeVisible() {
        super.onResumeVisible();
        LogUtil.d("InventoryFragment onResumeVisible>>");
        if (!RfidClientApplication.getInstance().mDeviceConnected) {
            mViewPager.setCurrentItem(0);
            ToastUtil.showToast(getContext(), getString(R.string.str_connect_open_first));
        } else {
            mRfidManager = RfidClientApplication.getInstance().getRfidManager();
            int mRfidType = mRfidManager.getParamInt(Constant.ParamKey.RFID_TYPE,0);
            mOnce.setEnabled(mRfidType != 3);
            RfidClientApplication.getInstance().setRfidResultListener(listener);
            if (mScanManager != null) {
                mScanManager.disableScanKey(true);
            }
        }
    }

    @Override
    protected void onPauseInVisible() {
        super.onPauseInVisible();
        mScanManager.disableScanKey(false);
        if (RfidClientApplication.getInstance().mDeviceConnected) {
            mInventorying = false;
            mStart.setText(R.string.str_inventory_start);
            mRfidManager.stopInventory();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);
        mRadioGroup = view.findViewById(R.id.radio_group);
        mOnce = view.findViewById(R.id.inventory_once);
        mCycle = view.findViewById(R.id.inventory_cycle);
        mStart = view.findViewById(R.id.start);
        mExport = view.findViewById(R.id.export);
        mClear = view.findViewById(R.id.clear);
        mCount = view.findViewById(R.id.all_count);
        mTimes = view.findViewById(R.id.all_times);
        mRecycler = view.findViewById(R.id.recycler_view);
        mSpeed = view.findViewById(R.id.tv_tagspeed);
        mTime = view.findViewById(R.id.tv_times);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        sharedViewModel.getClearDataEvent().observe(getViewLifecycleOwner(), new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean shouldClear) {
                if (shouldClear != null && shouldClear) {
                    list.clear();
                    adapter.notifyDataSetChanged();
                    updateUI();
                    sharedViewModel.clearDataEvent();
                }
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adapter = new InventoryAdapter(getContext(), list);
        mRecycler.setAdapter(adapter);

        adapter.setOnItemClick(new InventoryAdapter.onItemClick() {
            @Override
            public void onClick(ReadTagData data) {
                RfidClientApplication.getInstance().mOperationTagID = data.getTagID();
                mViewPager.setCurrentItem(2);
            }
        });
        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                if (id == R.id.inventory_once) {
                    mCycleInventory = false;
                } else if (id == R.id.inventory_cycle) {
                    mCycleInventory = true;
                }
            }
        });
        mStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCycleInventory) {
                    if (!mInventorying) {
                        mRfidManager.startInventory();
                        mInventorying = true;
                        mStart.setText(R.string.str_inventory_stop);
                        if(timer == null) {
                            beginTime = System.currentTimeMillis();
                            timer = new Timer();
                            timer.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                    long ReadTime = System.currentTimeMillis() - beginTime;
                                    Message msg = mHandler.obtainMessage();
                                    msg.what = MSG_UPDATE_TIME;
                                    msg.obj = String.valueOf(ReadTime) ;
                                    mHandler.sendMessage(msg);
                                }
                            }, 0, 200);
                        }
                    } else {
                        if(timer != null){
                            timer.cancel();
                            timer = null;
                        }
                        mRfidManager.stopInventory();
                        mInventorying = false;
                        mStart.setText(R.string.str_inventory_start);
                    }
                } else {
                    mRfidManager.startInventoryOnce();
                }
            }
        });

        mClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.clear();
                adapter.notifyDataSetChanged();
                updateUI();
                mSpeed.setText("0");
            }
        });
        mExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date());
                String filename = "/sdcard/Download/rfid_" + timeStamp + ".xls"; // 文件保存到 /sdcard/ 目录下，使用指定的文件名格式

                boolean ret = IOUtil.saveListToExcel(list,filename);
                ToastUtil.showToast(getContext(),ret?getString(R.string.str_save_path)+filename:getString(R.string.str_save_fail));
            }
        });
    }
    private void updateUI() {
        mCount.setText(getString(R.string.str_all_count)+ list.size());
        mTimes.setText(getString(R.string.str_all_times)+ getTimes());
    }

    private String getTimes() {
        int count = 0;
        for (InventoryBean bean : list){
            count += bean.count;
        }
        return String.valueOf(count);
    }
}
