package com.ezkit.rfidclient.fragment;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.ezkit.rfidclient.R;
import com.ezkit.rfidclient.RfidClientApplication;
import com.ezkit.rfidclient.model.SharedViewModel;
import com.ezkit.rfidclient.util.ToastUtil;

import net.ezkit.rfid.RfidManager;
import net.ezkit.rfid.bean.ReadTagParams;
import net.ezkit.rfid.bean.WriteTagParams;
import net.ezkit.rfid.util.LogUtil;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class RWFragment extends BaseFragment implements View.OnClickListener {
    private Spinner mMemBank;
    private Spinner mLockMemBank;
    private Spinner mLockType;
    private EditText mAddrOffset;
    private EditText mAddrLen;
    private EditText mPassword;
    private EditText mKillPassword;
    private TextView mExeResult;
    private EditText mWriteData;
    private EditText mReadData;
    private Button mReadBtn;
    private Button mWriteBtn;
    private Button mWriteEPC;
    private Button mLockBtn;
    private Button mKillBtn;
    private SharedViewModel sharedViewModel;

    TextView mExeEpcId;
    private RfidManager mRfidManager;

    private ViewPager mViewPager;

    public RWFragment(ViewPager mViewPager) {
        this.mViewPager = mViewPager;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_rw, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void initView(View view) {
        mExeEpcId = (TextView) view.findViewById(R.id.epc_text);
        mExeResult = (TextView) view.findViewById(R.id.rw_result);
        mMemBank = (Spinner) view.findViewById(R.id.mem_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.men_select, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mMemBank.setAdapter(adapter);
        mMemBank.setSelection(1, true);

        mLockMemBank = (Spinner) view.findViewById(R.id.lockmem_spinner);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getContext(), R.array.arrayLockMem, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mLockMemBank.setAdapter(adapter1);
        mLockMemBank.setSelection(2, true);

        mLockType = (Spinner) view.findViewById(R.id.locktype_spinner);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(getContext(), R.array.arrayLock, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mLockType.setAdapter(adapter2);
        mLockType.setSelection(2, true);


        mAddrOffset = (EditText) view.findViewById(R.id.et_wordptr);
        mAddrOffset.setText("2");
        mAddrLen = (EditText) view.findViewById(R.id.et_length);
        mAddrLen.setText("6");
        mPassword = (EditText) view.findViewById(R.id.et_pwd);
        mPassword.setText("00000000");
        mKillPassword = (EditText) view.findViewById(R.id.et_kwd);
        mWriteData = (EditText) view.findViewById(R.id.et_content_wd);
        mReadData = (EditText) view.findViewById(R.id.et_read_data);
        mReadBtn = (Button) view.findViewById(R.id.button_read);
        mWriteBtn = (Button) view.findViewById(R.id.button_write);
        mWriteEPC = (Button) view.findViewById(R.id.button_write_epc);
        mKillBtn = (Button) view.findViewById(R.id.button_kill);
        mLockBtn = (Button) view.findViewById(R.id.button_lock);
        mReadBtn.setOnClickListener(this);
        mWriteBtn.setOnClickListener(this);
        mWriteEPC.setOnClickListener(this);
        mKillBtn.setOnClickListener(this);
        mLockBtn.setOnClickListener(this);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        sharedViewModel.getClearDataEvent().observe(getViewLifecycleOwner(), new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean shouldClear) {
                if (shouldClear != null && shouldClear) {
                    mReadData.setText("");
                    mWriteData.setText("");
                    mExeResult.setText("");
                    sharedViewModel.clearDataEvent();
                }
            }
        });
    }

    @Override
    protected void onResumeVisible() {
        super.onResumeVisible();
        LogUtil.d("onResumeVisible");
        if (!RfidClientApplication.getInstance().mDeviceConnected) {
            ToastUtil.showToast(getContext(), getString(R.string.str_connect_open_first));
            mViewPager.setCurrentItem(0);
        } else {
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                mExeEpcId.setText(RfidClientApplication.getInstance().mOperationTagID);
            }
            mRfidManager = RfidClientApplication.getInstance().getRfidManager();
        }
    }

    @Override
    public void onClick(View view) {
        if (!RfidClientApplication.getInstance().mDeviceConnected) {
            ToastUtil.showToast(getContext(), getString(R.string.str_connect_open_first));
            return;
        }
        if (view == mReadBtn) {
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                try {
                    ReadTagParams mReadTagParams = new ReadTagParams();
                    mReadTagParams.setTagID(RfidClientApplication.getInstance().mOperationTagID);
                    mReadTagParams.setMemBank(mMemBank.getSelectedItemPosition());
                    mReadTagParams.setOffset(Integer.parseInt(mAddrOffset.getText().toString()));
                    mReadTagParams.setCount(Integer.parseInt(mAddrLen.getText().toString()));
                    mReadTagParams.setPassword(mPassword.getText().toString());
                    LogUtil.i(mReadTagParams.toString());
                    String readData = mRfidManager.readTagData(mReadTagParams);
                    if (TextUtils.isEmpty(readData)) {
                        setTextWithDate(getString(R.string.str_rw_get_failed),mExeResult);
                    } else {
                        setTextWithDate(getString(R.string.str_rw_get_success),mExeResult);
                        mReadData.setText(readData);
                    }
                } catch (Exception e) {
                    setTextWithDate(getString(R.string.str_rw_get_failed),mExeResult);
                    e.printStackTrace();
                }
            } else {
                ToastUtil.showToast(getContext(), getString(R.string.str_rw_no_epc));
            }
        } else if (view == mWriteBtn) {
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                try {
                    WriteTagParams mWriteTagParams = new WriteTagParams();
                    mWriteTagParams.setTagID(RfidClientApplication.getInstance().mOperationTagID);
                    mWriteTagParams.setMemBank(mMemBank.getSelectedItemPosition());
                    mWriteTagParams.setOffset(Integer.parseInt(mAddrOffset.getText().toString()));
                    mWriteTagParams.setPassword(mPassword.getText().toString());
                    mWriteTagParams.setWriteData(mWriteData.getText().toString());
                    int ret = mRfidManager.writeTagData(mWriteTagParams);

                    if (ret != 0) {
                        setTextWithDate(getString(R.string.str_rw_write_failed),mExeResult);
                    } else {
                        setTextWithDate(getString(R.string.str_rw_write_success),mExeResult);
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    setTextWithDate(getString(R.string.str_rw_write_failed),mExeResult);
                }
            } else {
                ToastUtil.showToast(getContext(), getString(R.string.str_rw_no_epc));
            }
        } else if (view == mWriteEPC){
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                try {
                    int ret = mRfidManager.writeEPC(mWriteData.getText().toString(),
                            mPassword.getText().toString());
                    if (ret != 0) {
                        setTextWithDate(getString(R.string.str_rw_write_failed),mExeResult);
                    } else {
                        setTextWithDate(getString(R.string.str_rw_write_success),mExeResult);
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    setTextWithDate(getString(R.string.str_rw_write_failed),mExeResult);
                }
            } else {
                ToastUtil.showToast(getContext(), getString(R.string.str_rw_no_epc));
            }
        } else if (view == mLockBtn){
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                try {
                    int ret = mRfidManager.lockTag(RfidClientApplication.getInstance().mOperationTagID,
                            (byte) mLockMemBank.getSelectedItemPosition(), (byte) mLockType.getSelectedItemPosition(),
                            mPassword.getText().toString());
                    if (ret != 0) {
                        setTextWithDate(getString(R.string.str_rw_optfailed),mExeResult);
                    } else {
                        setTextWithDate(getString(R.string.str_rw_optsuccess),mExeResult);
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    setTextWithDate(getString(R.string.str_rw_optfailed),mExeResult);
                }
            } else {
                ToastUtil.showToast(getContext(), getString(R.string.str_rw_no_epc));
            }
        }else if (view == mKillBtn){
            if (!TextUtils.isEmpty(RfidClientApplication.getInstance().mOperationTagID)) {
                try {
                    int ret = mRfidManager.killTag(RfidClientApplication.getInstance().mOperationTagID,
                            mKillPassword.getText().toString());
                    if (ret != 0) {
                        setTextWithDate(getString(R.string.str_rw_optsuccess),mExeResult);
                    } else {
                        setTextWithDate(getString(R.string.str_rw_write_success),mExeResult);
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    setTextWithDate(getString(R.string.str_rw_optfailed),mExeResult);
                }
            } else {
                ToastUtil.showToast(getContext(), getString(R.string.str_rw_no_epc));
            }
        }
    }


    public static void setTextWithDate(String data, TextView tvResult) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");// HH:mm:ss
        Date date = new Date(System.currentTimeMillis());
        tvResult.setText(simpleDateFormat.format(date) + " " + data);
    }
}
