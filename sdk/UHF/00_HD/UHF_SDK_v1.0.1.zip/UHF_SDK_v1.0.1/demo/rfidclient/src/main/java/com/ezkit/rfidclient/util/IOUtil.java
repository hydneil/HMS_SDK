package com.ezkit.rfidclient.util;


import static org.apache.poi.ss.usermodel.CellType.*;

import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;

import com.ezkit.rfidclient.bean.InventoryBean;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IOUtil {
    public static boolean saveTextToFile(String data, String filename) {
        try {
            FileOutputStream fos = new FileOutputStream(new File(filename));
            fos.write(data.getBytes());
            fos.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


    public static boolean saveListToExcel(List<InventoryBean> list, String filename) {
        try {
            HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
            //建一个Sheet
            HSSFSheet sheet = hssfWorkbook.createSheet();
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Label");
            headerRow.createCell(1).setCellValue("Count");
            headerRow.createCell(2).setCellValue("RSSI");
            int rowNum = 1;
            for (InventoryBean item : list) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(item.mReadTagData.getTagID());
                row.createCell(1).setCellValue(item.count);
                row.createCell(2).setCellValue(item.mReadTagData.getRssi());
            }
            Log.d("neil", filename);
            File file = new File(filename);
            if (file.exists()) {
                file.delete();
                file.createNewFile();
            } else {
                file.createNewFile();
            }
            file.setWritable(true);
            file.setReadable(true);
            FileOutputStream fileOut = new FileOutputStream(file);
            hssfWorkbook.write(fileOut);
            fileOut.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    public static boolean saveBitmapToStorage(Bitmap bitmap, String filePath) {
        File file = new File(filePath);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
