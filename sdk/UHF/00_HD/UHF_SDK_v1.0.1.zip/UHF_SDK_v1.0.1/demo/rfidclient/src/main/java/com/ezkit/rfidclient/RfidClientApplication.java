package com.ezkit.rfidclient;

import android.app.Application;
import android.os.RemoteException;

import com.ezkit.rfidclient.listener.RfidResultListener;

import net.ezkit.rfid.RfidManager;
import net.ezkit.rfid.bean.ReadTagData;
import net.ezkit.rfid.callback.IRfidCallback;
import net.ezkit.rfid.util.Constant;
import net.ezkit.rfid.util.LogUtil;

import org.greenrobot.eventbus.EventBus;

public class RfidClientApplication extends Application {
    private RfidManager mRfidManager;
    private IRfidCallback mRfidCallBack = new RfidCallBack();
    public boolean serviceConnected = false;
    private static RfidClientApplication instance;
    private RfidResultListener listener;

    public boolean mDeviceConnected = false;
    public String mOperationTagID;
    public int mRuntime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        LogUtil.i("new RfidManager");
        instance = this;
        mRfidManager = new RfidManager(this);
        LogUtil.i("setRfidCallBack");
        mRfidManager.setRfidCallBack(mRfidCallBack);
    }

    public static RfidClientApplication getInstance(){
        return instance;
    }

    public RfidManager getRfidManager(){
        if (serviceConnected)
            return mRfidManager;
        else
            return null;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        LogUtil.i("onTerminate");
        if (mRfidManager!= null) {
            if (mRfidCallBack!= null)
                mRfidManager.cancelRfidCallBack(mRfidCallBack);
            mRfidManager.disConnect();
        }
    }

    public void setRfidResultListener(RfidResultListener listener){
        this.listener = listener;
    }

    class RfidCallBack extends IRfidCallback.Stub{

        @Override
        public void deviceStateChange(int deviceState) throws RemoteException {
            LogUtil.i("deviceStateChange state = " + deviceState);
            if (deviceState == Constant.DeviceState.SERVICE_CONNECTED){
                serviceConnected = true;
                EventBus.getDefault().post(deviceState);
            }else if (deviceState == Constant.DeviceState.SERVICE_DISCONNECTED) {
                serviceConnected = false;
                mDeviceConnected = false;
            } else {
                // Notification of RFID connection status
                EventBus.getDefault().post(deviceState);
            }
        }

        @Override
        public void readTagCallback(ReadTagData readTagData) throws RemoteException {
            if (listener!= null){
                listener.onResultReceiver(readTagData);
            }
        }
    }
}
