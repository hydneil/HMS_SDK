package com.ezkit.rfidclient.model;

import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SharedViewModel extends ViewModel {
    private MutableLiveData<Boolean> clearDataEvent = new MutableLiveData<>();

    public void sendClearDataEvent() {
        clearDataEvent.setValue(true);
    }
    public MutableLiveData<Boolean> getClearDataEvent() {
        return clearDataEvent;
    }
    public void clearDataEvent() {
        new Handler(Looper.getMainLooper()).post(() -> clearDataEvent.setValue(false));
    }
}
