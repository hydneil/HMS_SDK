package com.ezkit.rfidclient.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ezkit.rfidclient.R;
import com.ezkit.rfidclient.RfidClientApplication;
import com.ezkit.rfidclient.util.ToastUtil;

import net.ezkit.rfid.RfidManager;
import net.ezkit.rfid.bean.InventoryParams;
import net.ezkit.rfid.bean.UHFInformation;
import net.ezkit.rfid.util.Constant;
import net.ezkit.rfid.util.LogUtil;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class ParamFragment extends BaseFragment implements View.OnClickListener {
    private TextView tvVersion;
    private TextView tvResult;
    private Spinner tvpowerdBm;
    private Spinner spType;
    private Spinner spMem;

    private LinearLayout mFreqLayout;
    private LinearLayout mOtherParamsLayout;
    private LinearLayout mProfileLayout;
    private Integer[] profileArray = new Integer[33];


    private Button bSetting;
    private Button bRead;

    private Button paramRead;
    private Button paramSet;

    private Button measure_loss;

    private int soundid;
    private int tty_speed = 57600;
    private byte addr = (byte) 0xff;
    private String[] strBand = new String[6];
    private String[] strmaxFrm = null;
    private String[] strminFrm = null;
    private String[] strtime = new String[256];

    private String[] strjtTime = new String[7];
    private String[] strBaudRate = new String[2];

    private String[] dwelltime = new String[254];

    private String[] strProfile = new String[12];
    private String[] strRange = new String[101];
    Spinner jgTime;
    private ArrayAdapter<String> spada_jgTime;
    private String[] FM_REGION = {"Div 48(FCC)", "Div 120(EISI)", "Div 96(CHINA0)", "Div 96(CHINA1)"};

    Spinner spBand;
    Spinner spBand1;
    Spinner spmaxFrm;
    Spinner spminFrm;
    Spinner sptime;
    Spinner spqvalue;
    Spinner spsession;
    Spinner sptidaddr;
    Spinner sptidlen;
    Spinner spbaudRate;
    Spinner spDwell;
    Spinner spTagfocus;
    Spinner spProfilr;
    Spinner profileSpinner;
    Button Setparam;
    Button Getparam;
    Button btSetBaud;
    Button btSetProfile;
    Button btSetFocus;
    Button btGetFocus;
    Button btSetPro;
    Button btReset;

    private ArrayAdapter<String> spada_Band;
    private ArrayAdapter<String> spada_maxFrm;
    private ArrayAdapter<String> spada_minFrm;
    private ArrayAdapter<String> spada_time;
    private ArrayAdapter<String> spada_lowPwr;
    private ArrayAdapter<String> spada_qvalue;
    private ArrayAdapter<String> spada_session;
    private ArrayAdapter<String> spada_tidaddr;
    private ArrayAdapter<String> spada_tidlen;
    private ArrayAdapter<String> spada_baudrate;

    private ArrayAdapter<String> spada_dwell;
    private ArrayAdapter<String> spada_tagfocus;
    private ArrayAdapter<String> spada_profile;
    private ArrayAdapter<String> profileAdapter;
    private static final String TAG = "SacnView";

    private LinearLayout linefocus;
    private LinearLayout lineprofile;
    private LinearLayout bandLayout;
    private LinearLayout bandLayout1;
    private LinearLayout qLayout;
    private LinearLayout rateLayout;
    EditText tvRun;
    private RfidManager mRfidManager;
    private ViewPager mViewPager;

    private int mRfidType = 0;

    public ParamFragment(ViewPager mViewPager) {
        this.mViewPager = mViewPager;

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_params, container, false);
        initView(view);
        return view;
    }

    private void initView(View view) {
        tvRun = (EditText) view.findViewById(R.id.tv_runtime);
        mFreqLayout = (LinearLayout) view.findViewById(R.id.layout_fre);
        qLayout = (LinearLayout) view.findViewById(R.id.layout_qvalue);
        mOtherParamsLayout = (LinearLayout) view.findViewById(R.id.layout_other_param);
        mProfileLayout = (LinearLayout) view.findViewById(R.id.layout_profile);
        bandLayout = (LinearLayout) view.findViewById(R.id.layout_band);
        bandLayout1 = (LinearLayout) view.findViewById(R.id.layout_band1);

        tvVersion = (TextView) view.findViewById(R.id.version);
        tvResult = (TextView) view.findViewById(R.id.param_result);

        tvpowerdBm = (Spinner) view.findViewById(R.id.power_spinner);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(getContext(), R.array.Power_select, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tvpowerdBm.setAdapter(adapter3);

        tvpowerdBm.setSelection(33, true);

        bSetting = (Button) view.findViewById(R.id.pro_setting);
        bRead = (Button) view.findViewById(R.id.pro_read);
        paramRead = (Button) view.findViewById(R.id.ivt_read);
        paramSet = (Button) view.findViewById(R.id.ivt_setting);
        btSetBaud = (Button) view.findViewById(R.id.bt_SetBdRate);
        btSetFocus = (Button) view.findViewById(R.id.bt_SetFocus);
        btGetFocus = (Button) view.findViewById(R.id.bt_GetFocus);
        btSetPro = (Button) view.findViewById(R.id.bt_SetProfile);
        btReset = (Button) view.findViewById(R.id.bt_reset_all);
        btSetProfile = (Button) view.findViewById(R.id.bt_set_profile);

        bSetting.setOnClickListener(this);
        bRead.setOnClickListener(this);
        paramRead.setOnClickListener(this);
        paramSet.setOnClickListener(this);
        btSetBaud.setOnClickListener(this);
        btSetProfile.setOnClickListener(this);

        btSetFocus.setOnClickListener(this);
        btGetFocus.setOnClickListener(this);
        btSetPro.setOnClickListener(this);
        btReset.setOnClickListener(this);

        linefocus = (LinearLayout) view.findViewById(R.id.linetagfocus);
        lineprofile = (LinearLayout) view.findViewById(R.id.lineprogile);

        //最大询查时间
        for (int index = 0; index < 256; index++) {
            strtime[index] = String.valueOf(index) + "*100ms";
        }
        sptime = (Spinner) view.findViewById(R.id.time_spinner);
        spada_time = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strtime);
        spada_time.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sptime.setAdapter(spada_time);
        sptime.setSelection(50, false);

        ////////////Ƶ��ѡ��
        strBand[0] = "Chinese band2";
        strBand[1] = "US band";
        strBand[2] = "Korean band";
        strBand[3] = "EU band";
        strBand[4] = "Chinese band1";
        strBand[5] = "ALL band";

        strBaudRate[0] = "57600bps";
        strBaudRate[1] = "115200bps";


        spBand = (Spinner) view.findViewById(R.id.band_spinner);
        spada_Band = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strBand);
        spada_Band.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBand.setAdapter(spada_Band);
        spBand.setSelection(1, false);
        spmaxFrm = (Spinner) view.findViewById(R.id.max_spinner);
        spminFrm = (Spinner) view.findViewById(R.id.min_spinner);

        SetFre(Constant.BandCode.NORTH_AMERICA);
        spBand.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // TODO Auto-generated method stub  
                arg0.setVisibility(View.VISIBLE);
                if (arg2 == 0) SetFre(Constant.BandCode.CHINA2);
                if (arg2 == 1) SetFre(Constant.BandCode.NORTH_AMERICA);
                if (arg2 == 2) SetFre(Constant.BandCode.KOREA);
                if (arg2 == 3) SetFre(Constant.BandCode.EUROPE);
                if (arg2 == 4) SetFre(Constant.BandCode.CHINA);
                if (arg2 == 5) SetFre(Constant.BandCode.OPEN);
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub  
            }
        });

        spBand1 = (Spinner) view.findViewById(R.id.band_spinner1);
        ArrayAdapter<String> adapterBand1 = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, FM_REGION);
        adapterBand1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBand1.setAdapter(adapterBand1);


        //strjtTime[0]="无间隔";
        for (int index = 0; index < 7; index++) {
            strjtTime[index] = String.valueOf(index * 10) + "ms";
        }
        jgTime = (Spinner) view.findViewById(R.id.jgTime_spinner);
        spada_jgTime = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strjtTime);
        spada_jgTime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jgTime.setAdapter(spada_jgTime);
        jgTime.setSelection(3, false);

        spqvalue = (Spinner) view.findViewById(R.id.qvalue_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.men_q, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spqvalue.setAdapter(adapter);
        spqvalue.setSelection(6, true);


        spsession = (Spinner) view.findViewById(R.id.session_spinner);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getContext(), R.array.men_s, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spsession.setAdapter(adapter1);
        spsession.setSelection(5, true);

        sptidaddr = (Spinner) view.findViewById(R.id.tidptr_spinner);
        sptidlen = (Spinner) view.findViewById(R.id.tidlen_spinner);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(getContext(), R.array.men_tid, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sptidaddr.setAdapter(adapter2);
        sptidaddr.setSelection(0, true);
        sptidlen.setAdapter(adapter2);
        sptidlen.setSelection(6, true);

        rateLayout = (LinearLayout) view.findViewById(R.id.layout_rate);
        spbaudRate = (Spinner) view.findViewById(R.id.baud_spinner);
        spada_baudrate = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strBaudRate);
        spada_baudrate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spbaudRate.setAdapter(spada_baudrate);


        ////////////查询类型
        spType = (Spinner) view.findViewById(R.id.IvtType_spinner);
        ArrayAdapter<CharSequence> spada_Type = ArrayAdapter.createFromResource(getContext(), R.array.IvtType_select, android.R.layout.simple_spinner_item);
        spada_Type.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spType.setAdapter(spada_Type);
        spType.setSelection(0, false);


        ////////////查询区域
        spMem = (Spinner) view.findViewById(R.id.mixmem_spinner);
        ArrayAdapter<CharSequence> spada_Mem = ArrayAdapter.createFromResource(getContext(), R.array.readmen_select, android.R.layout.simple_spinner_item);
        spada_Mem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMem.setAdapter(spada_Mem);
        spMem.setSelection(1, false);


        for (int index = 2; index < 256; index++) {
            dwelltime[index - 2] = String.valueOf(index * 100) + "ms";
        }
        spDwell = (Spinner) view.findViewById(R.id.dwell_spinner);
        spada_dwell = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, dwelltime);
        spada_dwell.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDwell.setAdapter(spada_dwell);
        spDwell.setSelection(48, false);


        spTagfocus = (Spinner) view.findViewById(R.id.focus_spinner);
        ArrayAdapter<CharSequence> spada_focus = ArrayAdapter.createFromResource(getContext(), R.array.en_select, android.R.layout.simple_spinner_item);
        spada_focus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTagfocus.setAdapter(spada_focus);
        spTagfocus.setSelection(0, false);

        strProfile = new String[12];
        strProfile[0] = "11:640K,FM0,7.5us";
        strProfile[1] = " 1:640K, M2,7.5us";
        strProfile[2] = "15:640K, M4,7.5us";
        strProfile[3] = "12:320K, M2, 15us";
        strProfile[4] = " 3:320K, M2, 20us";
        strProfile[5] = " 5:320K, M4, 20us";
        strProfile[6] = " 7:250K, M4, 20us";
        strProfile[7] = "13:160K, M8, 20us";
        strProfile[8] = "103:640K,FM0,6.25us";
        strProfile[9] = "120:640K, M2,6.25us";
        strProfile[10] = "202:426K,FM0, 15us";
        strProfile[11] = "345:640K, M4,7.5us";

        spProfilr = (Spinner) view.findViewById(R.id.prof_spinner);
        spada_profile = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strProfile);
        spada_profile.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProfilr.setAdapter(spada_profile);
        spProfilr.setSelection(5, false);


        for (int index = 0; index <= 100; index++) {
            strRange[index] = String.valueOf(index);
        }

        /// ////// FM Profile
        profileSpinner = (Spinner) view.findViewById(R.id.profile_spinner);
//        for (int i = 0; i < 33; i++) {
//            profileArray[i] = i;
//        }
        profileAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.profile_array));
        profileAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        profileSpinner.setAdapter(profileAdapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    protected void onResumeVisible() {
        super.onResumeVisible();
        LogUtil.d("ParamFragment onResumeVisible");
        if (!RfidClientApplication.getInstance().mDeviceConnected) {
            ToastUtil.showToast(getContext(), getString(R.string.str_connect_open_first));
            mViewPager.setCurrentItem(0);
        } else {
            mRfidManager = RfidClientApplication.getInstance().getRfidManager();
            mRfidType = mRfidManager.getParamInt(Constant.ParamKey.RFID_TYPE,0);
            LogUtil.d("mRfidType:" + mRfidType);
            readInformation();
            readParam();
            mProfileLayout.setVisibility(mRfidType == 3 ? View.VISIBLE : View.GONE);
            rateLayout.setVisibility(mRfidType == 3 ? View.GONE : View.VISIBLE);
            int profile = mRfidManager.getParamInt("LINK_PROFILE", 0);
            profileSpinner.setSelection(profile);
        }

//        ReadFocus();
//        ReadProfile();
//        ReadCheckAnt();
    }

    private void readInformation() {
        UHFInformation uhfInformation = mRfidManager.getUHFInformation();
        LogUtil.d(uhfInformation.toString());
        tvVersion.setText(uhfInformation.getVersion());
        tvpowerdBm.setSelection(uhfInformation.getPower(), false);
        if (mRfidType == 3 ){
            mFreqLayout.setVisibility(View.GONE);
            bandLayout.setVisibility(View.GONE);
            bandLayout1.setVisibility(View.VISIBLE);
            spBand.setSelection(uhfInformation.getBand(), false);
        } else {
            SetFre(uhfInformation.getBand());
            setSpBandValue(uhfInformation.getBand());
            spminFrm.setSelection(uhfInformation.getMinFre(), false);
            spmaxFrm.setSelection(uhfInformation.getMaxFre(), false);
            mFreqLayout.setVisibility(View.VISIBLE);
            bandLayout.setVisibility(View.VISIBLE);
            bandLayout1.setVisibility(View.GONE);
        }
    }

    private void readParam() {
        InventoryParams inventoryParams = mRfidManager.getInventoryParams();
        sptidlen.setSelection(inventoryParams.getLength(), true);
        sptidaddr.setSelection(inventoryParams.getWordPtr(), true);
        spqvalue.setSelection(inventoryParams.getQValue(),true);
        sptime.setSelection(inventoryParams.getScanTime(),true);
        spType.setSelection(inventoryParams.getIvtType(),true);
        spMem.setSelection(inventoryParams.getMemory()-1,true);

        int sessionindex = inventoryParams.getSession();
        if(sessionindex==255) sessionindex=4;
        if(sessionindex==254) sessionindex=5;
        if(sessionindex==253) sessionindex=6;
        if(sessionindex==252) sessionindex=7;
        if(sessionindex==251) sessionindex=8;
        spsession.setSelection(sessionindex,true);
        qLayout.setVisibility(mRfidType == 3 ? View.GONE:View.VISIBLE);

        tvRun.setText(RfidClientApplication.getInstance().mRuntime+"");
        setTextWithDate(getString(R.string.str_rw_get_success),tvResult);
        int baudRate = mRfidManager.getBaudRate();
        spbaudRate.setSelection(baudRate == 115200 ? 1 : 0);
        if (mRfidType == 1){
            mOtherParamsLayout.setVisibility(View.VISIBLE);
        } else {
            mOtherParamsLayout.setVisibility(View.GONE);
        }
    }

    public void setSpBandValue(int band) {
        if (band == Constant.BandCode.CHINA2) {
            spBand.setSelection(0, true);
        } else if (band == Constant.BandCode.NORTH_AMERICA) {
            spBand.setSelection(1, true);
        } else if (band == Constant.BandCode.KOREA) {
            spBand.setSelection(2, true);
        } else if (band == Constant.BandCode.EUROPE) {
            spBand.setSelection(3, true);
        } else if (band == Constant.BandCode.CHINA) {
            spBand.setSelection(4, true);
        } else if (band == Constant.BandCode.OPEN) {
            spBand.setSelection(5, true);
        }
    }

    public int getSpBandValue(int band) {
        if (band == 0) {
            return Constant.BandCode.CHINA2;
        } else if (band == 1) {
            return Constant.BandCode.NORTH_AMERICA;
        } else if (band == 2) {
            return Constant.BandCode.KOREA;
        } else if (band == 3) {
            return Constant.BandCode.EUROPE;
        } else if (band == 4) {
            return Constant.BandCode.CHINA;
        } else if (band == 5) {
            return Constant.BandCode.OPEN;
        }
        return Constant.BandCode.OPEN;
    }


    @Override
    public void onClick(View view) {
        if (view == bRead) {
            readInformation();
        } else if (view == paramRead){
            readParam();
        } else if (view == bSetting) {
            int Power = tvpowerdBm.getSelectedItemPosition();
            int fband = 0;
            if (mRfidType == 3){
                fband = spBand1.getSelectedItemPosition();
            } else {
                fband = getSpBandValue(spBand.getSelectedItemPosition());
            }
            int MinFre = spminFrm.getSelectedItemPosition();
            int MaxFre = spmaxFrm.getSelectedItemPosition();

            String temp = "";
            int result = mRfidManager.setPower(Power);
            if (result != 0) {
                temp = getString(R.string.power_error);
            }
            if (mRfidType == 3) {
                result = mRfidManager.setRegion(fband, 0, 0);
            } else {
                result = mRfidManager.setRegion(fband, MaxFre, MinFre);
            }
            if (result != 0) {
                if (temp == "")
                    temp = getString(R.string.frequent_error);
                else
                    temp += (",\r\n" + getString(R.string.frequent_error));
            }
            if (temp != "") {
                setTextWithDate(temp, tvResult);
            } else {
                setTextWithDate(getString(R.string.str_rw_set_success), tvResult);
            }
            readInformation();
        } else if (view == paramSet){
            InventoryParams params = mRfidManager.getInventoryParams();
            try {
                RfidClientApplication.getInstance().mRuntime = (int)(Integer.valueOf(tvRun.getText().toString()));
            } catch (Exception e){
                e.printStackTrace();
            }
            params.setLength(sptidlen.getSelectedItemPosition());
            params.setWordPtr(sptidaddr.getSelectedItemPosition());
            params.setQValue(spqvalue.getSelectedItemPosition());
            params.setScanTime(sptime.getSelectedItemPosition());
            params.setIvtType(spType.getSelectedItemPosition());
            params.setMemory(spMem.getSelectedItemPosition()+1);
            int Session = spsession.getSelectedItemPosition();
            if (mRfidType == 3 && Session >3){
                setTextWithDate(getString(R.string.str_rw_set_failed),tvResult);
                return;
            }
            if(Session==4)Session=255;
            if(Session==5)Session=254;
            if(Session==6)Session=253;
            if(Session==7)Session=252;
            if(Session==8)Session=251;
            params.setSession(Session);
            mRfidManager.setInventoryParams(params);
            setTextWithDate(getString(R.string.str_rw_set_success),tvResult);
        } else if (view == btSetBaud) {
            int mRate = 115200;
            if (spbaudRate.getSelectedItemPosition() == 0) {
                mRate = 57600;
            } else if (spbaudRate.getSelectedItemPosition() == 1) {
                mRate = 115200;
            }
//            int mRate =  Integer.parseInt((String) spbaudRate.getSelectedItem());
            int ret = mRfidManager.setBaudRate(mRate);
            setTextWithDate(getString(ret == 0? R.string.str_rw_set_success:R.string.str_rw_set_failed),tvResult);
        } else if (view == btReset) {
            int Power = 33;
            int fband = Constant.BandCode.NORTH_AMERICA;
            int MinFre = 0;
            int MaxFre = 49;

            String temp = "";
            int result = mRfidManager.setPower(Power);
            if (result != 0) {
                temp = getString(R.string.power_error);
            }
            result = mRfidManager.setRegion(fband, MaxFre,MinFre);
            if (result != 0) {
                if ("".equals(temp))
                    temp = getString(R.string.frequent_error);
                else
                    temp += (",\r\n" + getString(R.string.frequent_error));
            }
            InventoryParams params = mRfidManager.getInventoryParams();
            RfidClientApplication.getInstance().mRuntime = 0;

            params.setLength(6);
            params.setWordPtr(0);
            params.setQValue(6);
            params.setScanTime(50);
            params.setIvtType(0);
            params.setMemory(2);
            int Session = 254;
            params.setSession(Session);
            mRfidManager.setInventoryParams(params);
            readInformation();
            readParam();
            mRfidManager.setParamInt("LINK_PROFILE", 0);
            if (profileSpinner != null) {
                profileSpinner.setSelection(0);
            }
        } else if (view == btSetProfile) {
            int ret = mRfidManager.setParamInt("LINK_PROFILE",profileSpinner.getSelectedItemPosition());
            LogUtil.d("ret:"+ret);
            setTextWithDate(getString(ret == 0? R.string.str_rw_set_success:R.string.str_rw_set_failed),tvResult);
        }
    }

    private void initFrm(int count, float minFre, float step) {
        strmaxFrm = new String[count];
        strminFrm = new String[count];
        BigDecimal start = new BigDecimal(String.valueOf(minFre));
        BigDecimal delta = new BigDecimal(String.valueOf(step));
        for (int i = 0; i < count; i++) {
            BigDecimal value = start.add(delta.multiply(BigDecimal.valueOf(i)));
            String temp = value.setScale(1, BigDecimal.ROUND_HALF_UP).toString() + "MHz";
            strminFrm[i] = temp;
            strmaxFrm[i] = temp;
        }
        if (spada_minFrm != null)
            spada_minFrm.notifyDataSetChanged();
        if (spada_maxFrm != null)
            spada_maxFrm.notifyDataSetChanged();
    }

    private void SetFre(int m) {
        int maxFrmIndex = 19;
        if (m == Constant.BandCode.CHINA2) {
            initFrm(20, (float) 920.125, (float) 0.25);
            maxFrmIndex = 19;
        } else if (m == Constant.BandCode.NORTH_AMERICA) {
            initFrm(50, (float) 902.75, (float) 0.5);
            maxFrmIndex = 49;
        } else if (m == Constant.BandCode.KOREA) {
            initFrm(32, (float) 917.1, (float) 0.2);
            maxFrmIndex = 31;
        } else if (m == Constant.BandCode.EUROPE) {
            initFrm(15, (float) 865.1, (float) 0.2);
            maxFrmIndex = 14;
        } else if (m == Constant.BandCode.CHINA) {
            initFrm(20, (float) 840.125, (float) 0.25);
            maxFrmIndex = 19;
        } else if (m == Constant.BandCode.OPEN) {
            initFrm(61, (float) 840, (float) 2);
            maxFrmIndex = 60;
        }
        spada_maxFrm = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strmaxFrm);
        spada_maxFrm.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spmaxFrm.setAdapter(spada_maxFrm);
        spmaxFrm.setSelection(maxFrmIndex, false);

        spada_minFrm = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, strminFrm);
        spada_minFrm.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spminFrm.setAdapter(spada_minFrm);
        spminFrm.setSelection(0, false);
    }

    public static void setTextWithDate(String data, TextView tvResult) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");// HH:mm:ss
        Date date = new Date(System.currentTimeMillis());
        tvResult.setText(simpleDateFormat.format(date) + " " + data);
    }
}
