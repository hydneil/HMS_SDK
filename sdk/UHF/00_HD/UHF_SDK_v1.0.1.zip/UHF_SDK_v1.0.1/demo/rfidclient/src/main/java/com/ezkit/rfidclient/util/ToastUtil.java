package com.ezkit.rfidclient.util;

import android.content.Context;
import android.widget.Toast;

public class ToastUtil {
    private static Toast mToast;
    public static void showToast(Context mContext, String msg){
        if (mToast != null){
            mToast.cancel();
        }
        mToast = new Toast(mContext);
        mToast.setText(msg);
        mToast.setDuration(Toast.LENGTH_SHORT);
        mToast.show();
    }
}
