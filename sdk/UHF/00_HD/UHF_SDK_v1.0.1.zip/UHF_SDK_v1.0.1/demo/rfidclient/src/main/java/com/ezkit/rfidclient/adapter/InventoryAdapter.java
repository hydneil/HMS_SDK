package com.ezkit.rfidclient.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ezkit.rfidclient.R;
import com.ezkit.rfidclient.bean.InventoryBean;

import net.ezkit.rfid.bean.ReadTagData;
import net.ezkit.rfid.util.LogUtil;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {
    private Context mContext;
    private List<InventoryBean> list;
    private onItemClick click;

    public InventoryAdapter(Context mContext, List<InventoryBean> list) {
        this.mContext = mContext;
        this.list = list;
    }

    public void setOnItemClick(onItemClick click){
        this.click = click;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_inventory, parent,false);
        InventoryViewHolder holder = new InventoryViewHolder(view);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (click!= null){
                    int position = holder.getAdapterPosition();
                    click.onClick(list.get(position).mReadTagData);
                }
            }
        });

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        holder.tag.setText(list.get(position).mReadTagData.getTagID());
        holder.count.setText(String.valueOf(list.get(position).count));
        holder.rssi.setText(String.valueOf(list.get(position).mReadTagData.getRssi()));
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        private TextView tag;
        private TextView count;
        private TextView rssi;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tag = itemView.findViewById(R.id.item_label);
            count = itemView.findViewById(R.id.item_count);
            rssi = itemView.findViewById(R.id.item_rssi);
        }
    }
    public interface onItemClick{
        void onClick(ReadTagData data);
    }
}
