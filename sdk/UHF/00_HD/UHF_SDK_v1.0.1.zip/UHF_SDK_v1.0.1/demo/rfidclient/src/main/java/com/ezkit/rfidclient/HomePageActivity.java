package com.ezkit.rfidclient;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ezkit.rfidclient.adapter.ViewPagerAdapter;
import com.ezkit.rfidclient.fragment.BaseFragment;
import com.ezkit.rfidclient.fragment.ConnectFragment;
import com.ezkit.rfidclient.fragment.InventoryFragment;
import com.ezkit.rfidclient.fragment.ParamFragment;
import com.ezkit.rfidclient.fragment.RWFragment;
import com.ezkit.rfidclient.util.ToastUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import net.ezkit.rfid.util.Constant;
import net.ezkit.rfid.util.LogUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private ViewPager mViewPager;
    private List<BaseFragment> mList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        mViewPager = findViewById(R.id.viewpager);
        bottomNavigationView = findViewById(R.id.bottom_bar);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.connect){
                    mViewPager.setCurrentItem(0);
                }else if (item.getItemId() == R.id.inventory){
                    mViewPager.setCurrentItem(1);
                }else if (item.getItemId() == R.id.rw){
                    mViewPager.setCurrentItem(2);
                }else if (item.getItemId() == R.id.params){
                    mViewPager.setCurrentItem(3);
                }
                return true;
            }
        });
        mList.add(new ConnectFragment(mViewPager));
        mList.add(new InventoryFragment(mViewPager));
        mList.add(new RWFragment(mViewPager));
        mList.add(new ParamFragment(mViewPager));
        mViewPager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager(),mList));
        mViewPager.setOffscreenPageLimit(4);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }
            @Override
            public void onPageSelected(int position) {
                if (position !=0 && !RfidClientApplication.getInstance().mDeviceConnected ) {
                    mViewPager.setCurrentItem(0);
                    ToastUtil.showToast(HomePageActivity.this, getString(R.string.str_connect_open_first));
                    return;
                }
                switch (position){
                    case 0:
                        bottomNavigationView.setSelectedItemId(R.id.connect);
                        break;
                    case 1:
                        bottomNavigationView.setSelectedItemId(R.id.inventory);
                        break;
                    case 2:

                        bottomNavigationView.setSelectedItemId(R.id.rw);
                        break;
                    case 3:
                        bottomNavigationView.setSelectedItemId(R.id.params);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        EventBus.getDefault().register(this);
        setBottomNavigationViewEnabled(false);
    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMyEvent(Integer msg) {
        LogUtil.d("HomePage>>msg>>"+msg);
        if (msg == Constant.DeviceState.OPEN_SUCCESSFUL){
            setBottomNavigationViewEnabled(true);
        } else if (msg == Constant.DeviceState.OPEN_FAILED || msg == Constant.DeviceState.CLOSE_SUCCESSFUL){
            setBottomNavigationViewEnabled(false);
        }
    }

    private void setBottomNavigationViewEnabled(boolean enabled){
        int size = bottomNavigationView.getMenu().size();
        for (int i = 0; i < size; i++){
            bottomNavigationView.getMenu().getItem(i).setEnabled(enabled);
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        LogUtil.d("event>>"+event.getKeyCode());
        mList.get(mViewPager.getCurrentItem()).dispatchKeyEvent(event);
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        LogUtil.i("onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtil.i("onDestroy");
        EventBus.getDefault().unregister(this);
    }
}