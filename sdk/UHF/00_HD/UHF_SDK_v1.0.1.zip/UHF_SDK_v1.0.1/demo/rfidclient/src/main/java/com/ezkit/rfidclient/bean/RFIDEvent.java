package com.ezkit.rfidclient.bean;

public class RFIDEvent {
    private int state;
}
