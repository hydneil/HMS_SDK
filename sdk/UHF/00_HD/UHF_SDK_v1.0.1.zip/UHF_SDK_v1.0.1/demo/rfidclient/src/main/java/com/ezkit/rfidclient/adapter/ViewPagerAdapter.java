package com.ezkit.rfidclient.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.ezkit.rfidclient.fragment.BaseFragment;

import java.util.List;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    List<BaseFragment> list;

    public ViewPagerAdapter(@NonNull FragmentManager fm, List<BaseFragment> list) {
        super(fm);
        this.list = list;
    }

    @NonNull
    @Override
    public BaseFragment getItem(int position) {
        return list.get(position);
    }

    @Override
    public int getCount() {
        return list == null ? 0 : list.size();
    }
}
